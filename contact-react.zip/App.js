/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React from 'react';
import {Platform, StatusBar, Alert, Linking, LogBox} from 'react-native';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-community/async-storage';
import {NavigationContainer} from '@react-navigation/native';
import {Provider} from 'react-redux';
import FlashMessage from 'react-native-flash-message';
import {ThemeProvider} from 'styled-components';
import {AuthContext} from './src/context';
import AppTheme from './src/styles';
import NotAuthenticatedContainer from './src/routes';
import AuthenticatedContainer from './src/routes/mainStack';
import api, {setClientToken, URI} from './src/services/api';
import store from './src/store';
import NotifService from '~/utils/NotifService';
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import {
  persistItemInStorage,
  getItemFromStorage,
} from '~/utils/AsyncStorageManager';
import {ROUTE_NAMES, CONSTANTS, ASYNC_KEY} from '~/utils/CONSTANTS';

import env from 'react-native-config';
import {GoogleSignin, statusCodes} from '@react-native-community/google-signin';
import {AccessToken, LoginManager} from 'react-native-fbsdk';
import { BackHandler } from 'react-native';
import { checkVersion } from "react-native-check-version";

export default function App() {
  const UNAUTHORIZED = 401;
  const NOT_FOUND = 404;

  // Handle notification
  // const notif = new NotifService(
  //   async token => {
  //     console.log('> TOKEN FCM', token);
  //     await persistItemInStorage(ASYNC_KEY.FCM_TOKEN, token.token);
  //   },
  //   fcm => {
  //     // TODO : handle message from fcm
  //     fcm.finish(PushNotificationIOS.FetchResult.NoData);
  //   },
  // );

  const [state, dispatch] = React.useReducer(
    (prevState, action) => {
      switch (action.type) {
        case 'RESTORE_TOKEN':
          return {
            ...prevState,
            isLoading: false,
            navigateAuth: action.navigateAuth,
            userToken: action.token,
          };
        case 'SIGN_IN':
          return {
            ...prevState,
            isSignout: false,
            navigateAuth: false,
            userToken: action.token,
          };
        case 'SIGN_OUT':
          return {
            ...prevState,
            isSignout: true,
            navigateAuth: true,
            userToken: null,
          };
        case 'GO_TO_LOGIN':
          return {
            ...prevState,
            isSignout: true,
            navigateAuth: false,
            userToken: null,
          };
        case 'GO_TO_HOME':
          return {
            ...prevState,
            isSignout: true,
            navigateAuth: true,
            userToken: null,
          };
        case 'REGISTER':
          return {
            ...prevState,
            isSignout: true,
            navigateAuth: true,
            userToken: null,
          };
        case 'GO_TO_SIGNUP':
            return {
              ...prevState,
              isSignout: true,
              navigateAuth: true,
              userToken: null,
            };
      }
    },
    {
      isLoading: true,
      isSignout: false,
      userToken: null,
      navigateAuth: false,
    },
  );

  api.interceptors.response.use(
    response => response,
    error => {
      if (error && error.response) {
        const {status} = error.response;
        if (status === UNAUTHORIZED) {
          AsyncStorage.removeItem('userToken');
          dispatch({type: 'SIGN_OUT'});
        } else if (status === NOT_FOUND) {
          AsyncStorage.removeItem('userToken');
          dispatch({type: 'SIGN_OUT'});
        }
      }
      return Promise.reject(error);
    },
  );
  const [isFirstTime, setIsFirsTime] = React.useState('1');
  React.useEffect(() => {
    console.log('WEB_CLIENT_ID', env.WEB_CLIENT_ID);
    GoogleSignin.configure({
      webClientId: env.WEB_CLIENT_ID,
    });
  }, []);

  React.useEffect(() => {
    LogBox.ignoreAllLogs();
    // AsyncStorage.removeItem('isFirstTime');
    // Fetch the token from storage then navigate to our appropriate place
    const bootstrapAsync = async () => {
      let userToken;
      try {
        userToken = await AsyncStorage.getItem('userToken');
        await setClientToken(userToken);
      } catch (e) {
        // Restoring token failed
      }
      AsyncStorage.getItem('isFirstTime').then(success => {
        setIsFirsTime(success);
        console.log(success, 'isFirsTime');
        console.log(state.navigateAuth, 'state.navigateAuth');
        dispatch({
          type: 'RESTORE_TOKEN',
          token: userToken,
          navigateAuth: false,
        });
      });
    };

    bootstrapAsync();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  React.useEffect(() => {
    console.log('test');
    AsyncStorage.getItem('isFirstTime').then(success => {
      setIsFirsTime(success);
    });
  });
  React.useEffect(() => {
    // dynamicLinks()
    //   .getInitialLink()
    //   .then(link => {
    //     var links = link.url.split("/");
    //     if (links[2] === 'beauty2go.my') {
    //       AsyncStorage.setItem('referralCode',links[3]);
    //     }
    //   });
  }, []);
  const authContext = React.useMemo(
    () => ({
      signIn: async (data, showLoginError, onDone) => {
        try {
          const notificationToken = await getItemFromStorage(
            ASYNC_KEY.FCM_TOKEN,
            null,
          );

          AsyncStorage.removeItem('loginWith');

          const response = await api.post(`${URI.AUTH.LOGIN}`, {
            username: data.username,
            password: data.password
          });
          
          console.warn(response.data)
          if (response.data.status === "success" && response.data.data.user != null) {
            await setClientToken(response.data.data.access_token);
            await AsyncStorage.setItem(
              'userToken',
              response.data.data.access_token
            );
            await AsyncStorage.setItem(
              'userData',
              String(response.data.data.user),
            );
            // if (response.data.data.user.status !== "0") {
            //   console.warn('dispatch')
              dispatch({
                type: 'SIGN_IN',
                token: response.data.data.access_token,
                // token: 'dVZhYmJkcTVhQXNhRTBRS3J5UUVpaFlZR3lyN0ZsZEpVc1kxNFV6Wg=='
              });
            // }
            console.warn('masuk onDone ga?')
            onDone(response);
          } else {
            //console.warn(response)
            showLoginError(response.data.message.error[0], 'error');
          }
        } catch (e) {
          console.error(e);
          if (e.code === 'ECONNABORTED') {
            showLoginError(e.message);
          } else if (e.response) {
            console.warn(e.response.data.message);
            if(e.response.data.message == "User tidak ditemukan"){
              console.warn('should be signup form')
              onDone(e.response.data);
            }else{
              showLoginError(e.response.data.message);
            }
          } else {
            //showLoginError('Network Error');
          }
        }
      },
      forgotPassword: async (phone, code, password, showLoginError, onDone) => {
        try {
          const response = await api.post(`${URI.AUTH.FORGOT_PASSWORD}`, {
            phone: phone,
            otp: code,
            newPassword: password,
          });
          if (response.data.status !== false) {
            onDone();
          } else {
            showLoginError(response.data.message, 'error');
          }
        } catch (e) {
          console.log(e.response);
          if (e.code === 'ECONNABORTED') {
            showLoginError(e.message);
          } else if (e.response) {
            showLoginError(e.response.data.message, 'error');
          } else {
            showLoginError('Network Error', 'error');
          }
        }
      },
      signOut: async () => {
        AsyncStorage.removeItem('userToken');
        await api.get(`${URI.AUTH.LOGOUT}`);
        dispatch({type: 'SIGN_OUT'});
      },
      register: async (data, showLoginError, onDone) => {
        try {
          console.log('Data register', data);
          const response = await api.post(`${URI.AUTH.REGISTER}`, data);
          // const response = await api.post(`${URI.AUTH.LOGIN}`, {
          //   otp: data.otp
          // });
          console.log(response);
          if (response.data.succes !== false) {
            dispatch({type: 'REGISTER'});
            onDone(response);
            // onSuccess();
          } else {
            showLoginError(response.data.message, 'error');
          }
        } catch (e) {
          console.log(e);
          if (e.code === 'ECONNABORTED') {
            showLoginError(e.message);
          } else if (e.response) {
            showLoginError(e.response.data.errorMessage, 'error');
          } else {
            showLoginError('Network Error', 'error');
          }
        }
      },
      goToLogin: async () => {
        console.warn('goToLogin App.js')
        AsyncStorage.removeItem('userToken');
        dispatch({type: 'GO_TO_LOGIN'});
      },
      goToHome: async () => {
        dispatch({type: 'GO_TO_HOME'});
        setIsFirsTime('0');
      },
      goToSignup: async () => {
        dispatch({
          type: 'GO_TO_SIGNUP', 
          payload: {isSignup: true}
        });
      },
    }),
    [],
  );

  React.useEffect(() => {
    //checkUpdateNeeded();
  }, []);

  const checkUpdateNeeded = async () => {
    try {
      const version = await checkVersion();
      console.warn("Got version info:", version);

      if (version.needsUpdate) {
        console.warn(`App has a ${version.updateType} update pending.`);
        console.warn(version);
        Alert.alert(
          'New Version Available!', 
          'Please update your app before continuing.',
          [
            {
              text: 'UPDATE',
              onPress: () => {
                BackHandler.exitApp();
                Linking.openURL(version.url);  // open store if update is needed.
              },
            },
          ],
          {cancelable: false}
        );
      }
    } catch(error){
      console.warn("checkUpdateNeededError: " + error)
    }
  };

  return (
    <AuthContext.Provider value={authContext}>
      <SafeAreaProvider>
        <StatusBar
          backgroundColor={AppTheme.colors.primaryColor}
          barStyle="light-content"
          translucent
        />
        <ThemeProvider theme={AppTheme}>
          {state.isLoading ? null : state.navigateAuth && state.userToken == null ? (
            <Provider store={store}>
              <NotAuthenticatedContainer isFirstTime={isFirstTime} />
            </Provider>  
          ) : (
            <Provider store={store}>
              <AuthenticatedContainer isLoggedIn={state.userToken != null} />
            </Provider>
          )}
          <FlashMessage
            duration={5000}
            position={
              Platform.OS === 'ios' ? 'bottom' : {bottom: 0}
            }
          />
        </ThemeProvider>
      </SafeAreaProvider>
    </AuthContext.Provider>
  );
}
