// @flow

import React from 'react';
import {View, Text} from 'react-native';
import styled from 'styled-components';

const HeaderWrapper = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: ${({theme}) =>
    `${theme.metrics.largeSize}px ${theme.metrics.smallSize}px ${
      theme.metrics.extraSmallSize
    }px  ${theme.metrics.largeSize}px`};
`;

const SectionText = styled(Text)`
  color: ${({theme}) => theme.colors.darkText};
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.5%')}px;
  margin-bottom: 8px;
`;

const SectionTextViewAll = styled(Text)`
  color: ${({theme}) => theme.colors.primaryColor};
  padding-right: 10px;
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.0%')}px;
  margin-bottom: 8px;
`;
const renderSectionHeader = (navigation: Object, title: string): Object => {
  console.log('> renderSectionHeader');
  return (
    <HeaderWrapper>
      <SectionText>{title}</SectionText>
      {/* <SectionTextViewAll>View All</SectionTextViewAll> */}
    </HeaderWrapper>
  );
};

type Props = {
  navigation: Object,
  children: Object,
  title: string,
};

const Section = ({title, navigation, children}: Props) => {
  console.log('> Section');
  return (
    <View>
      {renderSectionHeader(navigation, title)}
      {children}
    </View>
  );
};

export default Section;
