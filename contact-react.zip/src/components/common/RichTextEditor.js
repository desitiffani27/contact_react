import React from 'react';
import { 
  SafeAreaView, 
  Text
} from 'react-native';
import { 
  RichEditor, 
  RichToolbar, 
  actions 
} from 'react-native-pell-rich-editor';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

const RichTextEditor = ({value, onChangeText}) => {
  return (
      <SafeAreaView style={{flex:1, backgroundColor: '#fff'}}>
        {/* <KeyboardAvoidingView> */}
          <RichEditor
            ref={(r) => value = r}
            initialContentHTML={value}
            onChange={onChangeText}
            // editorInitializedCallback={() => this.onEditorInitialized()}
          />
          <RichToolbar
            getEditor={() => value}
            actions={[
              actions.setBold,
              actions.setItalic,
              actions.setUnderline,
              actions.insertBulletsList,
              actions.insertOrderedList,
              actions.heading1,
              actions.heading4,
            ]}
            iconMap={{
              [actions.setUnderline]: () => (
                <Icon
                  name="format-underline"
                  color='#8e8e91'
                  size={25}
                />
              ),
              [actions.heading1]: () => (
                  <Text style={{color: '#8e8e91', textAlign: 'center'}}>H1</Text>
              ),
              [actions.heading4]: () => (
                  <Text style={{color: '#8e8e91', textAlign: 'center'}}>H3</Text>
              )
          }}
          />
        {/* </KeyboardAvoidingView> */}
      </SafeAreaView>
    )
};

export default RichTextEditor;