// @flow

import React, {Component} from 'react';
import {TouchableWithoutFeedback, Image, Text, View} from 'react-native';
import env from 'react-native-config';
import ShimmerPlaceholder from 'react-native-shimmer-placeholder';
import {useNavigation} from '@react-navigation/native';
import styled from 'styled-components';
import {CONSTANTS, ROUTE_NAMES} from '../../utils/CONSTANTS';
import AppTheme from '../../styles';

const Container = styled(View)`
  width: ${({theme}) => theme.metrics.getWidthFromDP('36%')}px;
  height: ${({theme}) => theme.metrics.getHeightFromDP('30%')}px;
  margin-left: ${({theme, isFirst}) =>
    isFirst ? theme.metrics.largeSize : 0}px;
  margin-right: ${({theme}) => theme.metrics.largeSize}px;
  align-content: center;
  flex-direction: row;
  justify-content: center;
`;

const ContainerWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.getWidthFromDP('36%')}px;
  height: ${({theme}) => theme.metrics.getHeightFromDP('29%')}px;
  flex-direction: row;
  padding-top: 10px;
  border-radius: 8px;
  justify-content: center;
  shadow-color: ${({theme}) => theme.colors.lightDarkLayer};
  elevation: 2;
`;

const ImageShimmerOverlay = styled(ShimmerPlaceholder).attrs({
  visible: false,
  autoRun: true,
})`
  width: 100%;
  height: 72%;
  border-radius: ${({theme}) => theme.metrics.borderRadius}px;
  position: absolute;
`;

const ProjectImage = styled(Image).attrs(({imageURL}) => ({
  source: {uri: imageURL},
}))`
  width: ${({theme}) => theme.metrics.getWidthFromDP('36%')};
  height: ${({theme}) => theme.metrics.getHeightFromDP('22%')};
  border-top-right-radius: ${({theme}) => theme.metrics.borderRadius}px;
  border-top-left-radius: ${({theme}) => theme.metrics.borderRadius}px;
  position: absolute;
`;

const BottomContentWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.getWidthFromDP('36%')}px;
  height: ${({theme}) => theme.metrics.getHeightFromDP('11%')}px;
  background-color: white;
  border-bottom-start-radius: 10px;
  border-bottom-end-radius: 10px;
  justify-content: space-between;
  position: absolute;
  top: ${({theme}) => theme.metrics.getHeightFromDP('18%')};
`;

const ProjectTitle = styled(Text).attrs({
  ellipsizeMode: 'tail',
  numberOfLines: 2,
})`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3.7%')}px;
  font-family: CircularStd-Medium;
  padding: ${({theme}) => theme.metrics.smallSize}px;
  color: ${({theme}) => theme.colors.black};
`;

const SectionListItem = props => {
  const {isFirst, item} = props;
  const [isImageLoaded, setImageLoaded] = React.useState(false);
  const navigation = useNavigation();

  const onImageLoaded = () => {
    setImageLoaded(true);
  };

  const renderContent = () => {
    return (
      <BottomContentWrapper>
        <ProjectTitle>{item.name}</ProjectTitle>
        <View
          style={{
            backgroundColor: AppTheme.colors.softPink,
            height: 25,
            flexDirection: 'row',
            borderBottomEndRadius: 10,
            borderBottomStartRadius: 10,
            alignContent: 'center',
            justifyContent: 'center',
          }}>
          <Text
            style={{
              color: AppTheme.colors.primaryColor,
              fontSize: 12,
              padding: 3,
              fontWeight: 'bold',
            }}>
            Starts from RM{' '}
            {item.services.length > 0 && item.services[0].minPrice !== null
              ? item.services[0].minPrice
              : 0}
          </Text>
        </View>
      </BottomContentWrapper>
    );
  };

  return (
    <Container isFirst={isFirst}>
      <TouchableWithoutFeedback
        onPress={() => {
          navigation.navigate(ROUTE_NAMES.SERVICES, {
            [CONSTANTS.NAVIGATION_PARAM_ID]: item.id,
          });
          console.log('to detail service');
        }}
        style={{flex: 1}}>
        <ContainerWrapper>
          <ProjectImage
            onLoad={() => onImageLoaded()}
            imageURL={item.img !== null ? item.img : 'login'}
          />
          {renderContent()}
        </ContainerWrapper>
      </TouchableWithoutFeedback>
      {!isImageLoaded && <ImageShimmerOverlay />}
    </Container>
  );
};

export default SectionListItem;
