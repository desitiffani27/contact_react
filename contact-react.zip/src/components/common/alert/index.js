import Alert from './Component';
import { TYPES } from './config';

export { Alert, TYPES };
