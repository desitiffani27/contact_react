// @flow

import React from 'react';
import {View, FlatList} from 'react-native';
import styled from 'styled-components';
import SectionListItem from './SectionListItem';

const Container = styled(View)`
  justify-content: space-between;
  width: 100%;
`;

const ListWrapper = styled(View)`
  flex: 1;
  flex-direction: row;
`;

const SectionContainer = ({items, routeName}) => {
  console.log('> items size: ' + items.length);
  return (
    <Container>
      <ListWrapper>
        <FlatList
          renderItem={({item, index}) => {
            return <SectionListItem item={item} isFirst={index === 0} />;
          }}
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item.id}
          data={items}
          horizontal
        />
      </ListWrapper>
    </Container>
  );
};

export default SectionContainer;
