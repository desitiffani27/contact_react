// @flow

import React, {Component} from 'react';
import {
  SafeAreaView,
  View,
  TextInput,
  TouchableOpacity,
  Text,
} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {showMessage} from 'react-native-flash-message';
import styled from 'styled-components';
import InfoEmpty from '~/components/common/InfoEmpty';
import {Creators as ProfileCreators} from '../../../store/ducks/profile';
import {CONSTANTS} from '~/utils/CONSTANTS';
import appStyles from '~/styles';
const ContentContainer = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('7%')}px;
  justify-content: center;
  align-items: center;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({color}) => color};
  border-radius: 4px;
`;
class changePassword extends Component {
  state = {
    isRefreshing: false,
    oldPassword: null,
    password: null,
    confirmPassword: null,
  };
  // static getDerivedStateFromProps(props, state) {
  //   const {profileRequest} = props;
  //   const {error: error1, errorMessage: errorMessage1} = profileRequest;

  //   if (error1 && errorMessage1 !== null) {
  //     showMessage({
  //       message: errorMessage1,
  //       type: 'danger',
  //       icon: 'danger',
  //     });
  //   }

  //   return {
  //     isRefreshing: false,
  //   };
  // }
  componentDidMount() {
    console.log('> Schedule Screen');
    SplashScreen.hide();
    // this.requestData();
    this.requestProfile();
  }

  requestProfile() {
    console.log('> requestData->getProfile', this.props);
    const {getProfileRequest} = this.props.profileActions;
    getProfileRequest();
  }

  validator = () => {
    if (!this.state.oldPassword) {
      this.showRegisterError('Old password cannot be empty !', 'error');
      return false;
    }
    if (!this.state.password) {
      this.showRegisterError('Password cannot be empty !', 'error');
      return false;
    }
    if (!this.state.confirmPassword) {
      this.showRegisterError('Password confirm cannot be empty !', 'error');
      return false;
    }
    if (this.state.confirmPassword !== this.state.password) {
      this.showRegisterError('Password confirm not match !', 'error');
      return false;
    }
    return true;
  };
  showRegisterError = (message, type) => {
    // setProgressVisible(false);

    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
    });
  };
  verify() {
    const {changePasswordRequest} = this.props.profileActions;
    const auth = this.context;
    this.validator() &&
      changePasswordRequest({
        oldPassword: this.state.oldPassword,
        password: this.state.password,
        passwordConfirmation: this.state.confirmPassword,
        onDone: () => {
          this.props.navigation.goBack();
        },
        showError: (message, type) => {
          showMessage({
            message: message,
            type: type === 'error' ? 'danger' : 'success',
            icon: type === 'error' ? 'danger' : 'success',
          });
        },
      });
  }

  renderNullData = text => {
    return (
      <View>
        <InfoEmpty
          scrollEnabled={false}
          title={text}
          refreshing={this.state.isRefreshing}
          onRefresh={this.requestProfile}
        />
      </View>
    );
  };

  render() {
    const {pkomRequest, profileRequest} = this.props;
    console.log('> render');
    let passTextInput = null;
    let confirmPassTextInput = null;
    return (
      <SafeAreaView
        style={{
          paddingHorizontal: appStyles.metrics.extraLargeSize,
          paddingVertical: appStyles.metrics.extraLargeSize,
          backgroundColor: appStyles.colors.white,
          flex: 1,
        }}>
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            // backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            marginBottom: 10,
          }}
          onChangeText={text => this.setState({oldPassword: text})}
          value={this.state.oldPassword}
          keyboardType={'default'}
          placeholder={'Old Password'}
          secureTextEntry={true}
          returnKeyType={'next'}
          onSubmitEditing={() => passTextInput.focus()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
        />
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            // backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            marginBottom: 10,
          }}
          onChangeText={text => this.setState({password: text})}
          value={this.state.password}
          returnKeyType={'next'}
          keyboardType={'default'}
          placeholder={'New Password'}
          secureTextEntry={true}
          onSubmitEditing={() => confirmPassTextInput.focus()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          ref={input => {
            passTextInput = input;
          }}
        />
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            // backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            marginBottom: 10,
          }}
          onChangeText={text => this.setState({confirmPassword: text})}
          value={this.state.confirmPassword}
          keyboardType={'default'}
          secureTextEntry={true}
          placeholder={'Confirm New Password'}
          onSubmitEditing={() => this.verify()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          ref={input => {
            confirmPassTextInput = input;
          }}
        />
        <TouchableOpacity
          onPress={() => {
            // setProgressVisible(true);
            // signIn({username, password}, showLoginError);
            this.verify();
          }}>
          <ContentContainer color={appStyles.colors.primaryColor}>
            <Text style={{color: 'white', fontWeight: 'bold'}}>SUBMIT</Text>
          </ContentContainer>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = state => ({
  profileRequest: state.profile,
});

// const mapDispatchToProps = dispatch => {
//   bindActionCreators(
//     Object.assign({}, ScheduleCreators, ProfileCreators),
//     dispatch,
//   );
// };
function mapDispatchToProps(dispatch) {
  return {
    profileActions: bindActionCreators(ProfileCreators, dispatch),
  };
}
export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(changePassword);
