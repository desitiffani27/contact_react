import * as React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Platform} from 'react-native';

import {ROUTE_NAMES} from '../../../utils/CONSTANTS';
import {
  setHiddenHeaderLayout,
  setDefaultHeaderLayout,
} from '../../../routes/headerUtils';
import ChangePassword from '../change-password';
// import PkomDetail from '../pkom-detail';
// import BookingDetail from '../booking-detail';
import Settings from './index';

const Stack = createStackNavigator();

function Routes() {
  console.log('> Setting Page');
  return (
    <Stack.Navigator
      initialRouteName={ROUTE_NAMES.SETTINGS}
      screenOptions={{
        gestureEnabled: true,
        gestureDirection: 'horizontal',
      }}
      animation="fade"
      mode={Platform.OS === 'ios' ? 'card' : 'modal'}
      headerMode="screen">
      <Stack.Screen
        name={ROUTE_NAMES.SETTINGS}
        component={Settings}
        options={({navigation}) =>
          setDefaultHeaderLayout(navigation, 'Account', 'Modesta-Script', 20)
        }
      />
      <Stack.Screen
        name={ROUTE_NAMES.CHANGE_PASSWORD}
        component={ChangePassword}
        options={({navigation}) =>
          setDefaultHeaderLayout(
            navigation,
            'Change Password',
            'Modesta-Script',
            20,
          )
        }
      />
    </Stack.Navigator>
  );
}

export default Routes;
