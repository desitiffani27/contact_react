import React from 'react';
import {TouchableOpacity, View, Image, Text, StyleSheet} from 'react-native';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import styles from '~/styles';
import {ROUTE_NAMES as HOME_ROUTE_NAMES, CONSTANTS} from '~/utils/CONSTANTS';
import env from 'react-native-config';
import {useNavigation} from '@react-navigation/native';

const Profile = ({data, onProfileChanged}) => {
  const navigation = useNavigation();

  const stylesComponent = StyleSheet.create({
    // View
    container: {
      flexDirection: 'row',
      marginHorizontal: styles.metrics.largeSize,
      alignItems: 'center',
    },
    containerText: {
      marginStart: styles.metrics.extraLargeSize,
      flex: 1,
    },
    containerEdit: {
      flexDirection: 'row',
      alignItems: 'center',
    },

    // Image
    imageAvatar: {
      width: styles.metrics.getWidthFromDP('25%'),
      height: styles.metrics.getWidthFromDP('25%'),
      borderRadius: styles.metrics.getWidthFromDP('25%') / 2,
      marginTop: styles.metrics.getHeightFromDP('4%'),
      marginBottom: styles.metrics.getHeightFromDP('1%'),
      overflow: 'hidden',
      resizeMode: 'cover',
    },

    // Text
    textName: {
      fontSize: 20,
      fontWeight: 'bold',
    },
    textEdit: {
      fontSize: 14,
      color: styles.colors.gray,
      marginEnd: styles.metrics.smallSize,
    },
  });

  const isValidURL = (str) => {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return !!pattern.test(str);
  };

  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={() => {
        navigation.navigate(HOME_ROUTE_NAMES.PROFILE_EDIT, {
          [CONSTANTS.DATA]: data,
          [CONSTANTS.FUNCTION]: onProfileChanged,
        });
      }}>
      <View style={stylesComponent.container}>
        <Image
          defaultSource={{uri: 'no_avatar'}}
          source={{
            uri: isValidURL(data.profile.foto_profil) ? data.profile.foto_profil : "https://alumni.ikama.or.id/assets/attachment/alumni/"+data.profile.foto_profil,
          }}
          style={stylesComponent.imageAvatar}
        />
        <View style={stylesComponent.containerText}>
          <Text
            adjustsFontSizeToFit={true}
            numberOfLines={1}
            style={stylesComponent.textName}>
            {data.profile.nama}
          </Text>

          <View style={stylesComponent.containerEdit}>
            <Text style={stylesComponent.textEdit}>Edit Profile</Text>
            <MaterialIcon
              color={styles.colors.gray}
              name={'keyboard-arrow-right'}
              size={16}
            />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default Profile;
