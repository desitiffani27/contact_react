// @flow

import React, {Component} from 'react';
import {
  TouchableOpacity,
  ScrollView,
  Platform,
  Switch,
  Text,
  Animated,
  Alert,
  View,
} from 'react-native';

import styled from 'styled-components';
import appStyle from '~/styles';

import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import env from 'react-native-config';
import {ROUTE_NAMES as HOME_ROUTE_NAMES, CONSTANTS} from '~/utils/CONSTANTS';
import appStyles from '~/styles';

import {AuthContext} from '../../../context';
import {Creators as AccountCreators} from '../../../store/ducks/account';
import {
  getItemFromStorage,
  persistItemInStorage,
} from '~/utils/AsyncStorageManager';

import {SWITCH_STATE_REFS, getItemConfig, TYPES} from './ItemConfig';
import Profile from './components/Profile';
import Loading from '~/components/common/Loading';

const Container = styled(View)`
  flex: 1;
  background-color: ${({theme}) => theme.colors.white};
`;

const SectionTitleText = styled(Text)`
  color: ${({theme}) => theme.colors.darkText};
  font-family: CircularStd-Bold;
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'ios' ? '4.2%' : '4.8%';
    return theme.metrics.getWidthFromDP(percentage);
  }}px;
`;

const ItemWrapper = styled(View)`
  padding: ${({theme}) => theme.metrics.largeSize}px;
`;

const LineSeparator = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('0.1%')};
  background-color: ${({theme}) => theme.colors.gray};
`;

const LanguageSectionWrapper = styled(View)`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;

const SelectedLanguageText = styled(Text)`
  color: ${({theme}) => theme.colors.red};
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'ios' ? '4%' : '4.8%';
    return theme.metrics.getWidthFromDP(percentage);
  }}px;
`;

const ReviewText = styled(Text)`
  color: ${({theme}) => theme.colors.primaryColor};
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'ios' ? '4%' : '4.8%';
    return theme.metrics.getWidthFromDP(percentage);
  }}px;
`;

const SmallText = styled(Text)`
  color: ${({theme}) => theme.colors.subText};
  margin: ${({theme}) => `${theme.metrics.extraSmallSize}px 0`};
  font-family: CircularStd-Book;
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'ios' ? '3.8%' : '4%';
    return theme.metrics.getWidthFromDP(percentage);
  }}px;
`;

const OptionWrapper = styled(View)`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;

const OptionTextWrapper = styled(View)`
  width: 75%;
`;

const MediumText = styled(Text)`
  color: ${({theme}) => theme.colors.subText};
  margin-top: ${({theme}) => theme.metrics.extraSmallSize};
  font-family: CircularStd-Bold;
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'ios' ? '4%' : '4.5%';
    return theme.metrics.getWidthFromDP(percentage);
  }}px;
`;

const OptionWithouDescriptionWrapper = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: ${({theme}) => theme.metrics.largeSize}px;
`;

const MultipleOptionsTitleWrapper = styled(View)`
  padding: ${({theme}) =>
    `${theme.metrics.largeSize}px 0 ${theme.metrics.mediumSize}px ${
      theme.metrics.largeSize
    }px`};
`;

const DefaultText = styled(Text)`
  color: ${({theme, color}) => color || theme.colors.defaultWhite};
  font-family: CircularStd-Black;
  font-size: ${({theme}) => theme.metrics.largeSize}px;
`;

const ContentContainer = styled(View)`
  width: 92%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('7%')}px;
  justify-content: center;
  align-items: center;
  margin-left: 4%;
  background-color: ${({color}) => color};
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  border-radius: 4px;
`;

const createAnimationStyle = (animation: Object): Object => {
  const translateY = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [-5, 0],
  });

  return {
    opacity: animation,
    transform: [
      {
        translateY,
      },
    ],
  };
};

type State = {
  receiveAllNotifications: boolean,
  whenIsAboutPromotions: boolean,
  notificationsSound: boolean,
  promotionsNearMe: boolean,
  whenPastSearch: boolean,
};

class Settings extends Component<Props, State> {
  state = {
    receiveAllNotifications: false,
    whenIsAboutPromotions: false,
    notificationsSound: false,
    promotionsNearMe: false,
    whenPastSearch: false,
    data: null,
  };
  static contextType = AuthContext;
  _loginButtonAnimation = new Animated.Value(0);
  async componentDidMount() {
    const auth = this.context;
    const receiveAllNotificationsFromStorage = await getItemFromStorage(
      SWITCH_STATE_REFS.RECEIVE_ALL_NOTIFICATIONS,
      'false',
    );

    const whenAboutPromotionsFromStorage = await getItemFromStorage(
      SWITCH_STATE_REFS.WHEN_ABOUT_DISCOUNTS,
      'false',
    );

    const notificationsSoundFromStorage = await getItemFromStorage(
      SWITCH_STATE_REFS.NOTIFICATIONS_SOUND,
      'false',
    );

    const receiveNearMeFromStorage = await getItemFromStorage(
      SWITCH_STATE_REFS.PROMOTIONS_NEAR_ME,
      'false',
    );

    const whenPastSearchFromStorage = await getItemFromStorage(
      SWITCH_STATE_REFS.WHEN_PAST_SEARCH,
      'false',
    );

    const {route} = this.props;
    const {[CONSTANTS.DATA]: data} = route.params;

    this.setState({
      receiveAllNotifications: receiveAllNotificationsFromStorage === 'true',
      whenIsAboutPromotions: whenAboutPromotionsFromStorage === 'true',
      notificationsSound: notificationsSoundFromStorage === 'true',
      promotionsNearMe: receiveNearMeFromStorage === 'true',
      whenPastSearch: whenPastSearchFromStorage === 'true',
      data,
    });

    Animated.stagger(100, [
      Animated.timing(this._loginButtonAnimation, {
        toValue: 1,
        duration: 350,
      }),
    ]).start();
  }

  handleSwitchToggle = async (option: string): Promise<void> => {
    const {state} = this;

    const value = !state[option];

    this.setState({
      [option]: value,
    });

    await persistItemInStorage(option, value);
  };

  confirmLogout = () => {
    const auth = this.context;
    Alert.alert('Confirmation', 'Are you sure want to logout?', [
      {
        text: 'Cancel',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'OK', onPress: () => auth.signOut()},
    ]);
  };

  renderItemSelector = ({onPress, title}): Object => (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress}>
      <ItemWrapper>
        <LanguageSectionWrapper>
          <SectionTitleText>{title}</SectionTitleText>
          <MaterialIcon
            color={appStyles.colors.gray}
            name={'arrow-forward'}
            size={24}
          />
        </LanguageSectionWrapper>
      </ItemWrapper>
    </TouchableOpacity>
  );

  renderSubItemSelector = ({onPress, title}): Object => (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress}>
      <ItemWrapper>
        <LanguageSectionWrapper>
          <MediumText>{title}</MediumText>
        </LanguageSectionWrapper>
      </ItemWrapper>
    </TouchableOpacity>
  );

  renderSelectLanguageSection = (): Object => (
    <ItemWrapper>
      <LanguageSectionWrapper>
        <SectionTitleText>Select Language</SectionTitleText>
        <TouchableOpacity>
          <SelectedLanguageText>English, US</SelectedLanguageText>
        </TouchableOpacity>
      </LanguageSectionWrapper>
    </ItemWrapper>
  );

  renderOptionWithDescription = (
    title: string,
    description: string,
  ): Object => (
    <OptionTextWrapper>
      <SectionTitleText>{title}</SectionTitleText>
      <SmallText>{description}</SmallText>
    </OptionTextWrapper>
  );

  renderSwitch = (id: string): Object => {
    const {state} = this;
    const value = state[id];

    const thumbTintColor = value
      ? appStyle.colors.primaryColor
      : appStyle.colors.white;
    const trackColor = {
      true:
        Platform.OS === 'android'
          ? appStyle.colors.activeSwitch
          : appStyle.colors.primaryColor,
      false: Platform.OS === 'android' ? appStyle.colors.inactiveSwitch : '',
    };

    return (
      <Switch
        thumbColor={Platform.OS === 'android' ? thumbTintColor : ''}
        onValueChange={() => this.handleSwitchToggle(id)}
        trackColor={trackColor}
        value={value}
      />
    );
  };

  renderItemWitDescription = (type: string): Object => {
    const config = getItemConfig(type);

    const {switchId, title, text} = config;

    return (
      <ItemWrapper>
        <OptionWrapper>
          {this.renderOptionWithDescription(title, text)}
          {this.renderSwitch(switchId)}
        </OptionWrapper>
      </ItemWrapper>
    );
  };

  renderItemWithoutDescription = (type: string): Object => {
    const config = getItemConfig(type);

    const {switchId, title} = config;

    return (
      <OptionWithouDescriptionWrapper>
        <MediumText>{title}</MediumText>
        {this.renderSwitch(switchId)}
      </OptionWithouDescriptionWrapper>
    );
  };

  onProfileChanged = value => {
    console.log('> onProfileChanged', value);
    const data = {...this.state.data, ...value};
    this.setState({data});
    const {route} = this.props;
    const {[CONSTANTS.FUNCTION]: onRefresh} = route.params;
    onRefresh();
  };

  render() {
    // const auth = React.useContext(AuthContext);

    const loginButtonAnimationStyle = createAnimationStyle(
      this._loginButtonAnimation,
    );

    if (!this.state.data) {
      return <Loading />;
    }

    return (
      <Container>
        <ScrollView alwaysBounceVertical={false}>
          <Profile
            data={this.state.data}
            onProfileChanged={this.onProfileChanged.bind(this)}
          />
          <LineSeparator />
          {this.renderItemSelector({
            title: 'FAQ',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.FAQ);
            },
          })}
          <LineSeparator />
          {this.renderItemSelector({
            title: 'Change Password',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.CHANGE_PASSWORD);
            },
          })}
          <LineSeparator />
          {/* <LineSeparator />
          {this.renderSelectLanguageSection()} */}
          {/* <LineSeparator />
          {this.renderItemWitDescription(TYPES.PROMOTIONS_NEAR_ME)}
          {this.renderItemWitDescription(TYPES.NOTIFICATIONS_SOUND)} */}
          <MultipleOptionsTitleWrapper>
            <SectionTitleText>Push Notifications</SectionTitleText>
          </MultipleOptionsTitleWrapper>
          {this.renderItemWithoutDescription(TYPES.RECEIVE_ALL_NOTIFICATIONS)}
          {this.renderItemWithoutDescription(TYPES.WHEN_PAST_SEARCH)}
          <LineSeparator />
          {/* {this.renderItemSelector({
            title: 'Refund Policy',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.REFUND_POLICY);
            },
          })}
          <LineSeparator />
          {this.renderItemSelector({
            title: 'Refund List',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.REFUND_LIST);
            },
          })}
          <LineSeparator />
          {this.renderItemSelector({
            title: 'My Article',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.MY_ARTICLE);
            },
          })}
          <LineSeparator /> */}
          <MultipleOptionsTitleWrapper>
            <SectionTitleText>Info</SectionTitleText>
          </MultipleOptionsTitleWrapper>
          {this.renderSubItemSelector({
            title: 'Contact Us',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.CONTACT_US);
            },
          })}
          {this.renderSubItemSelector({
            title: 'Terms and Conditions',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.TERMS_CONDITION);
            },
          })}
          {this.renderSubItemSelector({
            title: 'Privacy Policy',
            onPress: () => {
              this.props.navigation.navigate(HOME_ROUTE_NAMES.PRIVACY_POLICY);
            },
          })}
          <LineSeparator />
          {this.renderSubItemSelector({
            title: 'v ' + env.VERSION_NAME_STRING + (env.BUILD_TYPE == 'debug' ? ' (dev)' : ''),
            onPress: null
          })}
          <DefaultText color={appStyle.colors.gray}>
            
          </DefaultText>
        </ScrollView>
        <Animated.View style={loginButtonAnimationStyle}>
          <TouchableOpacity onPress={() => this.confirmLogout()}>
            <ContentContainer color={appStyle.colors.primaryColor}>
              <DefaultText color={appStyle.colors.defaultWhite}>
                Logout
              </DefaultText>
            </ContentContainer>
          </TouchableOpacity>
        </Animated.View>
      </Container>
    );
  }
}

// export default Settings;
const mapStateToProps = state => ({
  pkomRequest: state.home,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(AccountCreators, dispatch);

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Settings);
