import React, {Component} from 'react';
import {ScrollView} from 'react-native';
import {WebView} from 'react-native-webview';

import env from 'react-native-config';
export default class TermsCondition extends Component {
  render() {
    return (
      <ScrollView contentContainerStyle={{flex: 1}}>
        <WebView
          source={{uri: env.SERVER_URL + 'termsCondition/termsConditionMobile'}}
          startInLoadingState={true}
        />
      </ScrollView>
    );
  }
}
