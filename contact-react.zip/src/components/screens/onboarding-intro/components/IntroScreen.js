// @flow

import React from 'react';
import {Image, Text, View} from 'react-native';

import styled from 'styled-components';

const Wrapper = styled(View)`
  width: 100%;
  height: 100%;
`;

const TextContainer = styled(View)`
  width: 100%;
  justify-content: center;
  align-items: center;
  margin-top: ${({theme}) => theme.metrics.getHeightFromDP('60%')}px;
  padding-horizontal: ${({theme}) => theme.metrics.getWidthFromDP('10%')}px;
`;

const Title = styled(Text)`
  padding-bottom: ${({theme}) => theme.metrics.smallSize}px;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('8%')}px;
  font-family: CircularStd-Black;
  text-align: center;
  color: ${({theme}) => theme.colors.introText};
`;

const Description = styled(Text)`
  text-align: center;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.3%')}px;
  font-family: CircularStd-Medium;
  color: ${({theme}) => theme.colors.lightGray};
`;

const DarkLayer = styled(View)`
  width: 100%;
  height: 100%;
  background-color: ${({theme}) => theme.colors.darkLayer};
  position: absolute;
`;

const ImageWrapper = styled(Image).attrs(({image}) => ({
  source: {uri: image},
  resizeMode: 'cover',
}))`
  width: 100%;
  height: 100%;
  position: absolute;
`;

const LogoImage = styled(Image).attrs(({image}) => ({
  source: {uri: image}
}))`
  width: ${({theme}) => theme.metrics.getHeightFromDP('30%')}px;
  height: ${({theme}) => theme.metrics.getHeightFromDP('30%')}px;
  position: absolute;
  top: ${({theme}) => theme.metrics.getHeightFromDP('21%')}px;
  align-self: center;
`;
// left: ${({theme}) => theme.metrics.getHeightFromDP('3%')}px;

type Props = {
  description: string,
  image: string,
  title: string,
};

const IntroScreen = ({description, image, title}: Props) => (
  <Wrapper>
    <ImageWrapper image={image} />
    {/* <DarkLayer /> */}
    <LogoImage
     image= {'logonew'}/>
    <TextContainer>
      <Title>{title}</Title>
      <Description>{description}</Description>
    </TextContainer>
  </Wrapper>
);

export default IntroScreen;
