export const TYPES = {
  ELEGANCE_FEMINITY: 'ELEGANCE_FEMINITY',
  HEAD_TO_TOE: 'HEAD_TO_TOE',
  FEEL_LIKE_HOME: 'FEEL_LIKE_HOME',
};

export const SCREENS = {
  [TYPES.ELEGANCE_FEMINITY]: {
    title: 'Make Yourself At Home',
    description:
      'No more hassles of traveling, parking and getting used to an unfamiliar environment. Beauty2Go provides you with various beauty and health services at the comfort of your own home! Not only that, you will also receive more personalised attention. ',
    image: 'feellikehome',
  },

  [TYPES.HEAD_TO_TOE]: {
    title: 'Welcome to SILARAS',
    description:
      'Please click NEXT button below for more information! ',
    image: 'bg_intro',
  },

  [TYPES.FEEL_LIKE_HOME]: {
    title: 'Comprehensive',
    description:
      'We are not limited in our capabilities and we strive our best to provide the highest quality of services whether it be in beauty, massage or elderly care services. ',
    image: 'elegancefeminity',
  },
};
