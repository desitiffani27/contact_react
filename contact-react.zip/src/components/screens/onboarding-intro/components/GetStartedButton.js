// @flow

import React from 'react';
import {TouchableOpacity, Text, View} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import styled from 'styled-components';

import AsyncStorage from '@react-native-community/async-storage';
import {ROUTE_NAMES} from '../../../../utils/CONSTANTS';
import {AuthContext} from '../../../../context';
import AppTheme from '~/styles';

const ButtonWrapper = styled(View)`
  justify-content: center;
  flex: 1;
  margin-vertical: ${({theme}) => theme.metrics.getWidthFromDP('1%')}px;
  margin-horizontal: ${({theme}) => theme.metrics.getWidthFromDP('1%')}px;
  align-items: center;
`;

const Button = styled(TouchableOpacity)`
  height: ${({theme}) => theme.metrics.getHeightFromDP('8%')}px;
  justify-content: center;
  padding-vertical: ${({theme}) => theme.metrics.getWidthFromDP('3%')}px;
  padding-horizontal: ${({theme}) => theme.metrics.getWidthFromDP('7%')}px;
  background-color: ${({theme}) => theme.colors.primaryColor};
  border-radius: ${({theme}) => theme.metrics.getHeightFromDP('7%') / 2}px;
`;

const ButtonText = styled(Text)`
  color: ${({theme}) => theme.colors.defaultWhite};
  font-family: CircularStd-Bold;
  font-size: ${({theme}) => theme.metrics.largeRS}px;
`;

const GetStartedButton = () => {
  const navigation = useNavigation();
  const {goToHome, goToLogin} = React.useContext(AuthContext);
  return (
    <View
      style={{
        flexDirection: 'column',
        alignContent: 'center',
        marginTop: '-10%',
      }}>
      {/* <ButtonWrapper>
        <Button
          onPress={async () => {
            await AsyncStorage.setItem('isFirstTime', '0');
            navigation.navigate(ROUTE_NAMES.LOGIN);
          }}>
          <ButtonText>SIGN IN / SIGN ME UP</ButtonText>
        </Button>
      </ButtonWrapper> */}
      <ButtonWrapper>
        <Button
          style={{backgroundColor: AppTheme.colors.introText}}
          onPress={async () => {
            await AsyncStorage.setItem('isFirstTime', '0');
            goToLogin();
          }}>
          <ButtonText>NEXT ></ButtonText>
        </Button>
      </ButtonWrapper>
    </View>
  );
};

export default GetStartedButton;
