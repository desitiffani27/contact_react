// @flow

import React, {Component} from 'react';
import {StatusBar, FlatList, View} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import styled from 'styled-components';
import AsyncStorage from '@react-native-community/async-storage';
import BottomPagination from './components/BottomPagination';
import GetStartedButton from './components/GetStartedButton';
import {SCREENS, TYPES} from './components/SCREENS_TYPES';
import IntroScreen from './components/IntroScreen';

import {ROUTE_NAMES} from '../../../utils/CONSTANTS';
import appStyles from '../../../styles';

const Container = styled(View)`
  flex: 1;
`;

const IntroScreenWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.width}px;
  height: 100%;
`;

const BottomContent = styled(View)`
  width: 100%;
  margin-top: ${({theme}) => theme.metrics.getHeightFromDP('85%')}px;
  padding-horizontal: ${({theme}) => theme.metrics.extraLargeSize}px;
  position: absolute;
`;

const PAGES = [
  // SCREENS[TYPES.ELEGANCE_FEMINITY],
  // SCREENS[TYPES.FEEL_LIKE_HOME],
  SCREENS[TYPES.HEAD_TO_TOE],
];

type Props = {
  navigation: Object,
};

type State = {
  currentPageIndex: number,
};

class OnboardingIntro extends Component<Props, State> {
  state = {
    currentPageIndex: 2,
  };

  componentDidMount() {
    SplashScreen.hide();
  }

  onIncrementPageIndex = () => {
    const {currentPageIndex} = this.state;

    this.setState(
      {
        currentPageIndex: currentPageIndex + 1,
      },
      () => this.onSlidePage(),
    );
  };

  onDecrementPageIndex = () => {
    const {currentPageIndex} = this.state;

    this.setState(
      {
        currentPageIndex: currentPageIndex - 1,
      },
      () => this.onSlidePage(),
    );
  };

  onSlidePage = () => {
    const {currentPageIndex} = this.state;

    this._pagesListRef.scrollToIndex({
      animated: true,
      index: currentPageIndex,
    });
  };

  onFlatlistMomentumScrollEnd = event => {
    const {contentOffset} = event.nativeEvent;

    const isHorizontalSwipeMovement = contentOffset.x > 0;
    const currentPageIndex = isHorizontalSwipeMovement
      ? Math.ceil(contentOffset.x / appStyles.metrics.width)
      : 0;

    this.setState({
      currentPageIndex,
    });
  };

  renderPages = () => (
    <FlatList
      // onMomentumScrollEnd={event => this.onFlatlistMomentumScrollEnd(event)}
      renderItem={({item}) => (
        <IntroScreenWrapper>
          <IntroScreen {...item} />
        </IntroScreenWrapper>
      )}
      showsHorizontalScrollIndicator={false}
      keyExtractor={item => item.title}
      ref={(ref: any) => {
        this._pagesListRef = ref;
      }}
      bounces={false}
      pagingEnabled
      data={PAGES}
      horizontal
    />
  );

  renderPaginationController = () => {
    const {currentPageIndex} = this.state;
    const {navigation} = this.props;

    const PAGINATION_CONTROLLERS = [
      <BottomPagination
        onPressRightButton={this.onIncrementPageIndex}
        onPressLeftButton={async () => {
          await AsyncStorage.setItem('isFirstTime', '0');
          navigation.navigate(ROUTE_NAMES.LOGIN);
        }}
        currentIndex={2}
        numberOfDots={0}
        withSkip
      />,
      <BottomPagination
        onPressRightButton={this.onIncrementPageIndex}
        onPressLeftButton={this.onDecrementPageIndex}
        currentIndex={2}
        numberOfDots={0}
      />,
      <GetStartedButton />,
    ];

    const Controller = PAGINATION_CONTROLLERS[currentPageIndex];

    return <BottomContent>{Controller}</BottomContent>;
  };

  render() {
    return (
      <Container>
        <StatusBar
          backgroundColor="transparent"
          barStyle="light-content"
          translucent
          animated
        />
        {this.renderPages()}
        {this.renderPaginationController()}
      </Container>
    );
  }
}

export default OnboardingIntro;
