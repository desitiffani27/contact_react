// @flow

import React from 'react';
import {TextInput, View, TouchableOpacity} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components';

import {ContentContainer} from './Common';
import appStyles from '~/styles';

const InputWrapper = styled(View)`
  width: 100%;
  height: 100%;
  flex-direction: row;
  align-items: center;
  padding-horizontal: ${({theme}) => theme.metrics.largeSize}px;
`;

const InputIcon = styled(Icon).attrs(({iconName}) => ({
  name: iconName,
  size: 22,
}))`
  margin-right: ${({theme}) => theme.metrics.mediumSize}px;
  color: ${({theme}) => theme.colors.black};
`;

const CustomInput = styled(TextInput).attrs(
  ({
    placeholder,
    type,
    theme,
    value,
    onChangeText,
    caretHidden,
    onSubmitEditing,
    inputRef,
    blurOnSubmit,
    returnKeyType,
  }) => ({
    caretHidden,
    // placeholderTextColor: theme.colors.transparentGrayx,
    // selectionColor: theme.colors.defaultWhite,
    underlineColorAndroid: 'transparent',
    secureTextEntry: type === 'password',
    keyboardType: type === 'telephoneNumber' ? 'number-pad' : 'default',
    autoCapitalize: 'none',
    autoCorrect: false,
    placeholder,
    value,
    returnKeyType,
    onChangeText: onChangeText,
    onSubmitEditing: onSubmitEditing,
    ref: inputRef,
    blurOnSubmit: blurOnSubmit,
  }),
)`
  width: 80%;
  height: 100%;
  font-family: CircularStd-Book;
  color: ${({theme}) => theme.colors.black};
`;

type InputProps = {
  placeholder: string,
  iconName: string,
  type: string,
  value: string,
  onChangeText: any,
  caretHidden: boolean,
  onSubmitEditing: any,
  inputRef: any,
  blurOnSubmit: any,
};

const Input = ({
  placeholder,
  iconName,
  type,
  value,
  onChangeText,
  caretHidden,
  onSubmitEditing,
  returnKeyType,
  inputRef,
  blurOnSubmit,
  editable
}: InputProps): Object => {

  const [eyeIcon, setEyeIcon] = React.useState('eye-off');
  const [inputType, setInputType] = React.useState(type);
  const [isViewPass, setViewPass] = React.useState(false);

  const eyeToggle = () => {
    setViewPass(!isViewPass);
    if(isViewPass){
      setEyeIcon('eye');
      setInputType('text');
    }else{
      setEyeIcon('eye-off');
      setInputType('password');
    }
  };

  return (
    <ContentContainer color={appStyles.colors.transparentGray}>
      <InputWrapper>
        <InputIcon iconName={iconName} />
        <CustomInput
          placeholder={placeholder}
          type={inputType}
          value={value}
          onChangeText={onChangeText}
          onSubmitEditing={onSubmitEditing}
          inputRef={inputRef}
          blurOnSubmit={blurOnSubmit}
          caretHidden={caretHidden}
          returnKeyType={returnKeyType}
          editable={editable == false ? false : true}
        />
        {type === 'password' && (
          <TouchableOpacity
            onPress={()=> eyeToggle() }>
            <InputIcon iconName={eyeIcon} />
          </TouchableOpacity>
        )}
      </InputWrapper>
    </ContentContainer>
  );
}

export default Input;
