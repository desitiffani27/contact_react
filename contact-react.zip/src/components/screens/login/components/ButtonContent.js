// @flow

import React from 'react';
import {TouchableOpacity} from 'react-native';
// import {withNavigation} from 'react-navigation';

// import {ROUTE_NAMES} from '~/routes';
import {ContentContainer} from './Common';

type Props = {
  afterPress: Any,
  children: Object,
  color: string,
};

const ButtonContent = ({afterPress, children, color}: Props): Object => (
  <TouchableOpacity onPress={() => afterPress}>
    <ContentContainer color={color}>{children}</ContentContainer>
  </TouchableOpacity>
);

export default ButtonContent;
