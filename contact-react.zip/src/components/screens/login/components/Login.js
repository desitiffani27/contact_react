// @flow

import React, {useEffect} from 'react';
import {
  TouchableOpacity,
  Animated,
  View,
  Text,
  ActivityIndicator,
} from 'react-native';
import {getBrand, getApiLevel} from 'react-native-device-info';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components';

import {ROUTE_NAMES} from '~/utils/CONSTANTS';
import {useNavigation} from '@react-navigation/native';
import {ContentContainer} from './Common';
import {showMessage} from 'react-native-flash-message';
import ButtonContent from './ButtonContent';
import {DefaultText} from './Common';
import Input from './Input';
import {GoogleSigninButton} from '@react-native-community/google-signin';

import {AuthContext} from '../../../../context';
import appStyles from '~/styles';

const Container = styled(View)`
  width: 100%;
  height: 100%;
`;

const ForgotPasswordContainer = styled(Animated.View)`
  width: 100%;
  justify-content: center;
  align-items: center;
`;

const ForgotPasswordWrapper = styled(View)`
  flex-direction: row;
`;

const RecoverTextButton = styled(TouchableOpacity)`
  margin-left: 4px;
`;

const LabelText = styled (Text)`
  font-size: 13px;
  font-family: CircularStd-Book;
  color: ${({theme}) => theme.colors.white};
  margin-bottom: ${({theme}) => theme.metrics.smallSize}px;
`;

const createAnimationStyle = (animation: Object): Object => {
  const translateY = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [-5, 0],
  });

  return {
    opacity: animation,
    transform: [
      {
        translateY,
      },
    ],
  };
};

export const LoginComponent = props => {
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     username: '',
  //     password: '',
  //     isShowPassword: false,
  //     isProgressVisible: false,
  //   };
  // }
  console.log(props);
  const {
    signIn,
    goToHome,
  } = React.useContext(AuthContext);
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [isXiaomi, setXiaomi] = React.useState(false);
  const [isShowPassword, setIsShowPassword] = React.useState(false);
  const [isProgressVisible, setProgressVisible] = React.useState(false);
  const navigation = useNavigation();
  const _emailInputFieldAnimation = new Animated.Value(0);
  const _passwordInputFieldAnimation = new Animated.Value(0);
  const _loginButtonAnimation = new Animated.Value(0);
  // const _loginFacebookButtonAnimation = new Animated.Value(0);
  // const _loginGooglePlusButtonAnimation = new Animated.Value(0);
  const _forgotPasswordTextAnimation = new Animated.Value(0);

  useEffect(() => {
    Animated.stagger(100, [
      Animated.timing(_emailInputFieldAnimation, {
        toValue: 1,
        duration: 350,
      }),
      Animated.timing(_passwordInputFieldAnimation, {
        toValue: 1,
        duration: 350,
      }),
      Animated.timing(_loginButtonAnimation, {
        toValue: 1,
        duration: 350,
      }),
      Animated.timing(_forgotPasswordTextAnimation, {
        toValue: 1,
        duration: 350,
      }),
    ]).start();
  }, [
    _emailInputFieldAnimation,
    _forgotPasswordTextAnimation,
    _loginButtonAnimation,
    _passwordInputFieldAnimation,
  ]);

  // const [username, setUsername] = React.useState('');
  // const [password, setPassword] = React.useState('');
  // const [isShowPassword, setIsShowPassword] = React.useState(false);
  // const [isProgressVisible, setProgressVisible] = React.useState(false);

  const showLoginError = errorMessage => {
    setProgressVisible(false);
    showMessage({
      message: errorMessage,
      type: 'danger',
      icon: 'danger',
    });
  };

  const renderInput = (
    placeholder: string,
    iconName: string,
    type: string,
    style: Object,
    value: String,
    onChangeText: any,
  ): Object => (
    <Input
      placeholder={placeholder}
      iconName={iconName}
      style={style}
      type={type}
      value={value}
      onChangeText={onChangeText}
    />
  );

  const renderForgotPasswordText = (): Object => {
    const forgotPasswordTextAnimationStyle = createAnimationStyle(
      _forgotPasswordTextAnimation,
    );

    return (
      // <ForgotPasswordContainer style={forgotPasswordTextAnimationStyle}>
      <ForgotPasswordWrapper>
        <DefaultText>Forgot your Password?</DefaultText>
        <RecoverTextButton
          onPress={() => {
            navigation.navigate(ROUTE_NAMES.FORGOT_PASSWORD_PHONE);
          }}>
          <DefaultText color={appStyles.colors.primaryColor}>
            Recover here
          </DefaultText>
        </RecoverTextButton>
      </ForgotPasswordWrapper>
      // </ForgotPasswordContainer>
    );
  };

  const emailAnimationStyle = createAnimationStyle(_emailInputFieldAnimation);
  const passwordAnimationStyle = createAnimationStyle(
    _passwordInputFieldAnimation,
  );
  const loginButtonAnimationStyle = createAnimationStyle(_loginButtonAnimation);
  let passTextInput = null;
  const brandsNeedingWorkaround = [
    'redmi',
    'xiaomi',
    'poco',
    'pocophone',
    'redmi',
  ];
  let needsXiaomiWorkaround = brandsNeedingWorkaround.includes(
    getBrand().toLowerCase(),
  );
  getApiLevel().then(apiLevel => {
    console.log(apiLevel);
    needsXiaomiWorkaround = apiLevel > 28 && needsXiaomiWorkaround;
    setXiaomi(needsXiaomiWorkaround);
  });

  const submitLogin  = () => {
    setProgressVisible(true);
    signIn({username, password}, showLoginError, response => {
      if (response.status == "success") {
        navigation.navigate(ROUTE_NAMES.HOME, {
          data: response.data,
          type: 'HOME',
        });
      }
    });
  };

  return (
    <Container>
      <LabelText>Nomor Handphone</LabelText>
      <Input
        placeholder={''}
        iconName={'email'}
        type={'emailAddress'}
        style={emailAnimationStyle}
        value={username}
        blurOnSubmit={false}
        onChangeText={setUsername}
        returnKeyType={'next'}
        caretHidden={isXiaomi}
      />
      <LabelText>Password</LabelText>
      <Input
        placeholder={''}
        iconName={'lock'}
        type={'password'}
        style={emailAnimationStyle}
        value={password}
        blurOnSubmit={false}
        onChangeText={setPassword}
        onSubmitEditing={event => {
          submitLogin();
        }}
        returnKeyType={'next'}
        caretHidden={isXiaomi}
      />
      {/* <LabelText style={{marginTop: -10, marginBottom: appStyles.metrics.mediumSize}}>Contoh: ikama@gmail.com</LabelText> */}
      <TouchableOpacity
        onPress={() => {
         submitLogin();
        }}>
        <ContentContainer color={appStyles.colors.primaryColor}>
          <DefaultText>Masuk</DefaultText>
        </ContentContainer>
      </TouchableOpacity>
      {/* <View style={{flexDirection: 'row', justifyContent: 'center'}}>
        <LabelText>Belum punya akun IKAMA? </LabelText>
        <TouchableOpacity
          onPress={() => {
            props.onFromLoginToRegister();
          }}>
          <LabelText style={{color: appStyles.colors.blue}}>Daftar</LabelText>
        </TouchableOpacity>
      </View> */}
    </Container>
  );
};

export default LoginComponent;
