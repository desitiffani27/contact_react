// @flow

import React from 'react';
import {View, TouchableOpacity, Alert, Modal, Text} from 'react-native';
import {CheckBox} from 'react-native-elements';
import {showMessage} from 'react-native-flash-message';
import styled from 'styled-components';
import AppTheme from '~/styles';
import {getBrand, getApiLevel} from 'react-native-device-info';
//import dynamicLinks from '@react-native-firebase/dynamic-links';
import {AuthContext} from '../../../../context';
import ButtonContent from './ButtonContent';
import {DefaultText, ContentContainer} from './Common';
import Input from './Input';
import {useNavigation} from '@react-navigation/native';
import appStyles from '~/styles';
import {ROUTE_NAMES} from '~/utils/CONSTANTS';
import RadioButton from '~/components/screens/profile-edit/screens/components/RadioButton';
import AsyncStorage from '@react-native-community/async-storage';

const Container = styled(View)`
  height: 100%;
`;
const TextTerms = styled(Text)`
  color: white;
  font-family: CircularStd-Book;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3.2%')}px;
  text-align: justify;
  margin-right: ${({theme}) => theme.metrics.extraLargeSize}px;
`;
const brandsNeedingWorkaround = [
  'redmi',
  'xiaomi',
  'poco',
  'pocophone',
  'redmi',
];
let needsXiaomiWorkaround = brandsNeedingWorkaround.includes(
  getBrand().toLowerCase(),
);
const SignUp = (props): Object => {
  const {register, getOtp} = React.useContext(AuthContext);
  const [username, setUsername] = React.useState(null);
  const [gender, setGender] = React.useState(null);
  const [isXiaomi, setXiaomi] = React.useState(false);
  const [email, setEmail] = React.useState(null);
  const [referralCode, setReferralCode] = React.useState(null);
  const [phone, setPhone] = React.useState(null);
  const [password, setPassword] = React.useState(null);
  const [confirmPassword, setConfimrPassword] = React.useState(null);
  const navigation = useNavigation();
  const [isModalVisible, setModalVisible] = React.useState(null);
  const [isPromotionChecked, setPromotionChecked] = React.useState(null);

  AsyncStorage.getItem('referralCode').then(success => {
    if (success != null) {
      setReferralCode(success);
    } 
  });

  React.useEffect(() => {
    if (props.dataRegister) {
      console.log('Register', props.dataRegister);
      setUsername(props.dataRegister.fullname);
      setEmail(props.dataRegister.email);
    }
  }, [props.dataRegister]);

  const validator = () => {
    if (!username) {
      showRegisterError('Username cannot be empty !', 'error');
      return false;
    }
    // if (!gender) {
    //   showRegisterError('Gender cannot be empty !', 'error');
    //   return false;
    // }
    if (!email) {
      showRegisterError('Email cannot be empty !', 'error');
      return false;
    }
    if (!phone) {
      showRegisterError('Phone cannot be empty !', 'error');
      return false;
    }
    if (!password && !props.dataRegister) {
      showRegisterError('Password cannot be empty !', 'error');
      return false;
    }
    if (!confirmPassword && !props.dataRegister) {
      showRegisterError('Confirm password cannot be empty !', 'error');
      return false;
    }
    if (password !== confirmPassword && !props.dataRegister) {
      showRegisterError('Password not match !', 'error');
      return false;
    }
    if (phone.substring(0, 1) !== '6' && phone.length >= 10 && phone.length <= 13) {
      showRegisterError(
        'Phone number must be include country code eg.6012345679 !',
        'error',
      );
      return false;
    }
    return true;
  };

  const clearForm = () => {
    setUsername(null);
    setEmail(null);
    setConfimrPassword(null);
    setPassword(null);
    setPhone(null);
  };

  const submitForm = () => {
    console.log('data register', props.dataRegister);
    validator() &&
      register(
        {
          username,
          password,
          // password_confirmation: confirmPassword,
          email,
          phone,
          // gender,
          // referralCode,
          // isPromotionChecked,
          // isFromSocialMedia: props.dataRegister ? true : false,
          // picture: props.dataRegister ? props.dataRegister.picture : 'null',
        },
        showRegisterError,
        response => {
          console.warn(response);
          // if (!response.data.result.isActive) {

          let loginWith = 'MANUAL';
          if (props.dataRegister) {
            if (props.dataRegister.loginWith) {
              loginWith = props.dataRegister.loginWith;
            }
          }
          //navigation.navigate(ROUTE_NAMES.LOGIN);
          getOtp({username: response.data.data.email}, showRegisterError, res => {
            if (res.data.succes) {
              navigation.navigate(ROUTE_NAMES.OTP, {
                data: res.data,
                type: 'LOGIN',
              });
            }
          });
          // }
        },
      );
  };

  const disclaimerPopUp = () => {
    Alert.alert(
      'Disclaimer',
      'By providing your personal data to us and/or continuing access to ikama.or.id you declare that you have read and understood our Personal Data Protection Notice and agree to us processing your personal data in accordance with the manner as set out in our Personal Data Protection Notice. Please visit our website at ikama.or.id for more information on the Personal Data Protection Notice.',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'OK',
          onPress: async () => {
            submitForm();
          },
        },
      ],
    );
  };
  const showRegisterError = (message, type) => {
    // setProgressVisible(false);

    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
    });
  };

  const renderInput = (
    placeholder: string,
    iconName: string,
    type: string,
    onChangeText: any,
  ): Object => (
    <Input
      placeholder={placeholder}
      iconName={iconName}
      type={type}
      onChangeText={onChangeText}
    />
  );
  let passPhoneInput = null;
  let passEmailInput = null;
  let passPasswordInput = null;
  let passConfirmPasswordInput = null;
  getApiLevel().then(apiLevel => {
    needsXiaomiWorkaround = apiLevel > 28 && needsXiaomiWorkaround;
    setXiaomi(needsXiaomiWorkaround);
  });

  return (
    <Container>
      {isModalVisible && (
        <Modal>
          <RadioButton
            style={{flex: 0.5, justifyContent: 'flex-end'}}
            selected={gender}
            onSelected={data => {
              setGender(data);
              setModalVisible(false);
            }}
            options={[{id: 1, name: 'Male'}, {id: 2, name: 'Female'}]}
          />
        </Modal>
      )}
      {/* {renderInput('Fullname', 'account-outline', 'text', setUsername)}
      {renderInput('Phone', 'phone', 'telephoneNumber', setPhone)}
      {renderInput('E-mail', 'email-outline', 'emailAddress', setEmail)}
      {renderInput('Password', 'lock-outline', 'password', setPassword)}
      {renderInput(
        'Confirm Password',
        'lock-reset',
        'password',
        setConfimrPassword,
      )} */}
      
       <Input
        placeholder={'Username'}
        iconName={'account-outline'}
        type={'text'}
        value={username}
        blurOnSubmit={false}
        onChangeText={setUsername}
        onSubmitEditing={event => {
          passPhoneInput.focus();
        }}
        returnKeyType={'next'}
      />
      <Input
        placeholder={'Phone e.g. 601112345689'}
        iconName={'phone'}
        type={'telephoneNumber'}
        value={phone}
        blurOnSubmit={false}
        onChangeText={setPhone}
        onSubmitEditing={event => {
          passEmailInput.focus();
        }}
        inputRef={input => {
          passPhoneInput = input;
        }}
        returnKeyType={'next'}
      />
      <Input
        editable={props.dataRegister ? false : true}
        placeholder={'E-mail'}
        iconName={'email-outline'}
        type={'emailAddress'}
        value={email}
        blurOnSubmit={false}
        onChangeText={setEmail}
        onSubmitEditing={event => {
          passPasswordInput.focus();
        }}
        inputRef={input => {
          passEmailInput = input;
        }}
        caretHidden={isXiaomi}
        returnKeyType={'next'}
      />
      {!props.dataRegister && (
        <Input
          placeholder={'Password'}
          iconName={'lock-outline'}
          type={'password'}
          value={password}
          blurOnSubmit={false}
          onChangeText={setPassword}
          onSubmitEditing={event => {
            passConfirmPasswordInput.focus();
          }}
          inputRef={input => {
            passPasswordInput = input;
          }}
          returnKeyType={'next'}
        />
      )}
      {!props.dataRegister && (
        <Input
          placeholder={'Confirm Password'}
          iconName={'lock-reset'}
          type={'password'}
          value={confirmPassword}
          blurOnSubmit={false}
          onChangeText={setConfimrPassword}
          onSubmitEditing={event => validator() && disclaimerPopUp()}
          inputRef={input => {
            passConfirmPasswordInput = input;
          }}
        />
      )}
      {/* <ButtonContent
        afterPress={() =>
          validator() &&
          register(
            {
              username,
              password,
              password_confirmation: confirmPassword,
              email,
              role_id: 2,
            },
            showRegisterError,
          )
        }
        color={appStyles.colors.primaryColor}>
        <DefaultText>SIGN UP</DefaultText>
      </ButtonContent> */}
      {/* <View
        style={{
          flexDirection: 'row',
          marginStart: -10,
          paddingEnd: AppTheme.metrics.largeSize,
          marginBottom: AppTheme.metrics.mediumSize,
        }}>
        <CheckBox
          checked={isPromotionChecked}
          onPress={() => setPromotionChecked(!isPromotionChecked)}
          containerStyle={{
            padding: 0,
            margin: 0,
            justifyContent: 'center',
            alignItems: 'center',
          }}
        />
        <TextTerms>
          I hereby agree to receive promotional SMS, materials, mailers, e-mails
          and telemarketing calls from Beauty2Go
        </TextTerms>
      </View> */}
      <TouchableOpacity
        onPress={() => {
          validator() && disclaimerPopUp();
        }}>
        <ContentContainer color={appStyles.colors.primaryColor}>
          <DefaultText>SIGN UP</DefaultText>
        </ContentContainer>
      </TouchableOpacity>
    </Container>
  );
};

export default SignUp;
