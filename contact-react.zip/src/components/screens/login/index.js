// @flow

import React, {Component} from 'react';
import {
  TouchableOpacity,
  StatusBar,
  Animated,
  FlatList,
  Image,
  View,
  Text,
} from 'react-native';

import styled from 'styled-components';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import env from 'react-native-config';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import SignUpComponent from './components/SignUp';
import LoginComponent from './components/Login';
import {AuthContext} from '../../../context';

import appStyles from '~/styles';

const Container = styled(View)`
  flex: 1;
`;

const Wrapper = styled(View)`
  width: 100%;
  height: 100%;
  position: absolute;
  margin-top: ${({theme}) => theme.metrics.getHeightFromDP('2.5%')}px;
`;

const ContentWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.width}px;
  height: 100%;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const DarkLayer = styled(View)`
  width: 100%;
  height: 100%;
  background-color: ${({theme}) => theme.colors.intermediateDarkLayer};
`;

const Title = styled(Text)`
  font-family: Modesta-Script;
  color: ${({theme}) => theme.colors.defaultWhite};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('11.5%')}px;
`;

const TitleWrapper = styled(View)`
  width: 100%;
  align-items: center;
  justify-content: center;
  margin-vertical: ${({theme}) => theme.metrics.getHeightFromDP('4%')}px;
  margin-top: ${({theme}) => theme.metrics.getHeightFromDP('10%')}px;
`;

const BackgroundImage = styled(Image).attrs({
  source: {uri: 'bg_intro'},
  resizeMode: 'cover',
})`
  position: absolute;
  width: 100%;
  height: 100%;
`;

const NavigationTitleWrapper = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('10%')}px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-end: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
  padding-start: ${({theme}) => 2 * theme.metrics.extraSmallSize}px;
`;

const TextSmall = styled(Text).attrs({
  ellipsizeMode: 'tail',
  numberOfLines: 1,
})`
  font-family: CircularStd-Book;
  color: white;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.0%')}px;
  align-self: center;
`;

const LogoImage = styled(Image).attrs(({image}) => ({
  source: {uri: image}
}))`
  width: ${({theme}) => theme.metrics.getHeightFromDP('18%')}px;
  height: ${({theme}) => theme.metrics.getHeightFromDP('18%')}px;
  margin-top: ${({theme}) => theme.metrics.getHeightFromDP('8%')}px;
  align-self: center;
`;

const MAX_FONT_SIZE = appStyles.metrics.getWidthFromDP('6%');
const MIN_FONT_SIZE = appStyles.metrics.getWidthFromDP('4%');

const LAYOUTS = [
  {Layout: LoginComponent, id: 'login'},
  {Layout: SignUpComponent, id: 'signup'},
];

class Login extends Component {
  _loginFontSize: Object = new Animated.Value(1);
  _signUpFontSize: Object = new Animated.Value(0);
  _flatListRef: Object = {};
  static contextType = AuthContext;

  state = {
    isBackgroundImageLoaded: false,
    dataRegister: null,
    title: 'Log In'
  };
  componentDidMount() {
    this.props.navigation.setOptions({tabBarVisible: false});
  }
  componentDidUpdate(prevProps, prevState){

    if(prevProps.route.params != this.props.route.params){
      if(this.props.route.params.isSignup){
        this.setState({title: 'Sign Up'});
        this.onClickSignUpButton();
      }
    }
  }
  onClickLoginButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 1,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 0,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 0}));
  };

  onClickSignUpButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 0,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 1,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 1}));
  };

  onLoadBackgroundImage = (): void => {
    this.setState({
      isBackgroundImageLoaded: true,
    });
  };

  onFromLoginToRegister = dataRegister => {
    console.log(dataRegister);
    this.onClickSignUpButton();
    this.setState({
      dataRegister,
    });
  };

  renderContent = (): Object => (
    <FlatList
      renderItem={({item}) => {
        const {Layout} = item;

        return (
          <ContentWrapper>
            <Layout
              onFromLoginToRegister={this.onFromLoginToRegister}
              dataRegister={this.state.dataRegister}
            />
          </ContentWrapper>
        );
      }}
      showsHorizontalScrollIndicator={false}
      keyExtractor={item => item.id}
      ref={(ref: any): void => {
        this._flatListRef = ref;
      }}
      scrollEnabled={false}
      data={LAYOUTS}
      pagingEnabled
      horizontal
    />
  );

  render() {
    const {isBackgroundImageLoaded} = this.state;
    const auth = this.context;

    return (
      <Container>
        <StatusBar
          backgroundColor="transparent"
          barStyle="light-content"
          translucent
          animated
        />
        <BackgroundImage onLoad={this.onLoadBackgroundImage} />
        {/* <DarkLayer /> */}
        {isBackgroundImageLoaded && (
          <Wrapper>
            <KeyboardAwareScrollView>
              {/* <TitleWrapper>
                <Image
                  style={{width: 135, height: 150}}
                  source={{
                    uri: 'logonew',
                  }}
                />
                <TextSmall>
                  v{' '}
                  {env.VERSION_NAME_STRING +
                    (env.ENV_NAME == 'DEV' ? ' (dev)' : '')}
                </TextSmall>
              </TitleWrapper> */}
              <View style={{flexDirection: 'column', alignItems: 'center', paddingLeft: 10}}>
                <LogoImage image= {'logonew'}/> 
                <NavigationTitleWrapper>
                  <TouchableOpacity onPress={this.onClickLoginButton}>
                    <Animated.Text
                      style={{
                        paddingBottom: appStyles.metrics.getHeightFromDP('1.5%'),
                        paddingRight: appStyles.metrics.getHeightFromDP('4%'),
                        paddingLeft: appStyles.metrics.getHeightFromDP('3%'),
                        paddingTop: appStyles.metrics.getHeightFromDP('3%'),
                        fontFamily: 'CircularStd-Medium',
                        color: this._loginFontSize.interpolate({
                          inputRange: [0, 1],
                          outputRange: [
                            appStyles.colors.white,
                            appStyles.colors.white,
                          ],
                          extrapolate: 'clamp',
                        }),
                        fontSize: this._loginFontSize.interpolate({
                          inputRange: [0, 1],
                          outputRange: [MIN_FONT_SIZE, MAX_FONT_SIZE],
                          extrapolate: 'clamp',
                        }),
                      }}>
                      {this.state.title}
                    </Animated.Text>
                  </TouchableOpacity>
                  {/* <TouchableOpacity onPress={this.onClickSignUpButton}>
                    <Animated.Text
                      style={{
                        paddingBottom: appStyles.metrics.getHeightFromDP('1.5%'),
                        paddingLeft: appStyles.metrics.getHeightFromDP('4%'),
                        paddingTop: appStyles.metrics.getHeightFromDP('1%'),
                        fontFamily: 'CircularStd-Medium',
                        color: this._signUpFontSize.interpolate({
                          inputRange: [0, 1],
                          outputRange: [
                            appStyles.colors.grayTitle,
                            appStyles.colors.grayTitle,
                          ],
                          extrapolate: 'clamp',
                        }),
                        fontSize: this._signUpFontSize.interpolate({
                          inputRange: [0, 1],
                          outputRange: [MIN_FONT_SIZE, MAX_FONT_SIZE],
                          extrapolate: 'clamp',
                        }),
                      }}>
                      Daftar
                    </Animated.Text>
                  </TouchableOpacity> */}
                </NavigationTitleWrapper>
              </View>
              {this.renderContent()}
            </KeyboardAwareScrollView>
          </Wrapper>
        )}
      </Container>
    );
  }
}

export default Login;
