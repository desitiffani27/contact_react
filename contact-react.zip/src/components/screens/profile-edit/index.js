/* eslint-disable react/no-did-mount-set-state */
import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  TouchableOpacity,
  Alert,
  BackHandler,
  FlatList,
  PermissionsAndroid 
} from 'react-native';

import {Creators as ProfileEditCreators} from '~/store/ducks/profile';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {showMessage} from 'react-native-flash-message';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import {ROUTE_NAMES, CONSTANTS} from '~/utils/CONSTANTS';
import styles from './ProfileEditStyles';
import CustomTextInput from './components/CustomTextInput';
import moment from 'moment';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import {HeaderRigthDoneButton} from '~/routes/headerUtils';
import {HeaderBackButton} from '@react-navigation/stack';
import Loading from '~/components/common/Loading';
import ImageResizer from 'react-native-image-resizer';
import styled from 'styled-components';
import CustomTab from '~/components/common/CustomTab';
import AppTheme from '~/styles';

let scrollView;
class ProfileEdit extends Component {
  oldState = null;
  state = {
    doScroll: false,

    //personal_particular
    photo: null,
    nama: null,
    noAnggota: null,
    angkatan: null,
    ikamaTerdekat: null,
    suku: null,
    agama: null,
    tempatLahir: null,
    tanggalLahir: null,
    jenisKelamin: null,
    golDarah: null,
    status: null,

    //contact
    telp: null,
    wasap: null,
    noWhatsapp: null,
    facebook: null,
    instagram: null,
    linkedin: null,

    //origin
    asalProvinsi: null,
    asalKota: null,
    asalKecamatan: null,
    asalDesa: null,
    asalAlamat: null,
    asalKodePos: null,

    //domicile
    negara: null,
    provinsi: null,
    kota: null,
    kecamatan: null,
    desa: null,
    alamat: null,
    kodePos: null,

    setuju: 'Ya',

    pekerjaan: [],
    bisnis: [],
    interest: [],
    other: [],

    avatarSource: null,
    isShowImagePicker: false,
    isShowDatePicker: false,
    indexTypeSelected: 0,

    dataProfile: {},
    
    dataMaster: {
      "ikama-terdekat" : [],
      "negara" : [],
      "provinsi" : [],
      "kota" : [],
      "kecamatan": [],
      "desa": [],
      "sektor-pekerjaan": [],
      "instansi": [],
      "jenis-usaha": []
    },

    dataListGolDarah: [{id: 'A', name: 'A'}, {id: 'B', name: 'B'}, {id: 'AB', name: 'AB'}, {id: 'O', name: 'O'}]
  };

  componentDidMount() {
    const {route, getEditProfileRequest} = this.props;
    const {[CONSTANTS.DATA]: dataProfile} = route.params;

    const isValidURL = (str) => {
      var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
      '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
      '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
      '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
      '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
      '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
      return !!pattern.test(str);
    };

    this.props.navigation.setOptions({
      headerLeft: props => (
        <HeaderBackButton {...props} onPress={this.handleBackButton} />
      ),
    });
    
    BackHandler.addEventListener('hardwareBackPress', this.actionBack);
    console.log(dataProfile)

    getEditProfileRequest(data => {
      this.setState(
        {
          photo: isValidURL(data.profile.foto_profil) ? data.profile.foto_profil : "https://alumni.ikama.or.id/assets/attachment/alumni/"+data.profile.foto_profil,
          nama: data.profile.nama,
          noAnggota: data.profile.no_anggota,
          angkatan: data.profile.angkatan,
          ikamaTerdekat: {wilayah_id: data.profile.ikama_terdekat, wilayah: dataProfile.profile.ikama_terdekat},
          suku: data.profile.suku,
          agama: data.profile.agama,
          tempatLahir: data.profile.tempat_lahir,
          tanggalLahir: data.profile.tanggal_lahir ? moment(data.profile.tanggal_lahir) : null,
          jenisKelamin: data.profile.jenis_kelamin,
          golDarah: this.state.dataListGolDarah[data.profile.gol_darah-1].name,
          status: data.profile.status,
      
          //contact
          telp: data.profile.telp,
          noWhatsapp: data.profile.no_whatsapp,
          facebook: data.profile.facebook,
          instagram: data.profile.instagram,
          linkedin: data.profile.linkedin,
      
          //origin
          asalProvinsi: {id: data['asal-daerah'].provinsi, name: dataProfile['asal-daerah'].provinsi},
          asalKota: {id: data['asal-daerah'].kota, name: dataProfile['asal-daerah'].kota},
          asalKecamatan: {id: data['asal-daerah'].kecamatan, name: dataProfile['asal-daerah'].kecamatan},
          asalDesa: {id: data['asal-daerah'].desa, name: dataProfile['asal-daerah'].desa},
          asalAlamat: data['asal-daerah'].daerah,
          asalKodePos: data['asal-daerah'].kode_pos,
      
          //domicile
          negara: {id: data.domisili.negara, name: dataProfile.domisili.negara},
          provinsi: {id: data.domisili.provinsi, name: dataProfile.domisili.provinsi},
          kota: {id: data.domisili.kota, name: dataProfile.domisili.kota},
          kecamatan: {id: data.domisili.kecamatan, name: dataProfile.domisili.kecamatan},
          desa: {id: data.domisili.desa, name: dataProfile.domisili.desa},
          alamat: data.domisili.daerah,
          kodePos: data.domisili.kode_pos,
      
          pekerjaan: this.initStatePekerjaan(data.pekerjaan, dataProfile.pekerjaan),
          bisnis: this.initStateBisnis(data.bisnis, dataProfile.bisnis),
          interest: dataProfile.interest,
          other: dataProfile.other,
  
          dataMaster: data.master,

          dataProfile: dataProfile
        },
        () => {
          this.oldState = this.state;
          this.renderHeaderRightButton(this.state === this.oldState);
        },
      );
    });
  }

  initStatePekerjaan = (pekerjaanIds, pekerjaanLabels) => {
    var pekerjaan = [];
    for (var i=0; i < pekerjaanIds.length; i++){
      pekerjaan.push({
        id: pekerjaanIds[i].id,
        sektor: pekerjaanIds[i].sektor_id,
        provinsi_job: pekerjaanIds[i].provinsi,
        kota_job: pekerjaanIds[i].kota,
        pekerjaan: pekerjaanIds[i].pekerjaan_id,
        nama_perusahaan_job: pekerjaanIds[i].nama_perusahaan,
        jabatan_job: pekerjaanIds[i].jabatan,

        sektor_name: pekerjaanLabels[i].sektor_id,
        provinsi_name: pekerjaanLabels[i].provinsi,
        kota_name: pekerjaanLabels[i].kota,
        pekerjaan_name: pekerjaanLabels[i].pekerjaan_id,
        idx: i
      });
    }
    return pekerjaan;
  };

  initStateBisnis = (bisnisIds, bisnisLabels) => {
    var bisnis = [];
    for (var i=0; i < bisnisIds.length; i++){
      bisnis.push({
        id: bisnisIds[i].id,
        bidang: bisnisIds[i].bidang,
        jenis_usaha: bisnisIds[i].jenis_usaha,
        provinsi_bisnis: bisnisIds[i].provinsi,
        kota_bisnis: bisnisIds[i].kota,
        nama_perusahaan_bisnis: bisnisIds[i].nama_perusahaan,
        alamat_bisnis: bisnisIds[i].alamat,
        medsos: bisnisIds[i].nama_akun_medsos,
        brand: bisnisIds[i].brand,
        jabatan_bisnis: bisnisIds[i].jabatan,

        jenis_usaha_name: bisnisLabels[i].jenis_usaha,
        provinsi_name: bisnisLabels[i].provinsi,
        kota_name: bisnisLabels[i].kota,
        idx: i
      });
    }
    return bisnis;
  };

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.actionBack);
  }

  actionBack = () => {
    this.handleBackButton();
    return true;
  };

  handleBackButton = () => {
    if (this.state !== this.oldState) {
      Alert.alert(
        'Confirmation',
        'Are you sure want to back without save changed?',
        [
          {
            text: 'Cancel',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel',
          },
          {
            text: 'Go Back',
            onPress: () => {
              this.props.navigation.goBack();
            },
          },
        ],
      );
    } else {
      this.props.navigation.goBack();
    }
  };

  renderHeaderRightButton = disable => {
    this.props.navigation.setOptions({
      headerRight: () => {
        return (
          <HeaderRigthDoneButton
            disable={disable}
            onPress={() => {
              const {postProfileEditRequest, postProfilePictureEditRequest} = this.props;
                this.validator() &&
                postProfileEditRequest({
                  personal_particular: {
                    nama: this.state.nama,
                    angkatan: this.state.angkatan,
                    ikama_terdekat: this.state.ikamaTerdekat.wilayah_id,
                    suku: this.state.suku,
                    agama: this.state.agama,
                    tempat_lahir: this.state.tempatLahir,
                    tanggal_lahir: this.state.tanggalLahir
                      ? this.state.tanggalLahir.format('MM/DD/YYYY')
                      : null,
                    jenis_kelamin: this.state.jenisKelamin,
                    gol_darah: this.state.golDarah,
                    status: this.state.status
                  },
                  contact: {
                    telp: this.state.telp,
                    wasap: 1,
                    no_whatsapp: this.state.noWhatsapp,
                    facebook: this.state.facebook,
                    instagram: this.state.instagram,
                    linkedin: this.state.linkedin
                  },
                  origin: {
                    asal_provinsi: this.state.asalProvinsi.id,
                    asal_kota: this.state.asalKota.id,
                    asal_kecamatan: this.state.asalKecamatan.id,
                    asal_desa: this.state.asalDesa.id,
                    asal_alamat: this.state.asalAlamat,
                    asal_kode_pos: this.state.asalKodePos
                  },
                  domicile: {
                    negara: this.state.negara.id,
                    provinsi: this.state.provinsi.id,
                    kota: this.state.kota.id,
                    kecamatan: this.state.kecamatan.id,
                    desa: this.state.desa.id,
                    alamat: this.state.alamat,
                    kode_pos: this.state.kodePos
                  },
                  setuju: this.state.setuju,
                  pekerjaan: this.state.pekerjaan,
                  bisnis: this.state.bisnis,
                  interest: this.state.interest,
                  other: this.state.other
                }, () =>{
                  if(this.state.avatarSource != null){
                    postProfilePictureEditRequest(this.state.avatarSource);
                  }
                });
            }}
          />
        );
      },
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.profileEditRequest.dataEdit !==
      prevProps.profileEditRequest.dataEdit
    ) {
      const {route, navigation} = this.props;
      const {[CONSTANTS.FUNCTION]: onProfileChanged} = route.params;
      onProfileChanged(this.props.profileEditRequest.dataEdit);
      navigation.goBack();
    }

    if (this.state !== prevState) {
      this.renderHeaderRightButton(this.state === this.oldState);
    }
  }

  options = {
    mediaType: 'photo',
    maxWidth: 480,
    maxHeight: 480,
    storageOptions: {
      skipBackup: true,
      path: 'images',
    },
  };

  responseImagePicker = response => {
    this.setState({isShowImagePicker: false});
    console.log('Response = ', response);

    if (response.didCancel) {
      console.log('User cancelled image picker');
    } else if (response.error) {
      console.log('ImagePicker Error: ', response.error);
      this.showEditProfileError('ImagePicker Error: '+ response.error, 'error');
    } else {
      if(response.assets){
        this.setState({
          avatarSource: response.assets[0],
        });
      }else{
        
      }
      
      // if (response.originalRotation === 90) {
      //   rotation = 90;
      // } else if (response.originalRotation === 270) {
      //   rotation = -90;
      // }
      // ImageResizer.createResizedImage(
      //   response.uri,
      //   480,
      //   480,
      //   'JPEG',
      //   80,
      //   rotation,
      // )
      //   .then(resize => {
      //     console.log('> Resize', resize);
      //     this.setState({
      //       avatarSource: resize,
      //     });
      //   })
      //   .catch(err => {
      //     console.log(err);
      //   });
    }
  };
  validator = () => {
    console.log('validator');
    console.log('photo', this.state.photo);
    if (!this.state.avatarSource && !this.state.photo) {
      this.showEditProfileError('Profile Picture cannot be empty !', 'error');
      return false;
    }
    if (!this.state.nama) {
      this.showEditProfileError('Nama tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.angkatan) {
      this.showEditProfileError('Angkatan tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.ikamaTerdekat) {
      this.showEditProfileError('IKAMA Daerah tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.suku) {
      this.showEditProfileError('Suku tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.agama) {
      this.showEditProfileError('Agama tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.tempatLahir) {
      this.showEditProfileError('Tempat Lahir tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.tanggalLahir) {
      this.showEditProfileError('Tanggal Lahir tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.jenisKelamin) {
      this.showEditProfileError('Jenis Kelamin tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.asalProvinsi) {
      this.showEditProfileError('Asal Provinsi tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.asalKota) {
      this.showEditProfileError('Asal Kota tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.asalKecamatan) {
      this.showEditProfileError('Asal Kecamatan tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.asalDesa) {
      this.showEditProfileError('Asal Kelurahan/Desa tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.negara) {
      this.showEditProfileError('Negara Domisili tidak boleh kosong !', 'error');
      return false;
    }
    if (this.state.negara.id == 102){
      if (!this.state.provinsi) {
        this.showEditProfileError('Provinsi Domisili tidak boleh kosong !', 'error');
        return false;
      }
      if (!this.state.kota) {
        this.showEditProfileError('Kota Domisili tidak boleh kosong !', 'error');
        return false;
      }
      if (!this.state.kecamatan) {
        this.showEditProfileError('Kecamatan Domisili tidak boleh kosong !', 'error');
        return false;
      }
      if (!this.state.desa) {
        this.showEditProfileError('Kelurahan/Desa Domisili tidak boleh kosong !', 'error');
        return false;
      }
    }
    if (!this.state.alamat) {
      this.showEditProfileError('Alamat Domisili tidak boleh kosong !', 'error');
      return false;
    }
    if (!this.state.telp) {
      this.showEditProfileError('No. HP tidak boleh kosong !', 'error');
      return false;
    }
   
    return true;
  };
  showEditProfileError = (message, type) => {
    // setProgressVisible(false);

    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
    });
  };
  responseDatePicker = (event, date) => {
    console.log(date);
    this.setState({isShowDatePicker: false});
    if (date) {
      this.setState({tanggalLahir: moment(date)});
    }
  };

  onDoneState = state => {
    const oldId = this.state.state ? this.state.state.id : null;
    if (state.id !== oldId) {
      this.setState({state, city: null});
    }
  };

  onDoneCity = city => {
    this.setState({city});
  };

  onDoneGender = gender => {
    this.setState({jenisKelamin: gender == 1 ? 'Laki-laki' : 'Perempuan'});
  };

  onDoneGolonganDarah = golDarah => {
    this.setState({golDarah});
  };

  onDoneStatus = status => {
    console.log('> status', status);
    this.setState({status: status == 2 ? 'Sudah Menikah' : 'Belum Menikah'});
  };

  onDoneSeenByOther = isCanSeen => {
    console.log('> isCanSeen', isCanSeen);
    this.setState({setuju: isCanSeen == 1 ? 'Ya' : 'Tidak'});
  };

  onDoneAngkatan = angkatan => {
    this.setState({angkatan: angkatan+""});
  };

  onDoneIkamaDaerah = selectedIkamaTerdekat => { //in submit need to get id
    this.setState({ikamaTerdekat: selectedIkamaTerdekat});
  };

  onDoneAsalProvinsi = asalProvinsi => { //in submit need to get id
    const oldId = this.state.asalProvinsi ? this.state.asalProvinsi.id : null;
    if (asalProvinsi.id !== oldId) {
      this.setState({asalProvinsi, asalKota: null, asalKecamatan: null, asalDesa: null});
    }
  };

  onDoneAsalKota = asalKota => { //in submit need to get id
    const oldId = this.state.asalKota ? this.state.asalKota.id : null;
    if (asalKota.id !== oldId) {
      this.setState({asalKota, asalKecamatan: null, asalDesa: null});
    }
  };

  onDoneAsalKecamatan = asalKecamatan => { //in submit need to get id
    const oldId = this.state.asalKecamatan ? this.state.asalKecamatan.id : null;
    if (asalKecamatan.id !== oldId) {
      this.setState({asalKecamatan, asalDesa: null});
    }
  };

  onDoneAsalDesa = asalDesa => { //in submit need to get id
    this.setState({asalDesa});
  };

  onDoneAsalAlamat = asalAlamat => {
    this.setState({asalAlamat});
  };

  onDoneNegara = negara => { //in submit need to get id
    this.setState({negara});
  };

  onDoneProvinsi = provinsi => { //in submit need to get id
    const oldId = this.state.provinsi ? this.state.provinsi.id : null;
    if (provinsi.id !== oldId) {
      this.setState({provinsi, kota: null, kecamatan: null, desa: null});
    }
  };

  onDoneKota = kota => { //in submit need to get id
    const oldId = this.state.kota ? this.state.kota.id : null;
    if (kota.id !== oldId) {
      this.setState({kota, kecamatan: null, desa: null});
    }
  };

  onDoneKecamatan = kecamatan => { //in submit need to get id
    const oldId = this.state.kecamatan ? this.state.kecamatan.id : null;
    if (kecamatan.id !== oldId) {
      this.setState({kecamatan, desa: null});
    }
  };

  onDoneDesa = desa => { //in submit need to get id
    this.setState({desa});
  };

  onDoneAlamat = alamat => {
    this.setState({alamat});
  };

  onDoneSektorPekerjaan = selectedSektor => {
    var statePekerjaan = this.state.pekerjaan;
    var pekerjaan = statePekerjaan[selectedSektor.idx];
    pekerjaan.sektor = selectedSektor.sektor_id;
    pekerjaan.sektor_name = selectedSektor.nama;
    statePekerjaan[selectedSektor.idx] = pekerjaan;
    this.setState({pekerjaan: statePekerjaan});
  };

  onDoneProvinsiPekerjaan = selectedProvinsi => {
    var statePekerjaan = this.state.pekerjaan;
    var pekerjaan = statePekerjaan[selectedProvinsi.idx];
    pekerjaan.provinsi_job = selectedProvinsi.id;
    pekerjaan.provinsi_name = selectedProvinsi.name;
    pekerjaan.kota = null;
    pekerjaan.kota_name = null;
    statePekerjaan[selectedProvinsi.idx] = pekerjaan;
    this.setState({pekerjaan: statePekerjaan});
  };

  onDoneKotaPekerjaan = selectedKota => {
    var statePekerjaan = this.state.pekerjaan;
    var pekerjaan = statePekerjaan[selectedKota.idx];
    pekerjaan.kota_job = selectedKota.id;
    pekerjaan.kota_name = selectedKota.name;
    statePekerjaan[selectedKota.idx] = pekerjaan;
    this.setState({pekerjaan: statePekerjaan});
  };

  onDonePekerjaan = selectedInstansi => {
    var statePekerjaan = this.state.pekerjaan;
    var pekerjaan = statePekerjaan[selectedInstansi.idx];
    pekerjaan.pekerjaan = selectedInstansi.id_pekerjaan;
    pekerjaan.pekerjaan_name = selectedInstansi.nama_pekerjaan;
    statePekerjaan[selectedInstansi.idx] = pekerjaan;
    this.setState({pekerjaan: statePekerjaan});
  };

  onDoneJenisUsahaBisnis = selectedJenisUsaha => {
    var stateBisnis = this.state.bisnis;
    var bisnis = stateBisnis[selectedJenisUsaha.idx];
    bisnis.jenis_usaha = selectedJenisUsaha.id;
    bisnis.jenis_usaha_name = selectedJenisUsaha.code;
    stateBisnis[selectedJenisUsaha.idx] = bisnis;
    this.setState({bisnis: stateBisnis});
  };

  onDoneProvinsiBisnis = selectedProvinsi => {
    var stateBisnis = this.state.bisnis;
    var bisnis = stateBisnis[selectedProvinsi.idx];
    bisnis.provinsi_bisnis = selectedProvinsi.id;
    bisnis.provinsi_name = selectedProvinsi.name;
    bisnis.kota = null;
    bisnis.kota_name = null;
    stateBisnis[selectedProvinsi.idx] = bisnis;
    this.setState({bisnis: stateBisnis});
  };

  onDoneKotaBisnis = selectedKota => {
    var stateBisnis = this.state.bisnis;
    var bisnis = stateBisnis[selectedKota.idx];
    bisnis.kota_bisnis = selectedKota.id;
    bisnis.kota_name = selectedKota.name;
    stateBisnis[selectedKota.idx] = bisnis;
    this.setState({bisnis: stateBisnis});
  };

  onTypeChange = (indexTypeSelected: number): void => {
    this.setState({indexTypeSelected});
  };

  renderFormPekerjaan = (item, index) => {
    return (
      <View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <Text style={{
            textDecorationLine: 'underline', 
            fontSize: 16, 
            fontWeight: 'bold', 
            marginBottom: AppTheme.metrics.smallSize}}>PEKERJAAN {index+1}
          </Text>

          {index > 0 && (
            <TouchableOpacity
              onPress={() => { this.onDeletePekerjaan(index) }}>
              <View style={{flexDirection: 'row'}}>
                  <MaterialIcon
                    color={AppTheme.colors.red}
                    name={'delete'}
                    size={20}
                  />
                <Text style={{color: AppTheme.colors.red}}>Delete</Text>
              </View>
            </TouchableOpacity>
          )}

          {index == 0 && (
            <TouchableOpacity
              onPress={() => { this.onAddPekerjaan() }}>
              <View style={{
                flexDirection: 'row', 
                backgroundColor: AppTheme.colors.green,
                paddingHorizontal: AppTheme.metrics.mediumSize,
                paddingVertical: AppTheme.metrics.extraSmallSize,
                borderRadius: 3
                }}>
                  <MaterialIcon
                    color={AppTheme.colors.white}
                    name={'add'}
                    size={20}
                  />
                <Text style={{color: AppTheme.colors.white}}>Tambah</Text>
              </View>
            </TouchableOpacity>
          )}
        </View>

        <CustomTextInput
          title={'*Sektor'}
          placeholder={'-- Pilih Sektor --'}
          value={this.state.pekerjaan[index].sektor_name ? this.state.pekerjaan[index].sektor_name : null}
          onPress={() => {
            this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
              [CONSTANTS.TITLE]: 'Sektor',
              [CONSTANTS.FUNCTION]: this.onDoneSektorPekerjaan.bind(this),
              [CONSTANTS.DATA]: this.state.dataMaster["sektor-pekerjaan"],
              [CONSTANTS.TYPE]: CONSTANTS.TYPE_SEKTOR_PEKERJAAN,
              [CONSTANTS.ADDITIONAL_PARAMS]: index
            });
          }}
        />

        <CustomTextInput
          title={'*Provinsi'}
          placeholder={'-- Pilih Provinsi --'}
          value={this.state.pekerjaan[index].provinsi_name ? this.state.pekerjaan[index].provinsi_name : null}
          onPress={() => {
            this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
              [CONSTANTS.TITLE]: 'Provinsi',
              [CONSTANTS.FUNCTION]: this.onDoneProvinsiPekerjaan.bind(this),
              [CONSTANTS.DATA]: this.state.dataMaster.provinsi,
              [CONSTANTS.TYPE]: CONSTANTS.TYPE_PROVINSI,
              [CONSTANTS.ADDITIONAL_PARAMS]: index
            });
          }}
        />

        {this.state.pekerjaan[index].provinsi_job && (
          <CustomTextInput
            title={'*Kota / Kabupaten'}
            placeholder={'-- Pilih Kota / Kabupaten --'}
            value={this.state.pekerjaan[index].kota_name ? this.state.pekerjaan[index].kota_name : null}
            onPress={() => {
              this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                [CONSTANTS.TITLE]: 'Kota / Kabupaten',
                [CONSTANTS.FUNCTION]: this.onDoneKotaPekerjaan.bind(this),
                [CONSTANTS.DATA]: this.state.pekerjaan[index],
                [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_CITY,
                [CONSTANTS.PARAMS]: this.state.pekerjaan[index].provinsi_job,
                [CONSTANTS.ADDITIONAL_PARAMS]: index,
              });
            }}
          />
        )}

        <CustomTextInput
          title={'*Pekerjaan'}
          placeholder={'-- Pilih Pekerjaan --'}
          value={this.state.pekerjaan[index].pekerjaan_name ? this.state.pekerjaan[index].pekerjaan_name : null}
          onPress={() => {
            this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
              [CONSTANTS.TITLE]: 'Pekerjaan',
              [CONSTANTS.FUNCTION]: this.onDonePekerjaan.bind(this),
              [CONSTANTS.DATA]: this.state.dataMaster.instansi,
              [CONSTANTS.TYPE]: CONSTANTS.TYPE_INSTANSI,
              [CONSTANTS.ADDITIONAL_PARAMS]: index,
            });
          }}
        />

        <CustomTextInput
          title={'*Nama Perusahaan'}
          value={this.state.pekerjaan[index].nama_perusahaan_job ? this.state.pekerjaan[index].nama_perusahaan_job : null}
          onChangeText={text => {
            var statePekerjaan = this.state.pekerjaan;
            statePekerjaan[index].nama_perusahaan_job = text;
            this.setState({pekerjaan: statePekerjaan});
          }}
        />

        <CustomTextInput
          title={'*Jabatan'}
          value={this.state.pekerjaan[index].jabatan_job ? this.state.pekerjaan[index].jabatan_job : null}
          onChangeText={text => {
            var statePekerjaan = this.state.pekerjaan;
            statePekerjaan[index].jabatan_job = text;
            this.setState({pekerjaan: statePekerjaan});
          }}
        />
      </View>
    );
  };

  onDeletePekerjaan = (index) => {
    Alert.alert(
      'Confirmation',
      'Apakah anda yakin ingin menghapus pekerjaan ini?',
      [
        {
          text: 'Batal',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Ya',
          onPress: () => {
            this.setState({
              pekerjaan: this.state.pekerjaan.filter(i => this.state.pekerjaan.indexOf(i) !== index),
            });
          },
        },
      ],
    );
  };

  onAddPekerjaan = () => {
    this.setState({
      pekerjaan: [...this.state.pekerjaan, {id: -99}],
      doScroll: true
    });
  };

  renderFormBisnis = (item, index) => {
    return (
      <View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <Text style={{
            textDecorationLine: 'underline', 
            fontSize: 16, 
            fontWeight: 'bold', 
            marginBottom: AppTheme.metrics.smallSize}}>BISNIS {index+1}
          </Text>

          {index > 0 && (
            <TouchableOpacity
              onPress={() => { this.onDeleteBisnis(index) }}>
              <View style={{flexDirection: 'row'}}>
                  <MaterialIcon
                    color={AppTheme.colors.red}
                    name={'delete'}
                    size={20}
                  />
                <Text style={{color: AppTheme.colors.red}}>Delete</Text>
              </View>
            </TouchableOpacity>
          )}

          {index == 0 && (
            <TouchableOpacity
              onPress={() => { this.onAddBisnis() }}>
              <View style={{
                flexDirection: 'row', 
                backgroundColor: AppTheme.colors.green,
                paddingHorizontal: AppTheme.metrics.mediumSize,
                paddingVertical: AppTheme.metrics.extraSmallSize,
                borderRadius: 3
                }}>
                  <MaterialIcon
                    color={AppTheme.colors.white}
                    name={'add'}
                    size={20}
                  />
                <Text style={{color: AppTheme.colors.white}}>Tambah</Text>
              </View>
            </TouchableOpacity>
          )}
        </View>

        <CustomTextInput
          title={'*Bidang'}
          value={this.state.bisnis[index].bidang ? this.state.bisnis[index].bidang : null}
          onChangeText={text => {
            var stateBisnis = this.state.bisnis;
            stateBisnis[index].bidang = text;
            this.setState({bisnis: stateBisnis});
          }}
        />

        <CustomTextInput
          title={'*Jenis Usaha'}
          placeholder={'-- Pilih Jenis Usaha --'}
          value={this.state.bisnis[index].jenis_usaha_name ? this.state.bisnis[index].jenis_usaha_name : null}
          onPress={() => {
            this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
              [CONSTANTS.TITLE]: 'Jenis Usaha',
              [CONSTANTS.FUNCTION]: this.onDoneJenisUsahaBisnis.bind(this),
              [CONSTANTS.DATA]: this.state.dataMaster["jenis-usaha"],
              [CONSTANTS.TYPE]: CONSTANTS.TYPE_JENIS_USAHA,
              [CONSTANTS.ADDITIONAL_PARAMS]: index
            });
          }}
        />

        <CustomTextInput
          title={'*Provinsi'}
          placeholder={'-- Pilih Provinsi --'}
          value={this.state.bisnis[index].provinsi_name ? this.state.bisnis[index].provinsi_name : null}
          onPress={() => {
            this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
              [CONSTANTS.TITLE]: 'Provinsi',
              [CONSTANTS.FUNCTION]: this.onDoneProvinsiBisnis.bind(this),
              [CONSTANTS.DATA]: this.state.dataMaster.provinsi,
              [CONSTANTS.TYPE]: CONSTANTS.TYPE_PROVINSI,
              [CONSTANTS.ADDITIONAL_PARAMS]: index
            });
          }}
        />

        {this.state.bisnis[index].provinsi_bisnis && (
          <CustomTextInput
            title={'*Kota / Kabupaten'}
            placeholder={'-- Pilih Kota / Kabupaten --'}
            value={this.state.bisnis[index].kota_name ? this.state.bisnis[index].kota_name : null}
            onPress={() => {
              this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                [CONSTANTS.TITLE]: 'Kota / Kabupaten',
                [CONSTANTS.FUNCTION]: this.onDoneKotaBisnis.bind(this),
                [CONSTANTS.DATA]: this.state.bisnis[index],
                [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_CITY,
                [CONSTANTS.PARAMS]: this.state.bisnis[index].provinsi_bisnis,
                [CONSTANTS.ADDITIONAL_PARAMS]: index,
              });
            }}
          />
        )}  

        <CustomTextInput
          title={'*Nama Perusahaan'}
          value={this.state.bisnis[index].nama_perusahaan_bisnis ? this.state.bisnis[index].nama_perusahaan_bisnis : null}
          onChangeText={text => {
            var stateBisnis = this.state.bisnis;
            stateBisnis[index].nama_perusahaan_bisnis = text;
            this.setState({bisnis: stateBisnis});
          }}
        />

        <CustomTextInput
          title={'*Alamat'}
          value={this.state.bisnis[index].alamat_bisnis ? this.state.bisnis[index].alamat_bisnis : null}
          onChangeText={text => {
            var stateBisnis = this.state.bisnis;
            stateBisnis[index].alamat_bisnis = text;
            this.setState({bisnis: stateBisnis});
          }}
        />

        <CustomTextInput
          title={'*Nama akun medsos'}
          value={this.state.bisnis[index].medsos ? this.state.bisnis[index].medsos : null}
          onChangeText={text => {
            var stateBisnis = this.state.bisnis;
            stateBisnis[index].medsos = text;
            this.setState({bisnis: stateBisnis});
          }}
        />

        <CustomTextInput
          title={'*Nama brand'}
          value={this.state.bisnis[index].brand ? this.state.bisnis[index].brand : null}
          onChangeText={text => {
            var stateBisnis = this.state.bisnis;
            stateBisnis[index].brand = text;
            this.setState({bisnis: stateBisnis});
          }}
        />

        <CustomTextInput
          title={'*Jabatan'}
          value={this.state.bisnis[index].jabatan_bisnis ? this.state.bisnis[index].jabatan_bisnis : null}
          onChangeText={text => {
            var stateBisnis = this.state.bisnis;
            stateBisnis[index].jabatan_bisnis = text;
            this.setState({bisnis: stateBisnis});
          }}
        />
      </View>
    );
  };

  onDeleteBisnis = (index) => {
    Alert.alert(
      'Confirmation',
      'Apakah anda yakin ingin menghapus bisnis ini?',
      [
        {
          text: 'Batal',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Ya',
          onPress: () => {
            this.setState({
              bisnis: this.state.bisnis.filter(i => this.state.bisnis.indexOf(i) !== index),
            });
          },
        },
      ],
    );
  };

  onAddBisnis = () => {
    this.setState({
      bisnis: [...this.state.bisnis, {id: -99}],
      doScroll: true
    });
  };

  checkMustDoScroll = () => {
    if (this.state.doScroll){
      scrollView.scrollToEnd({ animated: true });
      this.setState({doScroll: false});
    }
  };

  initDataAngkatan = () => {
    var angkatanYears = moment().diff('1994-01-01', 'years');
    var angkatan = [];
    for (var i=1; i <= angkatanYears; i++){
      angkatan.push({id: i, name: i+""});
    }
    return angkatan;
  };

  showImagePickerDialog = () => {
    const requestCameraPermission = async () => {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          {
            title: "App Camera Permission",
            message:"App needs access to your camera ",
            buttonNeutral: "Ask Me Later",
            buttonNegative: "Cancel",
            buttonPositive: "OK"
          }
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          launchCamera(this.options, this.responseImagePicker)
        } else {
          console.log("Camera permission denied");
        }
      } catch (err) {
        console.log(err);
      }
    };

    Alert.alert(
      '',
      'Pilihan upload',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Camera',
          onPress: () => {
            requestCameraPermission()
          },
        },
        {
          text: 'Gallery',
          onPress: () => {
            launchImageLibrary(this.options, this.responseImagePicker)
          },
        },
      ],
    );
  };

  render() {
    const editTabs = [
      {id: 'first', title: 'Data Pribadi'},
      {id: 'second', title: 'Kontak'},
      {id: 'third', title: 'Asal Daerah'},
      {id: 'fourth', title: 'Domisili'},
      {id: 'fifth', title: 'Pekerjaan'},
      {id: 'sixth', title: 'Bisnis'},
      {id: 'seventh', title: 'Ketertarikan'},
      {id: 'eight', title: 'Lain-lain'},
    ];
    const angkatan = this.initDataAngkatan();

    if (this.props.profileEditRequest.loading) {
      return <Loading />;
    }
    
    return (
      <ScrollView 
        ref={ref => { scrollView = ref }}
        onContentSizeChange={() => this.checkMustDoScroll() }>
        <View style={{flex: 1}}>
          {/* Modal */}
          {this.state.isShowDatePicker && (
            <DateTimePicker
              value={
                this.state.birthdate
                  ? this.state.birthdate.toDate()
                  : new Date()
              }
              mode={'date'}
              display="default"
              onChange={this.responseDatePicker}
            />
          )}

          <CustomTab
            onChangeMenuIndex={index => this.onTypeChange(index)}
            contentWidth={AppTheme.metrics.width}
            data={editTabs}
            theme="white"
          />

          {this.state.indexTypeSelected == 0 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <TouchableOpacity
                activeOpacity={0.7}
                onPress={() => {
                  this.showImagePickerDialog();
                }}>
                <View style={styles.containerAvatar}>
                  <Image
                    defaultSource={{uri: 'no_avatar'}}
                    source={{
                      uri: this.state.avatarSource
                        ? this.state.avatarSource.uri
                        : this.state.photo,
                    }}
                    style={styles.imageAvatar}
                  />
                  <Text style={styles.textChangeImage}>Ubah Foto Profil</Text>
                </View>
              </TouchableOpacity>
              <CustomTextInput
                title={'*Fullname'}
                placeholder={'Richardo Charles'}
                value={this.state.nama}
                onChangeText={nama => {
                  this.setState({nama});
                }}
              />
              <CustomTextInput
                title={'Nomor Anggota'}
                placeholder={'-'}
                value={this.state.noAnggota}
                readonly={true}
              />
             <CustomTextInput
                title={'*Angkatan'}
                placeholder={'-- Pilih Angkatan --'}
                value={this.state.angkatan}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Angkatan',
                    [CONSTANTS.FUNCTION]: this.onDoneAngkatan.bind(this),
                    [CONSTANTS.DATA]: angkatan,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_RADIO_BUTTON,
                  });
                }}
              />
              <CustomTextInput
                title={'*IKAMA Daerah'}
                placeholder={'-- Pilih IKAMA Daerah --'}
                value={this.state.ikamaTerdekat ? this.state.ikamaTerdekat.wilayah : null}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'IKAMA Daerah',
                    [CONSTANTS.FUNCTION]: this.onDoneIkamaDaerah.bind(this),
                    [CONSTANTS.DATA]: this.state.dataMaster["ikama-terdekat"], //need API
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_IKAMA_DAERAH,
                  });
                }}
              />
              <CustomTextInput
                title={'*Suku'}
                placeholder={'Suku'}
                value={this.state.suku}
                onChangeText={suku => {
                  this.setState({suku});
                }}
              />
              <CustomTextInput
                title={'*Agama'}
                placeholder={'Agama'}
                value={this.state.agama}
                onChangeText={agama => {
                  this.setState({agama});
                }}
              />
              <CustomTextInput
                title={'*Tempat Lahir'}
                placeholder={'Tempat Lahir'}
                value={this.state.tempatLahir}
                onChangeText={tempatLahir => {
                  this.setState({tempatLahir});
                }}
              />
              <CustomTextInput
                title={'Birthdate'}
                placeholder={'DD MMMM YYYY'}
                value={
                  this.state.tanggalLahir
                    ? this.state.tanggalLahir.format('DD MMMM YYYY')
                    : null
                }
                onPress={() => {
                  this.setState({
                    isShowDatePicker: !this.state.isShowDatePicker,
                  });
                }}
              />
              <CustomTextInput
                title={'Jenis Kelamin'}
                placeholder={'Laki-laki / Perempuan'}
                value={this.state.jenisKelamin}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Jenis Kelamin',
                    [CONSTANTS.FUNCTION]: this.onDoneGender.bind(this),
                    [CONSTANTS.DATA]: [{id: 1, name: 'Laki-laki'}, {id: 2, name: 'Perempuan'}],
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_RADIO_BUTTON,
                  });
                }}
              />
              <CustomTextInput
                title={'Golongan Darah'}
                placeholder={'-- Pilih Golongan Darah --'}
                value={this.state.golDarah}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Golongan Darah',
                    [CONSTANTS.FUNCTION]: this.onDoneGolonganDarah.bind(this),
                    [CONSTANTS.DATA]: this.state.dataListGolDarah,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_RADIO_BUTTON,
                  });                  
                }}
              />
              <CustomTextInput
                title={'Status'}
                placeholder={'Belum Menikah / Sudah Menikah'}
                value={this.state.status}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Status',
                    [CONSTANTS.FUNCTION]: this.onDoneStatus.bind(this),
                    [CONSTANTS.DATA]: [{id: 1, name: 'Belum Menikah'}, {id: 2, name: 'Sudah Menikah'}],
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_RADIO_BUTTON,
                  });                  
                }}
              />

              <CustomTextInput
                title={'Apakah anda bersedia data anda dilihat alumni lain?'}
                placeholder={'Ya / Tidak'}
                value={this.state.setuju}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Bersedia data dilihat alumni lain',
                    [CONSTANTS.FUNCTION]: this.onDoneSeenByOther.bind(this),
                    [CONSTANTS.DATA]: [{id: 1, name: 'Ya'}, {id: 0, name: 'Tidak'}],
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_RADIO_BUTTON,
                  });                  
                }}
              />

              {/* <CustomTextInput
                title={'Bio'}
                placeholder={'bio'}
                value={this.state.bio}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Bio',
                    [CONSTANTS.FUNCTION]: this.onDoneBio.bind(this),
                    [CONSTANTS.DATA]: this.state.bio,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_TEXT_AREA,
                  });
                }}
              /> */}
             
              {/* <CustomTextInput
                title={'Phone Number'}
                placeholder={'phone number'}
                value={this.state.phone}
                keyboardType={'phone-pad'}
                onChangeText={phone => {
                  this.setState({phone});
                }}
              /> */}
             
            </View>
          )}

          {this.state.indexTypeSelected == 1 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <CustomTextInput
                title={'No Telepon'}
                value={this.state.telp}
                keyboardType={'phone-pad'}
                type={'tel'}
                onChangeText={value => {
                  this.setState({telp: value});
                }}
              />
              <CustomTextInput
                title={'No Whatsapp'}
                value={this.state.noWhatsapp}
                keyboardType={'phone-pad'}
                type={'tel'}
                onChangeText={value => {
                  this.setState({noWhatsapp: value});
                }}
              />
              <CustomTextInput
                title={'Facebook'}
                placeholder={'http://facebook.com/'}
                value={this.state.facebook}
                onChangeText={facebook => {
                  this.setState({facebook});
                }}
              />
              <CustomTextInput
                title={'Instagram'}
                placeholder={'http://instagram.com/'}
                value={this.state.instagram}
                onChangeText={instagram => {
                  this.setState({instagram});
                }}
              />
              <CustomTextInput
                title={'Linkedin'}
                placeholder={'http://linkedin.com/'}
                value={this.state.linkedin}
                onChangeText={linkedin => {
                  this.setState({linkedin});
                }}
              />

            </View>
          )}
          
          {this.state.indexTypeSelected == 2 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <CustomTextInput
                title={'*Asal Provinsi'}
                placeholder={'Pilih Provinsi'}
                value={this.state.asalProvinsi ? this.state.asalProvinsi.name : null}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Provinsi',
                    [CONSTANTS.FUNCTION]: this.onDoneAsalProvinsi.bind(this),
                    [CONSTANTS.DATA]: this.state.dataMaster.provinsi,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_PROVINSI,
                  });
                }}
              />
              {this.state.asalProvinsi && (
                <CustomTextInput
                  title={'*Asal Kota / Kabupaten'}
                  placeholder={'kota / kabupaten'}
                  value={this.state.asalKota ? this.state.asalKota.name : null}
                  onPress={() => {
                    this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                      [CONSTANTS.TITLE]: 'Kota / Kabupaten',
                      [CONSTANTS.FUNCTION]: this.onDoneAsalKota.bind(this),
                      [CONSTANTS.DATA]: this.state.asalKota,
                      [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_CITY,
                      [CONSTANTS.PARAMS]: this.state.asalProvinsi.id,
                    });
                  }}
                />
              )}
              {this.state.asalKota && (
                <CustomTextInput
                  title={'*Asal Kecamatan'}
                  placeholder={'kecamatan'}
                  value={this.state.asalKecamatan ? this.state.asalKecamatan.name : null}
                  onPress={() => {
                    this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                      [CONSTANTS.TITLE]: 'Kecamatan',
                      [CONSTANTS.FUNCTION]: this.onDoneAsalKecamatan.bind(this),
                      [CONSTANTS.DATA]: this.state.asalKecamatan,
                      [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_KECAMATAN,
                      [CONSTANTS.PARAMS]: this.state.asalKota.id,
                    });
                  }}
                />
              )}
              {this.state.asalKecamatan && (
                <CustomTextInput
                  title={'*Asal Kelurahan / Desa'}
                  placeholder={'kelurahan / desa'}
                  value={this.state.asalDesa ? this.state.asalDesa.name : null}
                  onPress={() => {
                    this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                      [CONSTANTS.TITLE]: 'Kelurahan / Desa',
                      [CONSTANTS.FUNCTION]: this.onDoneAsalDesa.bind(this),
                      [CONSTANTS.DATA]: this.state.asalDesa,
                      [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_DESA,
                      [CONSTANTS.PARAMS]: this.state.asalKecamatan.id,
                    });
                  }}
                />
              )}

              <CustomTextInput
                title={'Asal Alamat'}
                placeholder={'Alamat'}
                value={this.state.asalAlamat}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Asal Alamat',
                    [CONSTANTS.FUNCTION]: this.onDoneAsalAlamat.bind(this),
                    [CONSTANTS.DATA]: this.state.asalAlamat,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_TEXT_AREA,
                  });
                }}
              />

              <CustomTextInput
                title={'Asal Kode Pos'}
                placeholder={'postcode'}
                value={this.state.asalKodePos}
                keyboardType={'numeric'}
                onChangeText={asalKodePos => {
                  this.setState({asalKodePos});
                }}
              />
            </View>
          )}

          {this.state.indexTypeSelected == 3 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <CustomTextInput
                title={'*Negara'}
                placeholder={'Negara'}
                value={this.state.negara ? this.state.negara.name : null}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Negara',
                    [CONSTANTS.FUNCTION]: this.onDoneNegara.bind(this),
                    [CONSTANTS.DATA]: this.state.dataMaster.negara,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_PROVINSI,
                  });
                }}
              />

              {(this.state.negara.id == 102 || this.state.negara.id == "102") && (
                <View>
                  <CustomTextInput
                    title={'*Provinsi'}
                    placeholder={'Pilih Provinsi'}
                    value={this.state.provinsi ? this.state.provinsi.name : null}
                    onPress={() => {
                      this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                        [CONSTANTS.TITLE]: 'Provinsi',
                        [CONSTANTS.FUNCTION]: this.onDoneProvinsi.bind(this),
                        [CONSTANTS.DATA]: this.state.dataMaster.provinsi,
                        [CONSTANTS.TYPE]: CONSTANTS.TYPE_PROVINSI,
                      });
                    }}
                  />
                  {this.state.provinsi && (
                    <CustomTextInput
                      title={'*Kota / Kabupaten'}
                      placeholder={'kota / kabupaten'}
                      value={this.state.kota ? this.state.kota.name : null}
                      onPress={() => {
                        this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                          [CONSTANTS.TITLE]: 'Kota / Kabupaten',
                          [CONSTANTS.FUNCTION]: this.onDoneKota.bind(this),
                          [CONSTANTS.DATA]: this.state.kota,
                          [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_CITY,
                          [CONSTANTS.PARAMS]: this.state.provinsi.id,
                        });
                      }}
                    />
                  )}
                  {this.state.kota && (
                    <CustomTextInput
                      title={'*Kecamatan'}
                      placeholder={'kecamatan'}
                      value={this.state.kecamatan ? this.state.kecamatan.name : null}
                      onPress={() => {
                        this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                          [CONSTANTS.TITLE]: 'Kecamatan',
                          [CONSTANTS.FUNCTION]: this.onDoneKecamatan.bind(this),
                          [CONSTANTS.DATA]: this.state.kecamatan,
                          [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_KECAMATAN,
                          [CONSTANTS.PARAMS]: this.state.kota.id,
                        });
                      }}
                    />
                  )}
                  {this.state.kecamatan && (
                    <CustomTextInput
                      title={'*Kelurahan / Desa'}
                      placeholder={'kelurahan / desa'}
                      value={this.state.desa ? this.state.desa.name : null}
                      onPress={() => {
                        this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                          [CONSTANTS.TITLE]: 'Kelurahan / Desa',
                          [CONSTANTS.FUNCTION]: this.onDoneDesa.bind(this),
                          [CONSTANTS.DATA]: this.state.desa,
                          [CONSTANTS.TYPE]: CONSTANTS.TYPE_LIST_DESA,
                          [CONSTANTS.PARAMS]: this.state.kecamatan.id,
                        });
                      }}
                    />
                  )}

                  <CustomTextInput
                    title={'Kode Pos'}
                    placeholder={'postcode'}
                    value={this.state.kodePos}
                    keyboardType={'numeric'}
                    onChangeText={kodePos => {
                      this.setState({kodePos});
                    }}
                  />
                </View>
              )}

              <CustomTextInput
                title={'Alamat'}
                placeholder={'Alamat'}
                value={this.state.alamat}
                onPress={() => {
                  this.props.navigation.navigate(ROUTE_NAMES.SCREEN_INPUT, {
                    [CONSTANTS.TITLE]: 'Alamat',
                    [CONSTANTS.FUNCTION]: this.onDoneAlamat.bind(this),
                    [CONSTANTS.DATA]: this.state.alamat,
                    [CONSTANTS.TYPE]: CONSTANTS.TYPE_TEXT_AREA,
                  });
                }}
              />
            </View>
          )}

          {this.state.indexTypeSelected == 4 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <FlatList
                renderItem={({item, index}) => {
                  return this.renderFormPekerjaan(item, index);
                }}
                contentContainerStyle={{
                  paddingTop: 10,
                }}
                keyExtractor={item => item.id}
                showsHorizontalScrollIndicator={false}
                data={this.state.pekerjaan}
              />
            </View>
          )}

          {this.state.indexTypeSelected == 5 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <FlatList
                renderItem={({item, index}) => {
                  return this.renderFormBisnis(item, index);
                }}
                contentContainerStyle={{
                  paddingTop: 10,
                }}
                keyExtractor={item => item.id}
                showsHorizontalScrollIndicator={false}
                data={this.state.bisnis}
              />
            </View>
          )}

          {this.state.indexTypeSelected == 6 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <CustomTextInput
                title={'Hobi Olahraga'}
                value={this.state.interest.hobi_olahraga ? this.state.interest.hobi_olahraga : null}
                onChangeText={text => {
                  var stateInterest = this.state.interest;
                  stateInterest.hobi_olahraga = text;
                  this.setState({interest: stateInterest});
                }}
              />

              <CustomTextInput
                title={'Hobi Non Olahraga'}
                value={this.state.interest.hobi_non_olahraga ? this.state.interest.hobi_non_olahraga : null}
                onChangeText={text => {
                  var stateInterest = this.state.interest;
                  stateInterest.hobi_non_olahraga = text;
                  this.setState({interest: stateInterest});
                }}
              />

              <CustomTextInput
                title={'Ketertarikan Khusus'}
                value={this.state.interest.ketertarikan_khusus ? this.state.interest.ketertarikan_khusus : null}
                onChangeText={text => {
                  var stateInterest = this.state.interest;
                  stateInterest.ketertarikan_khusus = text;
                  this.setState({interest: stateInterest});
                }}
              />
            </View>
          )}

          {this.state.indexTypeSelected == 7 && (
            <View style={{padding: AppTheme.metrics.extraLargeSize}}>
              <CustomTextInput
                title={'Organisasi Lain'}
                value={this.state.other.organisasi_lain ? this.state.other.organisasi_lain : null}
                onChangeText={text => {
                  var stateOther = this.state.other;
                  stateOther.organisasi_lain = text;
                  this.setState({other: stateOther});
                }}
              />
            </View>
          )}
        </View>
      </ScrollView>
    );
  }
}

const mapStateToProps = state => ({
  profileEditRequest: state.profile,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(ProfileEditCreators, dispatch);

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ProfileEdit);
