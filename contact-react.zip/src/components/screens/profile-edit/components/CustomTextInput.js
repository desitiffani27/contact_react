import React from 'react';
import {View, Text} from 'react-native';
import styles from '~/styles';
import TextInput from '~/components/common/TextInput';

const CustomTextInput = ({
  title,
  placeholder,
  type,
  value,
  onChangeText,
  keyboardType,
  onPress,
  isBolderTitle
}) => {
  return (
    <View>
      <Text style={{color: isBolderTitle ? styles.colors.black : styles.colors.subSubText}}>{title}</Text>
      <TextInput
        onPress={onPress}
        placeholder={placeholder}
        value={value}
        onChangeText={onChangeText}
        type={type}
        keyboardType={keyboardType}
      />
    </View>
  );
};

export default CustomTextInput;
