// @flow

import React, {Component} from 'react';
import {
  TouchableOpacity,
  StatusBar,
  Animated,
  FlatList,
  ProgressBarAndroid,
  Image,
  View,
  TextInput,
  Text,
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {showMessage} from 'react-native-flash-message';
import styled from 'styled-components';
import {AuthContext} from '../../../context';
import {DefaultText} from '../login/components/Common';
import env from 'react-native-config';
import AsyncStorage from '@react-native-community/async-storage';
import {ROUTE_NAMES} from '~/utils/CONSTANTS';

import appStyles from '~/styles';

const Container = styled(View)`
  flex: 1;
`;

const Wrapper = styled(View)`
  width: 100%;
  height: 100%;
  position: absolute;
`;

const ContentWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.width}px;
  height: 100%;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const DarkLayer = styled(View)`
  width: 100%;
  height: 100%;
  background-color: ${({theme}) => theme.colors.intermediateDarkLayer};
`;

const Title = styled(Text)`
  font-family: Modesta-Script;
  color: ${({theme}) => theme.colors.defaultWhite};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('11.5%')}px;
`;

const TitleWrapper = styled(View)`
  width: 100%;
  align-items: center;
  justify-content: center;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
  margin-bottom: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const BackgroundImage = styled(Image).attrs({
  source: {uri: 'bg'},
  resizeMode: 'cover',
})`
  position: absolute;
  width: 100%;
  height: 100%;
`;

const NavigationTitleWrapper = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('10%')}px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;
const ContentContainer = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('5%')}px;
  justify-content: center;
  align-items: center;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({color}) => color};
  border-radius: 5px;
  shadow-color: ${({theme}) => theme.colors.lightGray};
  shadow-opacity: 0.26;
  shadow-offset: { width: 0, height: 2};
  shadow-radius: 10;
  elevation: 3;
`;
class LoginMenu extends Component {
  _loginFontSize: Object = new Animated.Value(1);
  _signUpFontSize: Object = new Animated.Value(0);
  _flatListRef: Object = {};
  static contextType = AuthContext;
  state = {
    isBackgroundImageLoaded: false,
    otp: null,
    
  };
  componentDidMount() {
    const auth = this.context;
    const {navigation, route} = this.props;
    navigation.setOptions({tabBarVisible: false});
  }
  
  onClickLoginButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 1,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 0,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 0}));
  };

  onClickSignUpButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 0,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 1,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 1}));
  };
  showRegisterError = (message, type) => {
    // setProgressVisible(false);

    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
    });
  };
  onLoadBackgroundImage = (): void => {
    this.setState({
      isBackgroundImageLoaded: true,
    });
  };
  
  render() {
    const {isBackgroundImageLoaded} = this.state;
    const auth = this.context;

    return (
      <Container>
        <StatusBar
          backgroundColor="transparent"
          barStyle="light-content"
          translucent
          animated
        />
        <BackgroundImage onLoad={this.onLoadBackgroundImage} />
        {/* <DarkLayer /> */}
        {isBackgroundImageLoaded && (
          <Wrapper>
            <KeyboardAwareScrollView>
              <View style={{flexDirection: 'row', justifyContent: 'center', marginTop: '25%'}}>
                <TouchableOpacity
                  onPress={() => {
                    auth.goToLogin()
                  }}
                  style={{width: '25%', marginEnd: '20%'}}>
                  <ContentContainer color={appStyles.colors.primaryColor}>
                    <DefaultText>Masuk</DefaultText>
                  </ContentContainer>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    auth.goToSignup()
                  }}
                  style={{width: '25%'}}>
                  <ContentContainer color={appStyles.colors.buttonGray}>
                    <DefaultText style={{color: appStyles.colors.grayTitle}}>Daftar</DefaultText>
                  </ContentContainer>
                </TouchableOpacity>
              </View>

              <TitleWrapper>
                <Image
                  style={{width: 230, height: 240}}
                  source={{
                    uri: 'logonew',
                  }}
                />
              </TitleWrapper>
              
              <View style={{paddingHorizontal: appStyles.metrics.extraLargeRS}}>
                <Text
                  style={{
                    fontSize: 16,
                    color: appStyles.colors.grayTitle,
                    fontFamily: 'CircularStd-Medium'
                  }}>
                  Pusat Bantuan
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    paddingTop: appStyles.metrics.mediumSize,
                    color: appStyles.colors.grayTitle,
                    fontFamily: 'CircularStd-Book'
                  }}>
                  Butuh Bantuan ? Hubungi Sekretariat IKAMA  
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: appStyles.colors.grayTitle,
                    fontFamily: 'CircularStd-Book'
                  }}>
                  Phone: 08xx-xxx-xxxx
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: appStyles.colors.grayTitle,
                    fontFamily: 'CircularStd-Book'
                  }}>
                  Email: 
                </Text>
              </View>
            </KeyboardAwareScrollView>
          </Wrapper>
        )}
      </Container>
    );
  }
}

export default LoginMenu;
