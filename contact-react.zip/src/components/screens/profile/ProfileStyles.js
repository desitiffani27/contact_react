import {StyleSheet} from 'react-native';
import styles from '~/styles';

export default StyleSheet.create({
  // View
  contianer: {
    height: '100%'
  },
  containerContent: {
    paddingTop: styles.metrics.getHeightFromDP('6%'),
    flex: 1
  },
  containerTitleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  containerTitle: {
    flex: 1,
    alignItems: 'center',
  },
  containerRating: {
    flexDirection: 'row',
    marginTop: styles.metrics.getHeightFromDP('4%'),
    alignItems: 'center',
  },
  containerEarning: {
    flexDirection: 'row',
    marginTop: styles.metrics.getHeightFromDP('4%'),
    paddingHorizontal: styles.metrics.getHeightFromDP('3%'),
    justifyContent: 'space-between',
    width: '100%',
  },
  containerSetting: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: styles.metrics.mediumSize,
  },

  // Text
  textTitle: {
    paddingLeft: 44,
    fontFamily: 'CircularStd-Bold',
    color: styles.colors.darkText,
    fontSize: 22.65,
  },
  textName: {
    color: styles.colors.primaryColor,
    fontSize: 24,
    marginBottom: styles.metrics.getHeightFromDP('4%'),
    fontFamily: 'CircularStd-Medium'
  },
  textRating: {
    marginLeft: styles.metrics.smallSize,
    color: styles.colors.primaryColor,
    fontSize: 20,
    fontWeight: 'bold',
  },
  textReviewed: {
    marginLeft: styles.metrics.mediumSize,
    color: styles.colors.defaultWhite,
    fontSize: 14,
  },

  // Image
  imageProfile: {
    width: styles.metrics.getWidthFromDP('35%'),
    height: styles.metrics.getWidthFromDP('35%'),
    borderRadius: styles.metrics.getWidthFromDP('35%') / 2,
    borderWidth: styles.metrics.getWidthFromDP('1%'),
    borderColor: styles.colors.defaultWhite,
    marginTop: styles.metrics.getHeightFromDP('4%'),
    marginBottom: styles.metrics.getHeightFromDP('4%'),
    backgroundColor: styles.colors.defaultWhite,
    overflow: 'hidden',
    resizeMode: 'cover',
  },

  // Icon
  touchSetting: {
    width: 44,
    height: 44,
  },

  //referral section style
  containerReferral: {
    flexDirection: 'column',
    marginTop: styles.metrics.getHeightFromDP('4%'),
    alignItems: 'center',
    borderRadius: 5,
    padding: 10,
    flex: 1, 
    justifyContent: 'flex-end'
  },

  textShareTitle: {
    fontFamily: `CircularStd-Black`,
    fontSize: 17,
    marginBottom: 10,
    color: styles.colors.white,
    justifyContent: 'flex-start',
  },

  textReferral: {
    fontFamily: `CircularStd-Book`,
    fontSize: 13,
    marginBottom: 10,
    color: styles.colors.white
  },

  referralCode: {
    fontFamily: `CircularStd-Medium`,
    fontSize: styles.metrics.getWidthFromDP('5.5%'),
    color: styles.colors.white,
    textAlign: `center`,
    backgroundColor: styles.colors.primaryColor,
    borderRadius: 5,
    alignItems: `center`,
    justifyContent: `center`,
    padding: 8
  },
});