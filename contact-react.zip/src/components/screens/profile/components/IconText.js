import React from 'react';
import {Text, View, StyleSheet} from 'react-native';
import styles from '~/styles';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';

const stylesComponent = StyleSheet.create({
  // View
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  // Text
  text: {
    color: styles.colors.defaultWhite,
    fontSize: 14,
    marginStart: styles.metrics.mediumSize,
  },
  textValue: {
    fontWeight: 'bold',
  },
});

const IconText = ({icon, title, value}) => {
  return (
    <View style={stylesComponent.container}>
      <MaterialIcon color={styles.colors.defaultWhite} name={icon} size={24} />
      <Text numberOfLines={1} style={stylesComponent.text}>
        {title && <Text>{title} </Text>}
        <Text style={stylesComponent.textValue}>{value}</Text>
      </Text>
    </View>
  );
};

export default IconText;
