import React from 'react';
import {Text, View, StyleSheet} from 'react-native';
import styles from '~/styles';

const stylesComponent = StyleSheet.create({
  // View
  container: {
    width: styles.metrics.getWidthFromDP('27%'),
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  separator: {
    backgroundColor: styles.colors.defaultWhite,
    height: styles.metrics.getHeightFromDP('0.15%'),
    width: '100%',
    marginVertical: styles.metrics.extraSmallSize,
  },

  // Text
  textTitle: {
    color: styles.colors.defaultWhite,
    fontSize: 16,
    textAlign: 'center',
  },
  textValue: {
    color: styles.colors.defaultWhite,
    fontSize: 22,
  },
});

const EarningItem = ({title, value}) => {
  return (
    <View style={stylesComponent.container}>
      <Text
        adjustsFontSizeToFit={true}
        numberOfLines={1}
        style={stylesComponent.textValue}>
        {value}
      </Text>
      <View style={stylesComponent.separator} />
      <Text
        adjustsFontSizeToFit={true}
        numberOfLines={2}
        style={stylesComponent.textTitle}>
        {title}
      </Text>
    </View>
  );
};

export default EarningItem;
