// @flow

import React, {Fragment, useEffect, useState} from 'react';
import {
  StatusBar,
  View,
  ScrollView,
  TouchableOpacity,
  Text,
  Image,
  FlatList,
  TextInput,
  Alert,
  Dimensions,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import {TabView, SceneMap, TabBar} from 'react-native-tab-view';
import HTML from 'react-native-render-html';
import moment from 'moment';
import ImageModal from 'react-native-image-modal';
import styled from 'styled-components';
import AppTheme from '~/styles';
import Loading from '../../../common/Loading';
import {ROUTE_NAMES as TALENT_ROUTE_NAMES} from '../../../../utils/CONSTANTS';
import Section from '../../../common/Section';
import {CONSTANTS} from '~/utils/CONSTANTS';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import styles from '../ProfileStyles';

const Container = styled(View)`
  flex: 1;
`;
const CardContainer = styled(View)`
  flex-direction: row;
  padding-left: ${({theme}) => theme.metrics.extraLargeSize}px;
  padding-right: ${({theme}) => theme.metrics.extraLargeSize}px;
  margin-end: ${({theme}) => theme.metrics.getWidthFromDP('10%')}px;
  border-top-left-radius: ${({theme}) =>
    theme.metrics.getWidthFromDP('10.2%')}px;
  background-color: ${({theme}) => theme.colors.defaultWhite};
  width: 100%;
`;
const ProfileAvatarWrapper = styled(View)`
  width: 30%;
  justify-content: center;
`;
const ProfileWrapper = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getWidthFromDP('40%')}px;
  justify-content: center;
  background-color: white;
  border-radius: 10px;
  border-width: 2px;
  border-color: white;
  overflow: hidden;
  margin-top: -${({theme}) => theme.metrics.getWidthFromDP('15%')}px;
`;
const ProfileAvatar = styled(Image).attrs(({uri}) => ({
  // priority: FastImage.priority.high,
  source: {uri},
  resizeMode: 'cover',
  defaultSource: {uri: 'no_avatar'},
}))`
  width: 100%;
  background-color: white;
  height: ${({theme}) => theme.metrics.getWidthFromDP('40%')}px;
`;
const MainContent = styled(View)`
  width: 100%;
  justify-content: center;
`;
const TopContentWrapper = styled(View)`
  width: 100%;
  flex-direction: row;
  padding-left: ${({theme}) => theme.metrics.mediumSize}px;
`;
const NameText = styled(Text).attrs({
  ellipsizeMode: 'tail',
  numberOfLines: 1,
})`
  font-family: CircularStd-Medium;
  color: ${({theme}) => theme.colors.darkText};
  padding-bottom: ${({theme}) => theme.metrics.extraSmallSize}px;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('5%')}px;
`;
const TextSmall = styled(Text).attrs({
  ellipsizeMode: 'tail',
  numberOfLines: 5
})`
  font-family: CircularStd-Book;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4%')}px;
  padding-left: ${({theme}) => theme.metrics.extraSmallSize}px;
  flex: 1;
`;
const BoxIconText = styled(View)`
  width: ${props => props.width};
  flex-direction: row;
  align-items: center;
`;
const BookingButton = styled(TouchableOpacity)`
  width: 93%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('7%')}px;
  justify-content: center;
  align-items: center;
  align-self: center
  margin-top: ${({theme}) => theme.metrics.extraLargeSize}px;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({theme}) => theme.colors.primaryColor};
  flex-direction: row;
  border-radius: 5px;
`;
const BookingButtonText = styled(Text)`
  color: ${({theme}) => theme.colors.defaultWhite};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('5.3%')}px;
  font-family: CircularStd-Black;
`;

const dataListGolDarah = ["","A", "B", "AB", "O"];

const ProfileDetail = (props): Object => {
  const profileDetail = props.detailRequest.profileRequest.data;
  const loading = props.detailRequest.profileRequest.loading;
  const error = props.detailRequest.profileRequest.error;
  const navigation = props.detailRequest.navigation;
  const shouldShowContent =
      Object.keys(profileDetail).length > 0 && !loading && !error;
  const initialLayout = {width: Dimensions.get('window').width};
  const [index, setIndex] = React.useState(0);
  const profile = profileDetail.profile;
  const asalDaerah = profileDetail['asal-daerah'];
  const domisili = profileDetail.domisili;
  const bisnis = profileDetail.bisnis;
  const interest = profileDetail.interest; //array
  const pekerjaan = profileDetail.pekerjaan;
  const other = profileDetail.other;

  const PersonalSection = () => (
    <Section title="Data Pribadi / Personal Particular">
      {profile != 'NA' && (
        <View>
          <TopContentWrapper>
            <TextSmall>Nama Lengkap</TextSmall>
            <TextSmall>: {profile.nama}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>No. Anggota</TextSmall>
            <TextSmall>: {profile.no_anggota != null ? profile.no_anggota : '-'}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Angkatan</TextSmall>
            <TextSmall>: {profile.angkatan}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>IKAMA Daerah</TextSmall>
            <TextSmall>: {profile.ikama_terdekat}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Suku</TextSmall>
            <TextSmall>: {profile.suku}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Agama</TextSmall>
            <TextSmall>: {profile.agama}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Tempat/Tanggal Lahir</TextSmall>
            <TextSmall>: {profile.tempat_lahir + " / " + profile.tanggal_lahir}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Jenis Kelamin</TextSmall>
            <TextSmall>: {profile.jenis_kelamin}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Golongan Darah</TextSmall>
            <TextSmall>: {dataListGolDarah[profile.gol_darah]}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Status</TextSmall>
            <TextSmall>: {profile.status}</TextSmall>
          </TopContentWrapper>
        </View>
      )}
    </Section>
  );
  
  const ContactSection = () => (
    <Section title="Kontak dan Sosial Media">
      <TopContentWrapper>
        <TextSmall>Email</TextSmall>
        {/* <TextSmall>: {profile.email}</TextSmall> */}
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Facebook</TextSmall>
        <TextSmall>: {profile.facebook}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Instagram</TextSmall>
        <TextSmall>: {profile.instagram}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Linkedin</TextSmall>
        <TextSmall>: {profile.linkedin}</TextSmall>
      </TopContentWrapper>
    </Section>
  );
  
  const OriginSection = () => (
    <Section title="Asal Daerah">
      <TopContentWrapper>
        <TextSmall>Asal Provinsi</TextSmall>
        <TextSmall>: {asalDaerah.provinsi}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Asal Kota / Kabupaten</TextSmall>
        <TextSmall>: {asalDaerah.kota}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Asal Kecamatan</TextSmall>
        <TextSmall>: {asalDaerah.kecamatan}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Asal Kelurahan / Desa</TextSmall>
        <TextSmall>: {asalDaerah.desa}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Asal Alamat</TextSmall>
        <TextSmall>: {asalDaerah.daerah}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Asal Kode Pos</TextSmall>
        <TextSmall>: {asalDaerah.kode_pos}</TextSmall>
      </TopContentWrapper>
    </Section>
  );
  
  const DomicileSection = () => (
    <Section title="Domisili">
      <TopContentWrapper>
        <TextSmall>Negara</TextSmall>
        <TextSmall>: {domisili.negara}</TextSmall>
      </TopContentWrapper>
      <TopContentWrapper>
        <TextSmall>Alamat</TextSmall>
        <TextSmall>: {domisili.daerah + "\nKelurahan " + domisili.desa 
                      + "\nKecamatan " + domisili.kecamatan 
                      + "\n" + domisili.kota + ", " + domisili.provinsi
                      + "\n" + domisili.kode_pos}
        </TextSmall>
      </TopContentWrapper>
    </Section>
  );
  
  const WorkSection = () => {
    var myloop = [];

    for (let i = 0; i < pekerjaan.length; i++) {
      myloop.push(
        <View key={i} style={{marginTop: AppTheme.metrics.smallSize}}>
          <TopContentWrapper>
            {pekerjaan.length > 1 && (<NameText>Pekerjaan {i+1}</NameText>)}
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Sektor</TextSmall>
            <TextSmall>: {pekerjaan[i].sektor_id ? pekerjaan[i].sektor_id : ''}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Provinsi</TextSmall>
            <TextSmall>: {pekerjaan[i].provinsi}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Kota / Kabupaten</TextSmall>
            <TextSmall>: {pekerjaan[i].kota}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Pekerjaan</TextSmall>
            <TextSmall>: {pekerjaan[i].pekerjaan_id}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Nama Perusahaan</TextSmall>
            <TextSmall>: {pekerjaan[i].nama_perusahaan}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Jabatan</TextSmall>
            <TextSmall>: {pekerjaan[i].jabatan}</TextSmall>
          </TopContentWrapper>
        </View>
      );
    }
    
    return myloop;
  };
  
  const BusinessSection = () => {
    var myloop = [];

    for (let i = 0; i < bisnis.length; i++) {
      myloop.push(
        <View key={i} style={{marginTop: AppTheme.metrics.smallSize}}>
          <TopContentWrapper>
            {bisnis.length > 1 && (<NameText>Bisnis {i+1}</NameText>)}
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Bidang</TextSmall>
            <TextSmall>: {bisnis[i].bidang}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Jenis Usaha</TextSmall>
            <TextSmall>: {bisnis[i].jenis_usaha}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Provinsi</TextSmall>
            <TextSmall>: {bisnis[i].provinsi}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Kota / Kabupaten</TextSmall>
            <TextSmall>: {bisnis[i].kota}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Nama Perusahaan</TextSmall>
            <TextSmall>: {bisnis[i].nama_perusahaan}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Alamat</TextSmall>
            <TextSmall>: {bisnis[i].alamat}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Nama Akun Medsos</TextSmall>
            <TextSmall>: {bisnis[i].nama_akun_medsos}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Nama Brand</TextSmall>
            <TextSmall>: {bisnis[i].brand}</TextSmall>
          </TopContentWrapper>
          <TopContentWrapper>
            <TextSmall>Jabatan</TextSmall>
            <TextSmall>: {bisnis[i].jabatan}</TextSmall>
          </TopContentWrapper>
        </View>
      );
    }
    
    return myloop;
  };
  
  const InterestSection = () => {    
    return (
      <Section title="Ketertarikan">
        <TopContentWrapper>
          <TextSmall>Hobi Olahraga</TextSmall>
          <TextSmall>: {interest.hobi_olahraga}</TextSmall>
        </TopContentWrapper>
        <TopContentWrapper>
          <TextSmall>Hobi Non Olahraga</TextSmall>
          <TextSmall>: {interest.hobi_non_olahraga}</TextSmall>
        </TopContentWrapper>
        <TopContentWrapper>
          <TextSmall>Ketertarikan Khusus</TextSmall>
          <TextSmall>: {interest.ketertarikan_khusus}</TextSmall>
        </TopContentWrapper>
      </Section>
  )};

  const OtherSection = () => {    
    return (
      <Section title="Lain-lain">
        <TopContentWrapper>
              <TextSmall>Organisasi Lain</TextSmall>
              <TextSmall>: {other.organisasi_lain}</TextSmall>
            </TopContentWrapper>    
      </Section>
  )};

  const isValidURL = (str) => {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return !!pattern.test(str);
  };
  
  const renderScene = SceneMap({
    first: PersonalSection,
    second: ContactSection,
    third: OriginSection,
    fourth: DomicileSection,
    fifth: WorkSection,
    sixth: BusinessSection,
    seventh: InterestSection,
    eight: OtherSection
  });
  
  const renderTabBar = props => {
    return (
      <TabBar
        {...props}
        indicatorStyle={{backgroundColor: AppTheme.colors.primaryColor}}
        activeColor={AppTheme.colors.primaryColor}
        inactiveColor={AppTheme.colors.lightDarkLayer}
        style={{backgroundColor: '#C8F2FE'}}
        labelStyle={{fontFamily: 'CircularStd-Medium', textAlign: 'center', fontSize: 12}}
        tabStyle={{width: 100}}
        scrollEnabled={true}
      />
    );
  };
  
  const [routes] = React.useState([
    {key: 'first', title: 'Data Pribadi'},
    {key: 'second', title: 'Kontak'},
    {key: 'third', title: 'Asal Daerah'},
    {key: 'fourth', title: 'Domisili'},
    {key: 'fifth', title: 'Pekerjaan'},
    {key: 'sixth', title: 'Bisnis'},
    {key: 'seventh', title: 'Ketertarikan'},
    {key: 'eight', title: 'Lain-lain'},
  ]);

  return (
    <Fragment>
      <StatusBar
        backgroundColor="transparent"
        barStyle={error || loading ? 'dark-content' : 'light-content'}
        translucent
        animated
      />
      {loading && <Loading />}
      {shouldShowContent && (
        <ScrollView contentContainerStyle={{flexGrow: 1}}>
          <Container>

            <View style={{width: '100%', alignItems: 'center'}}>
              <Image
                defaultSource={{uri: 'no_avatar'}}
                source={{
                  uri: isValidURL(profile.foto_profil) ? profile.foto_profil : "https://alumni.ikama.or.id/assets/attachment/alumni/"+profile.foto_profil ,
                }}
                style={styles.imageProfile}
              />
              <Text style={styles.textName}>
                {profile.nama ? profile.nama : 'Your Name'}
              </Text>
            </View>

            <View style={{background: AppTheme.colors.white}}>
              <TabView
                navigationState={{index, routes}}
                renderScene={renderScene}
                renderTabBar={renderTabBar}
                onIndexChange={setIndex}
                initialLayout={initialLayout}
              />
            </View>

          </Container>
        </ScrollView>
      )}
    </Fragment>
  );
};

export default ProfileDetail;
