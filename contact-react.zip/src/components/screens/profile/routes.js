import * as React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Platform} from 'react-native';

import {ROUTE_NAMES, CONSTANTS} from '../../../utils/CONSTANTS';
import {
  setHiddenHeaderLayout,
  setDefaultHeaderLayout,
  HeaderLeftClose,
} from '../../../routes/headerUtils';

import Profile from './index';
import Settings from '../settings';
import ProfileEdit from '../profile-edit';
import ChangePassword from '../change-password';
import Login from '~/components/screens/login';
import PrivacyPolicy from '../settings/screens/PrivacyPolicy';
import TermsCondition from '../settings/screens/TermsCondition';
import ContactUs from '../settings/screens/ContactUs';

const Stack = createStackNavigator();

function Routes() {
  console.log('> Home Account');
  return (
    <Stack.Navigator
      initialRouteName={ROUTE_NAMES.ACCOUNT}
      screenOptions={{
        gestureEnabled: true,
        gestureDirection: 'horizontal',
      }}
      animation="fade"
      mode={Platform.OS === 'ios' ? 'card' : 'modal'}
      headerMode="screen">
      <Stack.Screen
        name={ROUTE_NAMES.ACCOUNT}
        component={Profile}
        options={({navigation}) => setHiddenHeaderLayout(navigation)}
      />
      <Stack.Screen
        name={ROUTE_NAMES.SETTINGS}
        component={Settings}
        options={({navigation}) =>
          setDefaultHeaderLayout(navigation, 'Settings', 'Modesta-Script', 20)
        }
      />
      <Stack.Screen
        name={ROUTE_NAMES.PROFILE_EDIT}
        component={ProfileEdit}
        options={({navigation}) =>
          setDefaultHeaderLayout(
            navigation,
            'Edit Profile',
            'Modesta-Script',
            20,
          )
        }
      />
      {/* <Stack.Screen
        name={ROUTE_NAMES.SCREEN_INPUT}
        component={ScreenInput}
        options={({navigation}) => {
          return HeaderLeftClose(navigation, '', 'Modesta-Script', 20);
        }}
      /> */}
      <Stack.Screen
        name={ROUTE_NAMES.CHANGE_PASSWORD}
        component={ChangePassword}
        options={({navigation}) =>
          setDefaultHeaderLayout(
            navigation,
            'Change Password',
            'Modesta-Script',
            20,
          )
        }
      />
      <Stack.Screen
        name={ROUTE_NAMES.PRIVACY_POLICY}
        component={PrivacyPolicy}
        options={({route, navigation}) => 
          setDefaultHeaderLayout(navigation, 'Privacy Policy', 'CircularStd-Book', 20)
        }
      />
      <Stack.Screen
        name={ROUTE_NAMES.TERMS_CONDITION}
        component={TermsCondition}
        options={({route, navigation}) => 
          setDefaultHeaderLayout(navigation, 'Terms & Condition', 'CircularStd-Book', 20)
        }
      />
      <Stack.Screen
        name={ROUTE_NAMES.CONTACT_US}
        component={ContactUs}
        options={({route, navigation}) => 
          setDefaultHeaderLayout(navigation, 'Contact Us', 'CircularStd-Book', 20)
        }
      />
      <Stack.Screen
        name={ROUTE_NAMES.LOGIN}
        component={Login}
        options={({navigation}) => setHiddenHeaderLayout(navigation)}
      />
    </Stack.Navigator>
  );
}

export default Routes;
