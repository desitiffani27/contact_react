import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  StatusBar,
  ScrollView,
  TouchableOpacity,
  Share,
  Dimensions,
  Alert,
} from 'react-native';

import AsyncStorage from '@react-native-community/async-storage';
import {TabView, SceneMap, TabBar} from 'react-native-tab-view';
import {Creators as ProfileCreators} from '../../../store/ducks/profile';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {AuthContext} from '../../../context';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
//import dynamicLinks from '@react-native-firebase/dynamic-links';
import styled from 'styled-components';
import IconText from './components/IconText';
import roundToHalf from '~/utils/roundToHalf';
import ProfileDetail from './components/ProfileDetail';
import styles from './ProfileStyles';
import appStyles from '~/styles';
import showMessage from '~/utils/showMessage';
import {ROUTE_NAMES, CONSTANTS} from '~/utils/CONSTANTS';

import Loading from '~/components/common/Loading';
import env from 'react-native-config';
import moment from 'moment';
import Section from '../../common/Section';

const BackgroundImage = styled(Image).attrs({
  source: {uri: 'bg_profile'},
  resizeMode: 'cover',
})`
  position: absolute;
  width: 100%;
  height: 100%;
`;

class Profile extends Component {
  state = {index: 0};

  static getDerivedStateFromProps(props) {
    showMessage(props.profileRequest);
  }
  static contextType = AuthContext;
  componentDidMount() {
    const {getProfileRequest} = this.props;
    const {navigation} = this.props;
    const auth = this.context;
    // const user = await stGetUser();
    AsyncStorage.getItem('userToken').then(success => {
      if (success == null) {
        // navigation.setOptions({tabBarVisible: false});
        // navigation.reset({
        //   index: 0,
        //   routes: [{name: ROUTE_NAMES.LOGIN}],
        //   tabBarVisible: false,
        // });
        console.warn('success not')
        //auth.goToLogin();        
      } else {
        //getProfileRequest();
      }
    });
  }

  onRefresh = () => {
    const {getProfileRequest} = this.props;
    getProfileRequest();
  };
  onCheckUserSession = async () => {
    const {navigation} = this.props;
    // const user = await stGetUser();
    AsyncStorage.getItem('userToken').then(success => {
      success == null && navigation.navigate(ROUTE_NAMES.LOGIN);
    });
  };

  generateLink = async(referralLink) => {
    // const generatedLink = await dynamicLinks().buildLink({
    //   link: referralLink,
    //   domainUriPrefix: 'https://beauty2go.page.link'
    // });
    // return generatedLink;
  };

  renderTabBar = props => {
    return (
      <TabBar
        {...props}
        indicatorStyle={{backgroundColor: appStyles.colors.primaryColor}}
        activeColor={appStyles.colors.primaryColor}
        inactiveColor={appStyles.colors.gray}
        style={{backgroundColor: appStyles.colors.primaryColor}}
        labelStyle={{fontFamily: 'CircularStd-Medium'}}
      />
    );
  };

  confirmLogout = () => {
    const auth = this.context;
    Alert.alert('Konfirmasi', 'Apakah anda yakin akan keluar?', [
      {
        text: 'Tidak',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      {text: 'Ya', onPress: () => auth.signOut()},
    ]);
  };

  render() {
    const {loading, data} = this.props.profileRequest;
    const initialLayout = {width: Dimensions.get('window').width};

    //console.warn(data);

    console.log(this.props.profileRequest);
    return (
      <View style={styles.contianer}>
        {/* <StatusBar
          backgroundColor="transparent"
          barStyle="light-content"
          translucent
          animated
        /> */}
        {loading ? (
          <Loading />
        ) : (
          <View style={styles.containerContent}>
            <View style={styles.containerTitleWrapper}>
              <View style={styles.containerTitle}>
                <Text style={styles.textTitle}>Profile</Text>
              </View>
              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => this.confirmLogout()
                  // this.props.navigation.navigate(ROUTE_NAMES.SETTINGS, {
                  //   [CONSTANTS.DATA]: data,
                  //   [CONSTANTS.FUNCTION]: this.onRefresh.bind(this),
                  // });
                   // this.props.navigation.navigate(ROUTE_NAMES.SETTINGS, {
                  //   [CONSTANTS.DATA]: data,
                  //   [CONSTANTS.FUNCTION]: this.onRefresh.bind(this),
                  // });
                }>
                <View style={styles.containerSetting}>
                  <MaterialIcon
                    color={appStyles.colors.darkText}
                    name={'exit-to-app'}
                    size={24}
                  />
                </View>
              </TouchableOpacity>
            </View>

            <ProfileDetail detailRequest={this.props} />

          </View>
        )}
      </View>
    );
  }
}

const mapStateToProps = state => ({
  profileRequest: state.profile,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(ProfileCreators, dispatch);

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Profile);
