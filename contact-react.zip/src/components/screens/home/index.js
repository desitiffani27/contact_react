// @flow

import React, {Component} from 'react';
import {
  ScrollView,
  RefreshControl,
  View,
  Text,
  FlatList,
  Image,
  SafeAreaView,
  TouchableOpacity,
} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import {showMessage} from 'react-native-flash-message';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import AppTheme from '../../../styles';
import Section from './components/Section';
import StrCard from './components/StrCard';
import {Creators as HomeCreators} from '../../../store/ducks/home';
import styled from 'styled-components';
import Loading from '~/components/common/Loading';
import InfoEmpty from '~/components/common/InfoEmpty';
import ImageModal from 'react-native-image-modal';

const Container = styled(View)`
  justify-content: space-between;
  width: 100%;
`;

const ContainerProfile = styled(View)`
  flex: 1;
  flex-direction: column;
  align-content: center;
  background-color: 'rgba(6, 1, 180, 0.7)';
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
`;
// elevation: 2;

const ContainerProfileContent = styled(TouchableOpacity)`
  flex-direction: row;
  width: 100%;
  padding: 20px;
`;

const ListWrapper = styled(View)`
  flex: 1;
  flex-direction: row;
`;

const CartBadge = styled(Text)`
  background-color: red;
  color: white;
  padding-horizontal: 5px;
  border-radius: 20px;
  position: absolute;
  font-size: ${({theme}) => theme.metrics.getHeightFromDP('1.5%')}px;
  right: 0;
  top: 12;
`;

const BackgroundImage = styled(Image).attrs({
  source: {uri: 'bg_header'},
  resizeMode: 'cover',
})`
  position: absolute;
  width: 100%;
  height: 130px;
`;

const SectionTextViewAll = styled(Text)`
  color: ${({theme}) => theme.colors.primaryColor};
  margin-right: ${({theme}) => theme.metrics.mediumSize}px;
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.0%')}px;
  margin-bottom: 8px;
  text-align: right;
`;

const SLIDER_1_FIRST_ITEM = 1;
class Home extends Component {
  state = {
    isRefreshing: false,
    search: '',
    slider1ActiveSlide: SLIDER_1_FIRST_ITEM,
  };

  componentDidMount() {
    console.log('> Home Screen');
    SplashScreen.hide();
    //this.requestData();

    this.willFocusSubscription = this.props.navigation.addListener(
      'focus',
      () => {
        this.requestData();
      },
    );
  }

  static getDerivedStateFromProps(props, state) {
    const {landingRequest} = props;
    const {error: error1, errorMessage: errorMessage1} = landingRequest;

    if (error1 && errorMessage1 !== null) {
      // showMessage({
      //   message: errorMessage1,
      //   type: 'danger',
      //   icon: 'danger',
      // });
      console.log("errorLandingRequest: ", errorMessage1)
    }

    return {
      isRefreshing: false,
    };
  }

  requestData = async () => {
    console.log('> requestData->getLandingRequest');
    const {getLandingRequest} = this.props;
    // await getPkomRequest();
    await getLandingRequest();
  };

  isValidURL = (str) => {
    var pattern = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); // fragment locator
    return !!pattern.test(str);
  };

  onProfileChanged = value => {
    console.log('> onProfileChanged', value);

    // const data = {...this.state.data, ...value};
    // this.setState({data});
    // const {route} = this.props;
    // const {[CONSTANTS.FUNCTION]: onRefresh} = route.params;
    // onRefresh();
  };

  renderProfileInfo = (user) => {
    const {navigation} = this.props;

    return (
      <ContainerProfile>
        <ContainerProfileContent>
          <View
            style={{
              flex: 1,
            }}>
            <Image
              source={{
                uri: 'logonew',
                // uri: 'logonew',
              }}
              style={{
                height: 40,
                width: 40,
                marginBottom: 5,
              }}
            />
            <View style={{flexDirection: 'row', marginBottom: 4}}>
              <Text
                style={{
                  color: AppTheme.colors.white,
                  fontSize: 16,
                  fontFamily: 'CircularStd-Bold'
                }}>
                {user.role_id == 1 ? "Selamat datang, " + user.name + "!" : user.name}
              </Text>
              {user.role_id == 2 && user.type != "-" && (
                <Text
                  style={{
                    paddingHorizontal: 6,
                    paddingTop: 1,
                    marginStart: 8,
                    color: AppTheme.colors.black,
                    fontSize: 10,
                    marginTop: AppTheme.metrics.extraSmallSize,
                    backgroundColor: AppTheme.colors.white,
                    borderRadius: 10,
                    fontFamily: 'CircularStd-Medium'
                  }}>
                  {user.type}
                </Text>
              )}
            </View>
            {user.role_id != 1 && (
              <View>
                <Text
                  style={{
                    color: AppTheme.colors.white,
                    fontSize: 13,
                    marginBottom: 4,
                    fontFamily: 'CircularStd-Medium'
                  }}>
                  {user.no_hp}
                </Text>
                <Text
                  style={{
                    color: AppTheme.colors.white,
                    fontSize: 13,
                    fontFamily: 'CircularStd-Medium'
                  }}>
                  {user.jabatan}
                </Text>
              </View>
            )}
          </View>
          <View
            style={{
              borderRadius: 40,
              height: user.role_id == 1 ? 24 : 80,
              width: user.role_id == 1 ? 24 : 80,
              marginBottom: 10,
              marginLeft: 10,
              overflow: "hidden",
              alignItems: "center"
            }}>
            <ImageModal
                source={{
                  uri: user.image != null ? user.image : 'no_avatar',
                }}
                style={{
                  height: user.role_id == 1 ? 24 : 80,
                  width: user.role_id == 1 ? 24 : 80
                }}
                resizeMode="contain"
                imageBackgroundColor="gray"
                overlayBackgroundColor="gray"
              />
          </View>
        </ContainerProfileContent>
      </ContainerProfile>
    );
  };

  renderMainContent = landingInfo => {
    const {isRefreshing} = this.state;
    const {navigation} = this.props;
    console.warn("renderMainContent-landingInfo:", landingInfo);
    var userData = landingInfo.user;
    var strList = landingInfo.tenagaKesehatanStr;
    var opStrList = landingInfo.operasionalStr;

    return (
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={{
          paddingBottom: 20,
          marginTop: 26,
          flex: 1,
          backgroundColor: AppTheme.colors.background,
        }}
        refreshControl={
          <RefreshControl
            progressBackgroundColor={AppTheme.colors.primaryColor}
            tintColor={AppTheme.colors.primaryColor}
            colors={[AppTheme.colors.white]}
            onRefresh={this.requestData}
            refreshing={isRefreshing}
          />
        }>
        {(userData !== null && userData.id !== null) && this.renderProfileInfo(userData)}
        {strList.length > 0 && (
          <Section title="Surat Tanda Registrasi">
            <Container>
              <ListWrapper>
                <FlatList
                  renderItem={({item, index}) => {
                    return <StrCard item={item} isFirst={index === 0} isOperasional={false} onSaved={() => this.requestData} />;
                  }}
                  numColumns={1}
                  showsVerticalScrollIndicator={false}
                  keyExtractor={item => item.id}
                  data={strList}
                />
              </ListWrapper>
            </Container>
          </Section>
        )}
        {opStrList.length > 0 && (
          <Section title="Perizinan Operasional &amp; Kalibrasi">
            <Container>
              <ListWrapper>
                <FlatList
                  renderItem={({item, index}) => {
                    return <StrCard item={item} isFirst={index === 0} isOperasional={true} />;
                  }}
                  numColumns={1}
                  showsVerticalScrollIndicator={false}
                  keyExtractor={item => item.id}
                  data={opStrList}
                />
              </ListWrapper>
            </Container>
          </Section>
        )}
        {strList.length === 0 && opStrList.length === 0  && userData !== null && userData.id !== null &&
            this.renderNullData(userData.role_id == 2)}
      </ScrollView>
    );
  };

  renderNullData = (isTenagaKesehatan) => {
    return (
      <InfoEmpty
        scrollEnabled
        title={'Tidak ada data ' + (isTenagaKesehatan ? 'STR' : 'perizinan')}
        refreshing={this.state.isRefreshing}
        onRefresh={this.requestData}
      />
    );
  };

  render() {
    const {landingRequest} = this.props;
    return (
      <SafeAreaView style={{flex: 1}}>
        {landingRequest.loading ? (
          <Loading />
        ) : 
          this.renderMainContent(landingRequest)}
      </SafeAreaView>
    );
  }
}

const mapStateToProps = state => ({
  landingRequest: state.home,
});

const mapDispatchToProps = dispatch => {
  return bindActionCreators({...HomeCreators}, dispatch);
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Home);
