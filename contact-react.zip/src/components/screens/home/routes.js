import * as React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {Platform} from 'react-native';

import {ROUTE_NAMES, CONSTANTS} from '../../../utils/CONSTANTS';
import {
  setHiddenHeaderLayout,
  setDefaultHeaderLayout,
  HeaderLeftClose,
} from '../../../routes/headerUtils';

import FormStr from '../form-str';
import WebView from '~/components/common/WebViews';
import Home from './index';
import Login from '../login';
import ProfileEdit from '../profile-edit';

const Stack = createStackNavigator();

function Routes() {
  console.log('> Home Routes');
  return (
    <Stack.Navigator
      initialRouteName={ROUTE_NAMES.HOME}
      screenOptions={{
        gestureEnabled: true,
        gestureDirection: 'horizontal',
      }}
      animation="fade"
      mode={Platform.OS === 'ios' ? 'card' : 'modal'}
      headerMode="screen">
      <Stack.Screen
        name={ROUTE_NAMES.HOME}
        component={Home}
        // options={({navigation}) =>
        //   setDefaultHeaderLayout(navigation, 'Beauty2Go', 'Modesta-Script', 25)
        // }
        options={({route}) => setHiddenHeaderLayout(route)}
      />

      <Stack.Screen
        name={ROUTE_NAMES.FORM_STR}
        component={FormStr}
        // options={({route}) => setHiddenHeaderLayout(route)}
        options={({navigation, route}) =>
          setDefaultHeaderLayout(navigation, route.params.isOperasional ? 'Perbarui Dokumen Perizinan' : 'Perbarui STR', 'CircularStd-Book', 18)
        }
      />
      
      <Stack.Screen
        name={ROUTE_NAMES.WEBVIEW}
        component={WebView}
        // options={({route}) => setHiddenHeaderLayout(route)}
        options={({navigation}) =>
          setDefaultHeaderLayout(
            navigation,
            'Article Detail',
            'Modesta-Script',
            25,
          )
        }
      />

      <Stack.Screen 
        name={ROUTE_NAMES.LOGIN} 
        component={Login} 
        options={({route}) => setHiddenHeaderLayout(route)} 
      />
{/* 
      <Stack.Screen
        name={ROUTE_NAMES.SCREEN_INPUT}
        component={ScreenInput}
        options={({navigation}) => {
          return HeaderLeftClose(navigation, '', 'CircularStd-Book', 20);
        }}
      /> */}

      <Stack.Screen
        name={ROUTE_NAMES.PROFILE_EDIT}
        component={ProfileEdit}
        options={({navigation}) =>
          setDefaultHeaderLayout(
            navigation,
            'Edit Profile',
            'Modesta-Script',
            20,
          )
        }
      />
      
    </Stack.Navigator>
  );
}

export default Routes;
