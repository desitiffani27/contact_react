// @flow

import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import {handleHiddenHeaderStyle} from '~/routes/headerUtils';
import ArticleDetail from './components/ArticleDetail';
import {CONSTANTS} from '~/utils/CONSTANTS';
import {Creators as ArticleCreators} from '~/store/ducks/article';
import {HeaderBackButton} from '@react-navigation/stack';

class ArticleDetailContainer extends Component {
  _subscriptionWillFocusEvent = {};

  componentDidMount() {
    console.log('> PkomDetailContainer->componentDidMount: ');
    const {navigation, route, getArticleDetailRequest} = this.props;
    navigation.setOptions({tabBarVisible: false});
    const {[CONSTANTS.NAVIGATION_PARAM_ID]: id} = route.params;

    // this._subscriptionWillFocusEvent = navigation.addListener('willFocus', () =>
    //   handleHiddenHeaderStyle(route, navigation, false, false),
    // );
    navigation.setOptions({
      headerLeft: props => (
        <HeaderBackButton {...props} onPress={() => this.props.navigation.goBack()} 
          style={{ backgroundColor: "rgba(94,201,255,0.5)", 
                    borderRadius: 20 
        }} />
      ),
    });

    getArticleDetailRequest(id);
  }

  static getDerivedStateFromProps(nextProps, state) {
    const {loading, error} = nextProps.articleDetailRequest;
    const {navigation, route} = nextProps;

    handleHiddenHeaderStyle(route, navigation, loading, error);
  }

  componentWillUnmount() {
    //this._subscriptionWillFocusEvent.remove();
  }

  render() {
    const {route, navigation, articleDetailRequest} = this.props;
    console.log('> articledetailContainer->render');

    return (
      <ArticleDetail
        articleDetail={articleDetailRequest.detail}
        navigation={navigation}
      />
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators({...ArticleCreators}, dispatch);
};

const mapStateToProps = state => ({
  articleDetailRequest: state.article,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ArticleDetailContainer);
