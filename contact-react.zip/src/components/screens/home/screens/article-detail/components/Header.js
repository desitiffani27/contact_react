// @flow

import React, {Component, Fragment} from 'react';
import {View, TouchableOpacity, Share} from 'react-native';

import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';
import styled from 'styled-components';

import ProgressiveImage from '~/components/common/ProgressiveImage';
import {CONSTANTS} from '~/utils/CONSTANTS';
import appStyles from '~/styles';
import env from 'react-native-config';
import ImageView from 'react-native-image-view';

const ImageWrapper = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('35%')};
`;


const PkomImageWrapper = styled(View)`
  width: 100%;
  height: 100%;
  background-color: white;
  overflow: hidden;
`;

const BlackLayer = styled(View)`
  width: 100%;
  height: 100%;
  position: absolute;
`;

type Props = {
  thumbnailImageURL: string,
  pkomId: string,
  navigation: Object,
  route: Object,
  imageURL: string,
};

type State = {
  isImageLoaded: boolean,
  isImageViewVisible: boolean
};

class Header extends Component<Props, State> {
  state = {
    isImageLoaded: false,
    isImageViewVisible: false
  };

  onLoadImage = () => {
    const {isImageLoaded} = this.state;

    this.setState({
      isImageLoaded: !isImageLoaded,
    });
  };

  render() {
    const {thumbnailImageURL, imageURL, articleDetail} = this.props;

    const shareOptions = {
      title: 'Share',
      message: "I recommend you to see article " + articleDetail.title + " here : "+env.SERVER_URL,
      url: env.SERVER_URL,
      subject: articleDetail.title
    };

    const images = [
        {
            source: {
                uri: imageURL,
            }
        },
    ];

    return (
      <Fragment>
        <ImageWrapper>
          <PkomImageWrapper>
            <TouchableOpacity onPress={() => this.setState({isImageViewVisible: !this.state.isImageViewVisible})}>
              <ProgressiveImage
                thumbnailImageURL={thumbnailImageURL}
                imageURL={imageURL}
              />
            </TouchableOpacity>
            
            <ImageView
              images={images}
              imageIndex={0}
              isVisible={this.state.isImageViewVisible}
              onClose={() => this.setState({isImageViewVisible: !this.state.isImageViewVisible})}
            />
            <TouchableOpacity 
              onPress={() => Share.share(shareOptions)} 
              style={{
                alignSelf: 'center',
                position: 'absolute',
                right: 15,
                top: 35,
                zIndex: 15,
                elevation: (Platform.OS === 'android') ? 50 : 0,
                backgroundColor: "rgba(94,201,255,0.8)",
                borderRadius: 20,
                width: 35,
                height: 35}}>
              <Icon name="share-variant" color="white" size={25} style={{margin: 2.5}} />
            </TouchableOpacity>
          </PkomImageWrapper>
        </ImageWrapper>
      </Fragment>
    );
  }
}

export default Header;
