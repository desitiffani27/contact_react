// @flow

import React from 'react';
import {Text, View, ScrollView, TouchableOpacity} from 'react-native';
import styled from 'styled-components';
import moment from 'moment';
import { WebView } from 'react-native-webview';

const Container = styled(ScrollView)`
  flex: 1;
  padding: ${({theme}) => theme.metrics.extraLargeSize}px;
  padding-top: ${({theme}) => theme.metrics.largeSize * 2}px;
`;

const ArticleContent = styled(View)`
  margin-top: ${({theme}) => theme.metrics.mediumSize}px;
  color: ${({theme}) => theme.colors.subText};
  line-height: 25px;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.2%')}px;
  font-family: Lato;
  height: ${({theme}) => theme.metrics.getHeightFromDP('100%')}px;
  width: ${({theme}) => theme.metrics.getWidthFromDP('90%')}px;
  flex: 1;
`;

const ButtonSection = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

const Separator = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: 2px;
  margin-top: ${({theme}) => theme.metrics.largeSize}px;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({theme}) => theme.colors.lightingDarkLayer};
`;

const TitleText = styled(Text).attrs({
  numberOfLines: 2,
})`
  padding-bottom: ${({theme}) => theme.metrics.extraSmallSize}px;
  padding-right: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: ${({theme}) => theme.colors.darkText};
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'android' ? '5%' : '5.5%';
    return theme.metrics.getWidthFromDP(percentage);
  }};
  font-family: CircularStd-Black;
`;

const DateContent = styled(Text).attrs({
  ellipsizeMode: 'tail',
})`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3%')}px;
  font-family: CircularStd-medium;
  color: ${({theme}) => theme.colors.subSubText};
`;

const CategorySection = styled(View)`
  width: 100%;
  flex-direction: row;
`;
type Props = {
  articleDetail: Object,
  navigation: Object,
};

const Card = ({navigation, articleDetail}: Props): Object => {
  console.log('navigation', navigation);
  console.log('article', articleDetail);
  return (
    <View
      style={{
        flex: 1,
        height: '50%',
        elevation: 12,
        backgroundColor: 'white',
        borderTopRightRadius: 50,
        marginTop: -50,
      }}>
      <Container>
        <TitleText>{articleDetail.title}</TitleText>
        <DateContent>Created at: {moment(articleDetail.created_at, 'YYYY-MM-DD').format('DD MMMM YYYY')}</DateContent>
        <ArticleContent>
          <WebView
            source={{ html: "<style>body { font-size: 250%; word-wrap: break-word; overflow-wrap: break-word; }</style>" + articleDetail.content }}
          />
        </ArticleContent>
        {/* {articleDetail.categoryId && <Separator />}
        {productDetail.categoryId && (
          <Text
            style={{
              fontWeight: 'bold',
              paddingBottom: appStyle.metrics.smallSize,
            }}>
            Category
          </Text>
        )}
        {productDetail.categoryId && (
          <CategorySection>
            <TouchableOpacity
              onPress={async () => {
                // navigation.navigate(HOME_ROUTE_NAMES.PRODUCTS, {
                //   [CONSTANTS.NAVIGATION_PARAM_ID]: productDetail.categoryId,
                // });
                console.log('goto list');
              }}
              style={{
                backgroundColor: appStyle.colors.softPink,
                padding: 10,
                borderRadius: 20,
              }}>
              <Text
                style={{
                  color: appStyle.colors.primaryColor,
                  fontWeight: 'bold',
                }}>
                {productDetail.productCategory.name}
              </Text>
            </TouchableOpacity>
          </CategorySection>
        )} */}
      </Container>
    </View>
  );
};

export default Card;
