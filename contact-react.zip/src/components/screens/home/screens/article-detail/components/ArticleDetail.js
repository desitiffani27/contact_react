// @flow

import React, {Fragment} from 'react';
import {StatusBar, View, TouchableOpacity, Text} from 'react-native';
import env from 'react-native-config';

import styled from 'styled-components';
import Loading from '~/components/common/Loading';

import Header from './Header';
import Card from './card';

const Container = styled(View)`
  flex: 1;
`;
type Props = {
  navigation: Function,
  articleDetail: Object,
  loading: Object,
  error: Object
};

const ArticleCard = ({
  navigation,
  articleDetail,
  loading,
  error,
}: Props): Object => {
  const shouldShowContent =
    Object.keys(articleDetail).length > 0 && !loading && !error;
  return (
    <Fragment>
      <StatusBar
        backgroundColor="transparent"
        barStyle={error || loading ? 'dark-content' : 'light-content'}
        translucent
        animated
      />
      {loading && <Loading />}
      {shouldShowContent && (
        <Container>
          <Header
            thumbnailImageURL={articleDetail.picture}
            imageURL={articleDetail.picture}
            navigation={navigation}
            articleDetail={articleDetail}
          />
          <Card
            articleDetail={articleDetail}
            navigation={navigation}
          />
        </Container>
      )}
    </Fragment>
  );
};

export default ArticleCard;
