// @flow

import React from 'react';
import {Text, View, ScrollView, TouchableOpacity} from 'react-native';
import styled from 'styled-components';
import moment from 'moment';
import { WebView } from 'react-native-webview';
import Icon from 'react-native-vector-icons/FontAwesome';
import AppTheme from '~/styles';

const Container = styled(ScrollView)`
  flex: 1;
  padding: ${({theme}) => theme.metrics.extraLargeSize}px;
  padding-top: ${({theme}) => theme.metrics.largeSize * 2}px;
`;

const InfoContainer = styled(View)`
  margin-top: ${({theme}) => theme.metrics.mediumSize}px;
  border-style: dotted;
  border-width: 1;
  border-color: ${({theme}) => theme.colors.gray};
  padding: ${({theme}) => theme.metrics.smallSize}px;
  padding-end: ${({theme}) => theme.metrics.extraLargeSize * 2}px;
  border-radius: 10px;
`;

const ContentText = styled(Text)`
  font-family: CircularStd-Book;
  color: ${({theme}) => theme.colors.darkText};
`;

const EventContent = styled(View)`
  margin-top: ${({theme}) => theme.metrics.mediumSize}px;
  color: ${({theme}) => theme.colors.subText};
  line-height: 25px;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.2%')}px;
  font-family: Lato;
  height: ${({theme}) => theme.metrics.getHeightFromDP('100%')}px;
  width: ${({theme}) => theme.metrics.getWidthFromDP('90%')}px;
  flex: 1;
`;

const ButtonSection = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

const Separator = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: 2px;
  margin-top: ${({theme}) => theme.metrics.largeSize}px;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({theme}) => theme.colors.lightingDarkLayer};
`;

const TitleText = styled(Text).attrs({
  numberOfLines: 2,
})`
  padding-bottom: ${({theme}) => theme.metrics.extraSmallSize}px;
  padding-right: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: ${({theme}) => theme.colors.darkText};
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'android' ? '5%' : '5.5%';
    return theme.metrics.getWidthFromDP(percentage);
  }};
  font-family: CircularStd-Black;
`;

const DateContent = styled(Text).attrs({
  ellipsizeMode: 'tail',
})`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3%')}px;
  font-family: CircularStd-medium;
  color: ${({theme}) => theme.colors.subSubText};
`;

const CategorySection = styled(View)`
  width: 100%;
  flex-direction: row;
`;
type Props = {
  eventDetail: Object,
  navigation: Object,
};

const Card = ({navigation, eventDetail}: Props): Object => {
  console.log('navigation', navigation);
  console.log('event', eventDetail);
  return (
    <View
      style={{
        flex: 1,
        height: '50%',
        elevation: 12,
        backgroundColor: 'white',
        borderTopRightRadius: 50,
        marginTop: -50,
      }}>
      <Container>
        <TitleText>{eventDetail.title}</TitleText>
        <DateContent>Created at: {moment(eventDetail.created_at, 'YYYY-MM-DD').format('DD MMMM YYYY')}</DateContent>
        
        <InfoContainer>
          <View style={{flexDirection: 'row', }}>
            <Icon name="map-marker" size={23} color={AppTheme.colors.gray} style={{paddingEnd: AppTheme.metrics.smallSize}} />
            <ContentText>{eventDetail.location}</ContentText>
          </View>
          <View style={{flexDirection: 'row', }}>
            <Icon name="clock-o" size={20} color={AppTheme.colors.gray} style={{paddingEnd: AppTheme.metrics.smallSize}} />
            <ContentText>{moment(eventDetail.date + ' ' + eventDetail.time, 'YYYY-MM-DD hh:mm:ss').format('DD MMMM YYYY - HH:mm')}</ContentText>
          </View>
        </InfoContainer>

        <EventContent>
          <WebView
            source={{ html: "<style>body { font-size: 250%; word-wrap: break-word; overflow-wrap: break-word; }</style>" + eventDetail.description }}
          />
        </EventContent>
      </Container>
    </View>
  );
};

export default Card;
