// @flow

import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import {handleHiddenHeaderStyle} from '~/routes/headerUtils';
import EventDetail from './components/EventDetail';
import {CONSTANTS} from '~/utils/CONSTANTS';
import {Creators as EventCreators} from '~/store/ducks/event';
import {HeaderBackButton} from '@react-navigation/stack';

class EventDetailContainer extends Component {
  _subscriptionWillFocusEvent = {};

  componentDidMount() {
    console.log('> EventDetailContainer->componentDidMount: ');
    const {navigation, route, getEventDetailRequest} = this.props;
    navigation.setOptions({tabBarVisible: false});
    const {[CONSTANTS.NAVIGATION_PARAM_ID]: id} = route.params;

    navigation.setOptions({
      headerLeft: props => (
        <HeaderBackButton {...props} onPress={() => this.props.navigation.goBack()} 
          style={{ backgroundColor: "rgba(94,201,255,0.5)", 
                    borderRadius: 20 
        }} />
      ),
    });

    getEventDetailRequest(id);
  }

  static getDerivedStateFromProps(nextProps, state) {
    const {loading, error} = nextProps.eventDetailRequest;
    const {navigation, route} = nextProps;

    handleHiddenHeaderStyle(route, navigation, loading, error);
  }

  componentWillUnmount() {
    //this._subscriptionWillFocusEvent.remove();
  }

  render() {
    const {route, navigation, eventDetailRequest} = this.props;
    console.log('> eventdetailContainer->render');

    return (
      <EventDetail
        eventDetail={eventDetailRequest.detail}
        navigation={navigation}
      />
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators({...EventCreators}, dispatch);
};

const mapStateToProps = state => ({
  eventDetailRequest: state.event,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(EventDetailContainer);
