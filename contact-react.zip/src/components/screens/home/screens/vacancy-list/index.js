// @flow

import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {FlatList, View, RefreshControl, StyleSheet} from 'react-native';
import {SearchBar} from 'react-native-elements';
import Loading from '~/components/common/Loading';
import AppTheme from '~/styles';
import InfoEmpty from '~/components/common/InfoEmpty';
import RenderItemCategory from '../../components/RenderItemCategory';
import {showMessage} from 'react-native-flash-message';
import {handleHiddenHeaderStyle} from '~/routes/headerUtils';
import VacancyCard from '~/components/screens/home/components/VacancyCard';
import {Creators as VacancyCreators} from '~/store/ducks/vacancy';
import styled from 'styled-components';
const Container = styled(View)`
  justify-content: space-between;
  width: 100%;
  height: 100%;
`;
const ListWrapper = styled(View)`
  height: ${({theme}) => theme.metrics.getHeightFromDP('80%')}px;
`;

class VacancyList extends Component {
  _subscriptionWillFocusEvent = {};
  state = {
    isRefreshing: false,
    search: '',
    categoryId: 0,
    page: 1,
    size: 10,
    offset: 0,
    selected: {id: 0, name: 'All'},
    vacancyList: [],
    oldList: [],
  };
  componentDidMount = async () => {
    console.log('> VacancyList->componentDidMount: ');
    // const {getJobCategoryRequest, navigation, route} = this.props;

    // await getJobCategoryRequest();
    this.requestData(1, 10, 0, null, 0, []);
  }

  requestData = (page, size, categoryId, search, offset, oldList) => {
    console.log('> requestData->getVacancyListRequest');
    const {getVacancyListRequest} = this.props;
    getVacancyListRequest(page, size, offset, categoryId, search, oldList);
  };

  static getDerivedStateFromProps(props, state) {
    const {vacancyListRequest} = props;
    const {error: error1, errorMessage: errorMessage1} = vacancyListRequest;

    if (error1 && errorMessage1 !== null) {
      showMessage({
        message: errorMessage1,
        type: 'danger',
        icon: 'danger',
      });
    }

    return {
      isRefreshing: false,
    };
  }

  componentWillUnmount() {
    //this._subscriptionWillFocusEvent.remove();
  }

  updateSearch = search => {
    this.setState({search});
  };

  doSearch = search => {
    this.setState({page: 1});
    this.requestData(1, 10, this.state.selected.id, this.state.search, 0, []);
  };

  doClear = search => {
    this.setState({search: '', page: 1});
    this.requestData(1, 10, this.state.selected.id, '', 0, []);
  };

  renderNullData = () => {
    return (
      <InfoEmpty
        scrollEnabled
        title={'Job vacancy data is empty!'}
        refreshing={this.state.isRefreshing}
        onRefresh={this.onRefreshItem}
      />
    );
  };

  onRefreshItem = () => {
    const {tabItemSelected} = this.state;
    console.log('REFRESHH', tabItemSelected);
    this.requestData(1, 10, this.state.selected.id, null, 0, []);
    this.setState({page: 1, offset: 1, vacancyList: []});
  };

  componentDidUpdate(prevProps, prevState) {
    // console.log(this.state.selected, this.props.faqRequest.category);
    if (
      this.state.selected === null &&
      this.props.vacancyListRequest.jobCategoryList.length > 0
    ) {
      // console.log(this.state.selected, this.props.faqRequest.category);
      this.setState({selected: {id: 0, name: 'All'}});
    }

    if (this.state.selected !== prevState.selected) {
      this.setState({search: this.state.search, page: 1});
      this.requestData(1, 10, this.state.selected.id, this.state.search, 0, []);
    }
  }

  onLoadMoreItem = () => {
    const {page, size, categoryId, selected, search, offset} = this.state;
    const {vacancyListRequest} = this.props;

    const nextPage = page + 1;
    console.log(nextPage, vacancyListRequest.totalPages);
    if (nextPage > 1 && vacancyListRequest.totalPages >= nextPage) {
      this.requestData(
        nextPage,
        size,
        selected.id,
        search,
        0,
        this.state.oldList,
      );
      this.setState({page: nextPage, offset: 0});
    }
  };

  render() {
    const {vacancyListRequest} = this.props;
    const categoryList = [
      ...[{id: 0, name: 'All'}],
      ...vacancyListRequest.jobCategoryList,
    ];
    const dataset = vacancyListRequest.vacancyList;
    console.log(vacancyListRequest);
    this.state.oldList = vacancyListRequest.vacancyList;
    return (
      // <Container>
      <View>
        <SearchBar
          lightTheme
          round
          containerStyle={{
            backgroundColor: AppTheme.colors.primaryColor,
            borderBottomColor: AppTheme.colors.primaryColor,
            borderTopColor: AppTheme.colors.primaryColor,
            paddingLeft: 15,
            paddingRight: 15,
          }}
          inputContainerStyle={{
            backgroundColor: AppTheme.colors.defaultWhite,
            borderColor: 'transparent',
            borderWidth: 0.5,
            paddingLeft: 5,
            elevation: 2,
            height: 35,
          }}
          inputStyle={{fontSize: 14}}
          onChangeText={this.updateSearch}
          onSubmitEditing={this.doSearch}
          onClear={this.doClear}
          value={this.state.search}
          icon={{type: 'font-awesome', name: 'search'}}
          placeholder="Search job vacancy..."
        />
        {/* <FlatList
          style={stylesComponent.listCategory}
          renderItem={({item, index}) => {
            return (
              <RenderItemCategory
                item={item}
                index={index}
                selected={this.state.selected}
                onPress={value => this.setState({selected: value})}
              />
            );
          }}
          keyExtractor={item => item.id}
          showsHorizontalScrollIndicator={false}
          data={categoryList}
          horizontal={true}
        /> */}
        {vacancyListRequest.loading && this.state.page === 1 ? (
          <Loading />
        ) : (
          vacancyListRequest.vacancyList.length > 0 && (
            <ListWrapper>
              <FlatList
                renderItem={({item, index}) => {
                  return (
                    <VacancyCard
                      item={item}
                      isEven={index % 2}
                      isLast={
                        vacancyListRequest.vacancyList.length === index + 1
                      }
                    />
                  );
                }}
                numColumns={1}
                refreshControl={
                  <RefreshControl
                    progressViewOffset={0}
                    refreshing={this.state.isRefreshing}
                    onRefresh={this.onRefreshItem}
                  />
                }
                onEndReached={this.onLoadMoreItem}
                showsVerticalScrollIndicator={false}
                keyExtractor={item => item.id}
                data={vacancyListRequest.vacancyList}
              />
            </ListWrapper>
          )
        )}
        {dataset.length === 0 &&
          vacancyListRequest.loading === false &&
          this.renderNullData()}
      </View>
      // </Container>
    );
  }
}
const stylesComponent = StyleSheet.create({
  // Flatlist
  listCategory: {
    paddingTop: AppTheme.metrics.mediumSize,
    paddingBottom: AppTheme.metrics.mediumSize,
  },
  listItem: {
    flex: 1,
    height: '100%',
    paddingBottom: AppTheme.metrics.mediumSize,
  },

  // Text
  textTopQuestion: {
    color: AppTheme.colors.black,
    fontSize: 18,
    padding: AppTheme.metrics.largeSize,
  },

  container: isStart => {
    return {
      paddingStart: isStart
        ? AppTheme.metrics.largeSize
        : AppTheme.metrics.smallSize,
      paddingEnd: AppTheme.metrics.smallSize,
    };
  },
  containerButton: enable => {
    return [
      {
        padding: AppTheme.metrics.mediumSize,
        borderRadius: AppTheme.metrics.mediumSize,
      },
      enable
        ? {backgroundColor: AppTheme.colors.primaryColor}
        : {borderColor: AppTheme.colors.primaryColor, borderWidth: 1},
    ];
  },

  // Text
  textButton: enable => {
    return [
      {color: AppTheme.colors.primaryColor},
      enable && {color: AppTheme.colors.white},
    ];
  },
});
const mapDispatchToProps = dispatch => {
  return bindActionCreators({...VacancyCreators }, dispatch);
};

const mapStateToProps = state => ({
  vacancyListRequest: state.vacancy,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(VacancyList);
