// @flow

import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';

import {handleHiddenHeaderStyle} from '~/routes/headerUtils';
import VacancyDetail from './components/VacancyDetail';
import {CONSTANTS} from '~/utils/CONSTANTS';
import {Creators as VacancyCreators} from '~/store/ducks/vacancy';
import {HeaderBackButton} from '@react-navigation/stack';

class VacancyDetailContainer extends Component {
  _subscriptionWillFocusEvent = {};

  componentDidMount() {
    console.log('> VacancyDetailContainer->componentDidMount: ');
    const {navigation, route} = this.props;
    navigation.setOptions({tabBarVisible: false});
    const {[CONSTANTS.NAVIGATION_PARAM_ID]: data} = route.params;

    navigation.setOptions({
      headerLeft: props => (
        <HeaderBackButton {...props} onPress={() => this.props.navigation.goBack()} 
          style={{ backgroundColor: "rgba(94,201,255,0.5)", 
                    borderRadius: 20 
        }} />
      ),
    });

    //getVacancyDetail(id);
  }

  static getDerivedStateFromProps(nextProps, state) {
    const {loading, error} = nextProps.vacancyDetailRequest;
    const {navigation, route} = nextProps;

    handleHiddenHeaderStyle(route, navigation, loading, error);
  }

  componentWillUnmount() {
    //this._subscriptionWillFocusEvent.remove();
  }

  render() {
    const {route, navigation, postCartRequest} = this.props;
    const {[CONSTANTS.NAVIGATION_PARAM_ID]: data} = route.params;
    console.log('> vacancyDetailContainer->render');
    const {productDetailRequest} = this.props;

    return (
      <VacancyDetail
        vacancyDetail={data}
        navigation={navigation}
      />
    );
  }
}

const mapDispatchToProps = dispatch => {
  return bindActionCreators({...VacancyCreators}, dispatch);
};

const mapStateToProps = state => ({
  vacancyDetailRequest: state.vacancy,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(VacancyDetailContainer);
