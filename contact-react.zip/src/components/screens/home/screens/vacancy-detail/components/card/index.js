// @flow

import React from 'react';
import {Text, View, ScrollView, TouchableOpacity, Linking} from 'react-native';
import styled from 'styled-components';
import Header from './Header';
import appStyle from '~/styles';
import HTML from 'react-native-render-html';
const Container = styled(ScrollView)`
  flex: 1;
  padding-horizontal: ${({theme}) => theme.metrics.extraLargeSize}px;
  padding-top: 10px;
`;

const CompanyName = styled(Text)`
  margin-top: ${({theme}) => theme.metrics.mediumSize}px;
  color: ${({theme}) => theme.colors.green};
  line-height: 15px;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.2%')}px;
  font-family: Lato;
`;

const ButtonSection = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;

const Separator = styled(View)`
  width: 100%;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: 2px;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({theme}) => theme.colors.lightingDarkLayer};
`;

const CategorySection = styled(View)`
  width: 100%;
  flex-direction: row;
`;

const LabelText = styled(Text)`
  margin-top: ${({theme}) => theme.metrics.mediumSize}px;
  color: ${({theme}) => theme.colors.subSubText};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3.2%')}px;
  font-family: Lato;
`;

const PkomContent = styled(Text)`
  color: ${({theme}) => theme.colors.subText};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4%')}px;
  font-family: Lato;
`;

type Props = {
  vacancyDetail: Object,
  navigation: Object
};

const Card = ({navigation, vacancyDetail}: Props): Object => {
  return (
    <View
      style={{
        flex: 1,
        elevation: 12,
        backgroundColor: 'white',
        borderTopRightRadius: 50,
        marginTop: -50,
      }}>
      <Container>
        <Header title={vacancyDetail.title} />
        <CompanyName>{vacancyDetail.company.name}</CompanyName>
        {vacancyDetail.job_category_id && (
          <LabelText
            style={{
              paddingBottom: appStyle.metrics.smallSize,
            }}>
            Category
          </LabelText>
        )}
        {vacancyDetail.job_category_id && (
          <CategorySection>
            <TouchableOpacity
              onPress={async () => {
                // navigation.navigate(HOME_ROUTE_NAMES.PRODUCTS, {
                //   [CONSTANTS.NAVIGATION_PARAM_ID]: productDetail.categoryId,
                // });
                console.log('goto list');
              }}
              style={{
                backgroundColor: appStyle.colors.softBlue,
                padding: 10,
                borderRadius: 20,
              }}>
              <Text
                style={{
                  color: appStyle.colors.white,
                  fontWeight: 'bold',
                }}>
                {vacancyDetail.category.name}
              </Text>
            </TouchableOpacity>
          </CategorySection>
        )}

        <LabelText>Job Description</LabelText>
        <HTML
          html={vacancyDetail.job_description}
        />
        <LabelText>Responsibility</LabelText>
        <HTML
          html={vacancyDetail.responsibility}
        />
        <LabelText>Requirement</LabelText>
        <HTML
          html={vacancyDetail.requirement}
        />
        <LabelText>Deadline</LabelText>
        <PkomContent>{vacancyDetail.deadline}</PkomContent>
        <LabelText>Location</LabelText>
        <PkomContent>{vacancyDetail.location}</PkomContent>
        <LabelText>Quota</LabelText>
        <PkomContent>{vacancyDetail.quota}</PkomContent>
        <LabelText>Other Information</LabelText>
        <PkomContent>{vacancyDetail.other_information}</PkomContent>
        <LabelText>No. Whatsapp</LabelText>
        <PkomContent>{vacancyDetail.no_whatsapp}</PkomContent>
        <LabelText></LabelText>
      </Container>
      <TouchableOpacity
        onPress={async () => {
          Linking.openURL('whatsapp://send?text=Halo, saya tertarik dengan lowongan ini: '+ vacancyDetail.title +'&phone='+ vacancyDetail.no_whatsapp)
        }}
        style={{
          backgroundColor: appStyle.colors.primaryColor,
          width: '100%',
          padding: 10,
        }}>
        <ButtonSection>
          {/* <Icon name={icon} size={25} color={'white'} /> */}
          <Text
            style={{
              color: 'white',
              fontWeight: 'bold',
              fontSize: 17,
              paddingStart: 5,
            }}>
            Contact Now
          </Text>
        </ButtonSection>
      </TouchableOpacity>
    </View>
  );
};

export default Card;
