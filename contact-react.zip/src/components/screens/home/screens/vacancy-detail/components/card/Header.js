// @flow

import React from 'react';
import {Platform, Text, View} from 'react-native';
import styled from 'styled-components';
import appStyles from '~/styles';
import {currencyFormat} from '~/utils/helpers';
import ReviewStars from '~/components/common/ReviewStars';
const ContentWrapper = styled(View)`
  width: 100%;
`;

const TitleWrapper = styled(View)`
  width: 100%;
  flex-direction: row;
`;

const ProjectTitle = styled(Text).attrs({
  numberOfLines: 2,
})`
  width: 70%;
  padding-bottom: ${({theme}) => theme.metrics.extraSmallSize}px;
  padding-right: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: ${({theme}) => theme.colors.darkText};
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'android' ? '5%' : '5.5%';
    return theme.metrics.getWidthFromDP(percentage);
  }};
  font-family: CircularStd-Black;
`;
const PriceTitle = styled(Text).attrs({
  numberOfLines: 1,
})`
  width: 30%;
  padding-bottom: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: ${({theme}) => theme.colors.green};
  font-size: ${({theme}) => {
    const percentage = Platform.OS === 'android' ? '5%' : '5.5%';
    return theme.metrics.getWidthFromDP(percentage);
  }};
  font-family: CircularStd-Book;
`;
type Props = {
  title: string,
  price: string,
};

const ProductInfo = ({title}: Props) => (
  <ContentWrapper>
    <TitleWrapper style={{justifyContent: 'space-between'}}>
      <ProjectTitle>{title}</ProjectTitle>
    </TitleWrapper>
    <TitleWrapper>
      {/* {ReviewStars({
        shouldShowReviewsText: false,
        isSmall: false,
        reviews: 0,
        stars: 4,
        textColor: 'darkText',
      })}
      <Text
        style={{
          textAlign: 'right',
          color: appStyles.colors.subSubText,
          paddingLeft: 10,
        }}>
        50 Reviews
      </Text> */}
    </TitleWrapper>
  </ContentWrapper>
);

export default ProductInfo;
