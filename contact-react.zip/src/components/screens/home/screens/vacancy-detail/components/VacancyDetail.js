// @flow

import React, {Fragment} from 'react';
import {StatusBar, View, TouchableOpacity, Text} from 'react-native';
import env from 'react-native-config';

import styled from 'styled-components';
import Loading from '~/components/common/Loading';

import Header from './Header';
import Card from './card';

const Container = styled(View)`
  flex: 1;
`;
type Props = {
  navigation: Function,
  vacancyDetail: Object,
  loading: Object,
  error: Object,
};

const VacancyDetail = ({
  navigation,
  vacancyDetail,
  loading,
  error,
}: Props): Object => {
  const shouldShowContent =
    Object.keys(vacancyDetail).length > 0 && !loading && !error;
  return (
    <Fragment>
      <StatusBar
        backgroundColor="transparent"
        barStyle={error || loading ? 'dark-content' : 'light-content'}
        translucent
        animated
      />
      {loading && <Loading />}
      {shouldShowContent && (
        <Container>
          <Header
            thumbnailImageURL={vacancyDetail.picture}
            imageURL={vacancyDetail.picture}
            navigation={navigation}
            vacancyDetail={vacancyDetail}
          />
          <Card
            vacancyDetail={vacancyDetail}
            navigation={navigation}
          />
        </Container>
      )}
    </Fragment>
  );
};

export default VacancyDetail;
