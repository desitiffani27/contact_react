// @flow

import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {FlatList, View, StyleSheet, RefreshControl} from 'react-native';
import {SearchBar} from 'react-native-elements';
import Loading from '~/components/common/Loading';
import InfoEmpty from '~/components/common/InfoEmpty';
import RenderItemCategory from '../../components/RenderItemCategory';
import AppTheme from '~/styles';
import {showMessage} from 'react-native-flash-message';
import {handleHiddenHeaderStyle} from '~/routes/headerUtils';
import ArticleCard from '~/components/screens/home/components/ArticleCard';
import {Creators as ArticleCreators} from '~/store/ducks/article';
import styled from 'styled-components';
const Container = styled(View)`
  justify-content: space-between;
  width: 100%;
  height: 100%;
`;
const ListWrapper = styled(View)`
  height: ${({theme}) => theme.metrics.getHeightFromDP('68%')}px;
`;

class ArticleList extends Component {
  _subscriptionWillFocusEvent = {};
  state = {
    isRefreshing: false,
    search: '',
    categoryId: 0,
    page: 1,
    size: 10,
    offset: 0,
    selected: {id: 0, name: 'All'},
    articleList: [],
    oldList: [],
  };
  componentDidMount = async () => {
    console.log('> ArticleList->componentDidMount: ');
    const {navigation, route} = this.props;
    // navigation.setOptions({tabBarVisible: false});
    // const {[CONSTANTS.NAVIGATION_PARAM_ID]: id} = route.params;

    // this._subscriptionWillFocusEvent = navigation.addListener('willFocus', () =>
    //   handleHiddenHeaderStyle(route, navigation, false, false),
    // );

    // await getArticleCategoryRequest();
    this.requestData(1, 10, 0, null, 0, []);
  }

  requestData = (page, size, categoryId, search, offset, oldList) => {
    console.log('> requestData->getArticleListRequest');
    const {getArticleListRequest} = this.props;
    getArticleListRequest(page, size, offset, categoryId, search, oldList);
  };

  static getDerivedStateFromProps(props, state) {
    const {articleListRequest} = props;
    const {error: error1, errorMessage: errorMessage1} = articleListRequest;

    if (error1 && errorMessage1 !== null) {
      showMessage({
        message: errorMessage1,
        type: 'danger',
        icon: 'danger',
      });
    }

    return {
      isRefreshing: false,
    };
  }

  componentWillUnmount() {
    //this._subscriptionWillFocusEvent.remove();
  }

  updateSearch = search => {
    this.setState({search});
  };

  doSearch = search => {
    this.setState({page: 1});
    this.requestData(1, 10, this.state.selected.id, this.state.search, 0, []);
  };

  doClear = search => {
    this.setState({search: '', page: 1});
    this.requestData(1, 10, this.state.selected.id, '', 0, []);
  };

  renderNullData = () => {
    return (
      <InfoEmpty
        scrollEnabled
        title={'Article data is empty!'}
        refreshing={this.state.isRefreshing}
        onRefresh={this.onRefreshItem}
      />
    );
  };

  onRefreshItem = () => {
    const {tabItemSelected} = this.state;
    console.log('REFRESHH', tabItemSelected);
    this.requestData(1, 10, this.state.selected.id, null, 0, []);
    this.setState({page: 1, offset: 1, productList: []});
  };

  // componentDidUpdate(prevProps, prevState) {
  //   // console.log(this.state.selected, this.props.faqRequest.category);
  //   if (
  //     this.state.selected === null &&
  //     this.props.articleListRequest.articleCategoryList.length > 0
  //   ) {
  //     // console.log(this.state.selected, this.props.faqRequest.category);
  //     this.setState({selected: {id: 0, name: 'All'}});
  //   }

  //   if (this.state.selected !== prevState.selected) {
  //     this.setState({search: this.state.search, page: 1});
  //     this.requestData(1, 10, this.state.selected.id, this.state.search, 0, []);
  //   }
  // }

  onLoadMoreItem = () => {
    const {page, size, categoryId, selected, search, offset} = this.state;
    const {articleListRequest} = this.props;

    const nextPage = page + 1;
    console.log(nextPage, articleListRequest.totalPages);
    if (nextPage > 1 && articleListRequest.totalPages >= nextPage) {
      this.requestData(
        nextPage,
        size,
        selected.id,
        search,
        0,
        this.state.oldList,
      );
      this.setState({page: nextPage, offset: 0});
    }
  };

  render() {
    console.log('> PkomDetailContainer->render');
    const {articleListRequest} = this.props;
    const dataset = articleListRequest.articleList;
    this.state.oldList = articleListRequest.articleList;
    return (
      // <Container>
      <View>
        <SearchBar
          lightTheme
          round
          containerStyle={{
            backgroundColor: AppTheme.colors.primaryColor,
            borderBottomColor: AppTheme.colors.primaryColor,
            borderTopColor: AppTheme.colors.primaryColor,
            paddingLeft: 15,
            paddingRight: 15,
          }}
          inputContainerStyle={{
            backgroundColor: AppTheme.colors.defaultWhite,
            borderColor: 'transparent',
            borderWidth: 0.5,
            paddingLeft: 5,
            elevation: 2,
            height: 35,
          }}
          inputStyle={{fontSize: 14}}
          onChangeText={this.updateSearch}
          onSubmitEditing={this.doSearch}
          onClear={this.doClear}
          value={this.state.search}
          icon={{type: 'font-awesome', name: 'search'}}
          placeholder="Search article..."
        />
        {/* <FlatList
          style={stylesComponent.listCategory}
          renderItem={({item, index}) => {
            return (
              <RenderItemCategory
                item={item}
                index={index}
                selected={this.state.selected}
                onPress={value => this.setState({selected: value})}
              />
            );
          }}
          keyExtractor={item => item.id}
          showsHorizontalScrollIndicator={false}
          data={categoryList}
          horizontal={true}
        /> */}
        {articleListRequest.loading && this.state.page === 1 ? (
          <Loading />
        ) : (
          articleListRequest.articleList.length > 0 && (
            <ListWrapper>
              <FlatList
                renderItem={({item, index}) => {
                  return <ArticleCard item={item} isFirst={index === 0} isLoggedIn={true} />;
                }}
                numColumns={2}
                contentContainerStyle={{
                  paddingTop: 10,
                }}
                refreshControl={
                  <RefreshControl
                    progressViewOffset={0}
                    refreshing={this.state.isRefreshing}
                    onRefresh={this.onRefreshItem}
                  />
                }
                onEndReached={this.onLoadMoreItem}
                showsVerticalScrollIndicator={false}
                keyExtractor={item => item.id}
                data={articleListRequest.articleList}
              />
            </ListWrapper>
          )
        )}
        {dataset.length === 0 &&
          articleListRequest.loading === false &&
          this.renderNullData()}
      </View>
      // </Container>
    );
  }
}
const stylesComponent = StyleSheet.create({
  // Flatlist
  listCategory: {
    paddingTop: AppTheme.metrics.mediumSize,
    paddingBottom: AppTheme.metrics.mediumSize,
  },
  listItem: {
    flex: 1,
    height: '100%',
    paddingBottom: AppTheme.metrics.mediumSize,
  },

  // Text
  textTopQuestion: {
    color: AppTheme.colors.black,
    fontSize: 18,
    padding: AppTheme.metrics.largeSize,
  },

  container: isStart => {
    return {
      paddingStart: isStart
        ? AppTheme.metrics.largeSize
        : AppTheme.metrics.smallSize,
      paddingEnd: AppTheme.metrics.smallSize,
    };
  },
  containerButton: enable => {
    return [
      {
        padding: AppTheme.metrics.mediumSize,
        borderRadius: AppTheme.metrics.mediumSize,
      },
      enable
        ? {backgroundColor: AppTheme.colors.primaryColor}
        : {borderColor: AppTheme.colors.primaryColor, borderWidth: 1},
    ];
  },

  // Text
  textButton: enable => {
    return [
      {color: AppTheme.colors.primaryColor},
      enable && {color: AppTheme.colors.white},
    ];
  },
});
const mapDispatchToProps = dispatch =>
  bindActionCreators(ArticleCreators, dispatch);

const mapStateToProps = state => ({
  articleListRequest: state.article,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ArticleList);
