// @flow

import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import styled from 'styled-components';

const HeaderWrapper = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: ${({theme}) =>
    `${theme.metrics.extraSmallSize}px ${theme.metrics.smallSize}px ${
      theme.metrics.extraSmallSize
    }px  ${theme.metrics.largeSize}px`};
`;

const SectionText = styled(Text)`
  color: ${({theme}) => theme.colors.darkText};
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.6%')}px;
  margin-bottom: 5px;
  margin-top: 15px;
`;

const SectionTextViewAll = styled(Text)`
  color: ${({theme}) => theme.colors.primaryColor};
  padding-right: 10px;
  font-family: CircularStd-Medium;
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.0%')}px;
  margin-bottom: 8px;
`;

const renderSectionHeader = (
  navigation: Object,
  title: string,
  routeName: string,
): Object => {
  console.log('> renderSectionHeader');
  return (
    <HeaderWrapper>
      <SectionText>{title}</SectionText>
      {/* <TouchableOpacity
        onPress={() => {
          navigation.navigate(routeName);
        }}>
        <SectionTextViewAll>View All</SectionTextViewAll>
      </TouchableOpacity> */}
    </HeaderWrapper>
  );
};

type Props = {
  navigation: Object,
  children: Object,
  title: string,
  routeName: string,
};

const Section = ({title, navigation, children, routeName}: Props) => {
  console.log('> Section');
  return (
    <View>
      {renderSectionHeader(navigation, title, routeName)}
      {children}
    </View>
  );
};

export default Section;
