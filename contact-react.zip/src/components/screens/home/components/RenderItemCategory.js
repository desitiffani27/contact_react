import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import styles from '~/styles';

const RenderItemCategory = ({item, index, onPress, selected}) => {
  const stylesComponent = StyleSheet.create({
    // View
    container: isStart => {
      return {
        paddingStart: isStart
          ? styles.metrics.largeSize
          : styles.metrics.smallSize,
        paddingEnd: styles.metrics.smallSize,
      };
    },
    containerButton: enable => {
      return [
        {
          padding: styles.metrics.mediumSize,
          borderRadius: styles.metrics.mediumSize,
        },
        enable
          ? {backgroundColor: styles.colors.primaryColor}
          : {borderColor: styles.colors.primaryColor, borderWidth: 1},
      ];
    },

    // Text
    textButton: enable => {
      return [
        {color: styles.colors.primaryColor},
        enable && {color: styles.colors.white},
      ];
    },
  });

  if (selected === null) {
    return <View />;
  }

  return (
    <TouchableOpacity activeOpacity={0.7} onPress={() => onPress(item)}>
      <View style={stylesComponent.container(index === 0)}>
        <View style={stylesComponent.containerButton(item.id === selected.id)}>
          <Text style={stylesComponent.textButton(item.id === selected.id)}>
            {item.name}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default RenderItemCategory;
