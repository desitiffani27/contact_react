// @flow

import React, {Component} from 'react';
import {TouchableWithoutFeedback, Image, Text, View, Linking, Modal, BackHandler } from 'react-native';
import {useNavigation} from '@react-navigation/native';
import styled from 'styled-components';
import {
  ROUTE_NAMES as HOME_ROUTE_NAMES,
  CONSTANTS,
} from '../../../../utils/CONSTANTS';
import moment from 'moment';
import {AuthContext} from '../../../../context';
import AppTheme from '~/styles';
import {TouchableOpacity} from 'react-native-gesture-handler';
import ImageModal from 'react-native-image-modal';
import {Icon} from 'react-native-elements';

const Container = styled(View)`
  flex: 1;
  padding-left: ${({theme, isFirst}) => theme.metrics.largeSize}px;
  padding-right: ${({theme}) => theme.metrics.largeSize}px;
  margin-bottom: 10px;
  align-content: center;
  flex-direction: row;
  justify-content: center;
`;

const ContainerWrapper = styled(View)`
  flex: 1;
  flex-direction: row;
  padding-top: 10px;
  border-radius: 8px;
  justify-content: center;
  background-color: ${({theme}) => theme.colors.white};
`;

const BottomContentWrapper = styled(View)`
  flex: 1;
  width: ${({theme}) => theme.metrics.getWidthFromDP('100%')}px;
  border-bottom-start-radius: 10px;
  border-bottom-end-radius: 10px;
  padding: ${({theme}) => theme.metrics.smallSize}px;
  justify-content: flex-start;
  bottom: 0;
`;

const ProjectTitle = styled(Text).attrs({
  ellipsizeMode: 'tail',
  numberOfLines: 2,
})`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.2%')}px;
  font-family: CircularStd-Bold;
  paddingHorizontal: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: ${({theme}) => theme.colors.black};
`;

const TextContent = styled(Text)`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3.7%')}px;
  font-family: CircularStd-Book;
  padding: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: #181D27;
`;

const SmallTextContent = styled(Text).attrs({
  ellipsizeMode: 'tail',
  numberOfLines: 2,
})`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3%')}px;
  font-family: CircularStd-Book;
  paddingHorizontal: ${({theme}) => theme.metrics.extraSmallSize}px;
  paddingBottom: ${({theme}) => theme.metrics.extraSmallSize}px;
  color: ${({theme}) => theme.colors.subText};
`;

const DateContent = styled(Text)`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3.7%')}px;
  font-family: CircularStd-Book;
  color: ${({theme}) => theme.colors.green};
  padding: ${({theme}) => theme.metrics.extraSmallSize}px;
  margin-vertical: 5px;
`;

const SmallButton = styled(TouchableOpacity)`
  justify-content: center;
  width: ${({theme}) => theme.metrics.getWidthFromDP('42%')}px;
  align-items: center;
  margin-top: ${({theme}) => theme.metrics.extraSmallSize}px;
  margin-bottom: ${({theme}) => theme.metrics.mediumSize}px;
  background-color: ${({theme}) => theme.colors.primaryColor};
  border-radius: 5px;
  padding-vertical: 5px;
  margin-horizontal: 4px;
`;

const ButtonText = styled(Text)`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('3.7%')}px;
  font-family: CircularStd-Medium;
  color: ${({theme}) => theme.colors.white};
`;

let imageModalRef;
const StrCard = props => {
  const {isFirst, item, isOperasional, onSaved} = props;
  const [isModalImageVisible, setModalImageVisible] = React.useState(false);
  const navigation = useNavigation();
  const {goToLogin} = React.useContext(AuthContext);

  const renderContent = item => {
    return (
      <BottomContentWrapper>
        <View style={{flexDirection: 'row'}}>
          {item.image != "" && item.image != null && (
            <View style={{marginRight: AppTheme.metrics.extraSmallSize}}>
              <ImageModal
                source={{
                  uri: item.image,
                }}
                style={{
                  height: AppTheme.metrics.getWidthFromDP('30%'),
                  width: AppTheme.metrics.getWidthFromDP('30%'),
                }}
                resizeMode="contain"
                imageBackgroundColor={AppTheme.colors.transparentWhite}
              />
            </View>
          )}
          
          <View style={{flex: 1}}>
            {isOperasional && (<ProjectTitle>{item.nama}</ProjectTitle>)}
            <ProjectTitle style={{paddingBottom: isOperasional ? 0 : AppTheme.metrics.extraSmallSize}}>{isOperasional ? item.no_surat : item.no_str}</ProjectTitle>
            {isOperasional && (<SmallTextContent>Instansi: {item.instansi_pemberi_izin}</SmallTextContent>)}
            <TextContent>Tanggal Keluar: {moment(item.tgl_terbit).format('DD-MM-YYYY')}</TextContent>
            <TextContent>Berlaku Hingga: {moment(item.tgl_berlaku).format('DD-MM-YYYY')}</TextContent>
            <DateContent style={[item.status === "aktif" ? {color: AppTheme.colors.green} : item.status === "warning" ? {color: AppTheme.colors.orange} : {color: AppTheme.colors.red}]}>
              Masa berlaku tersisa: {expirationEstimations(item.tgl_berlaku)}
            </DateContent>
            {/* <TextContent>{item.file}</TextContent> */}
          </View>
        </View>

        <View style={{flexDirection: 'row', width: "100%"}}>
            <SmallButton onPress={() => {
              if(item.file != null && item.file != ""){
                if(item.file.substr(item.file.length - 3) == "pdf"){
                  Linking.openURL(item.file)
                }else{
                  setModalImageVisible(!isModalImageVisible);
                  setTimeout(() => {
                    imageModalRef._open();
                  }, 100);
                } 
              }
                      
            }}>
              <ButtonText>Lihat {isOperasional ? 'Dokumen' : 'STR'}</ButtonText>
            </SmallButton>
            <SmallButton onPress={() => {
              navigation.navigate(HOME_ROUTE_NAMES.FORM_STR, {
                [CONSTANTS.DATA]: item,
                [CONSTANTS.FUNCTION]: onSaved,
                isOperasional: isOperasional
              });
            }}>
              <ButtonText>Perbarui</ButtonText>
            </SmallButton>
          </View>
      </BottomContentWrapper>
    );
  };

  const expirationEstimations = (expiredDate) =>{
    var given = moment(expiredDate, "YYYY-MM-DD");
    var current = moment().startOf('day');
    var days = moment.duration(given.diff(current)).asDays();

    if(days > 365){
      current = moment().startOf('years');
      return moment.duration(given.diff(current)).years() + " tahun";
    }else if (days > 30){
      current = moment().startOf('months');
      return moment.duration(given.diff(current)).months() + " bulan";
    }else if (days > 7){
      current = moment().startOf('weeks');
      return moment.duration(given.diff(current)).weeks() + " minggu";
    }else{
      return days + " hari";
    }
  };

  const renderImageModal = (file) => {
    return (
      <Modal visible={isModalImageVisible}>
        <ImageModal
          ref={ref => {
            imageModalRef = ref;
          }}
          resizeMode="contain"
          imageBackgroundColor="#000000"
          style={{
            width: AppTheme.metrics.getWidthFromDP('100%'),
            height: AppTheme.metrics.getHeightFromDP('100%'),
          }}
          source={{
            uri: file,
          }}
          willClose={() => setModalImageVisible(false)}
        />
      </Modal>
    );
  };

  return (
    <Container isFirst={isFirst}>
      <TouchableWithoutFeedback
        // onPress={() => {
        //   navigation.navigate(HOME_ROUTE_NAMES.EVENT_DETAIL, 
        //     {[CONSTANTS.NAVIGATION_PARAM_ID]: typeof item.id !== 'undefined' ? item.id : item.event_id});
        // }}
        style={{flex: 1}}>
        <ContainerWrapper>
          {renderImageModal(item.file)}
          {renderContent(item)}
        </ContainerWrapper>
      </TouchableWithoutFeedback>
    </Container>
  );
};

export default StrCard;
