/* eslint-disable react/no-did-mount-set-state */
import React, {Component} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  PermissionsAndroid 
} from 'react-native';

import {Creators as PerizinanEditCreators} from '~/store/ducks/perizinan';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import {showMessage} from 'react-native-flash-message';
import {ROUTE_NAMES, CONSTANTS} from '~/utils/CONSTANTS';
import CustomTextInput from './components/CustomTextInput';
import moment from 'moment';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import DocumentPicker from 'react-native-document-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import Loading from '~/components/common/Loading';
import AppTheme from '~/styles';
import styled from 'styled-components';
import { ScrollView } from 'react-native-gesture-handler';

const SubmitButton = styled(TouchableOpacity)`
  justify-content: center;
  align-items: center;
  margin-vertical: ${({theme}) => theme.metrics.mediumSize}px;
  background-color: ${({theme}) => theme.colors.primaryColor};
  border-radius: 5px;
  padding-vertical: 10px;
`;

const ButtonText = styled(Text)`
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('4.2%')}px;
  font-family: CircularStd-Medium;
  color: ${({theme}) => theme.colors.white};
`;

class FormStr extends Component {
  oldState = null;
  state = {
    id: 0,
    doScroll: false,
    file: null,
    namaPerizinan: null,
    noReg: null,
    tglKeluar: null,
    tglBerlaku: null,
    filePickerResult: [],
    isOperasional: false
  };

  componentDidMount() {
    const {route} = this.props;
    const {[CONSTANTS.DATA]: data, isOperasional} = route.params;
    this.setState({
      namaPerizinan: isOperasional ? data.nama : null,
      noReg: isOperasional ? data.no_surat : data.no_str,
      tglKeluar: moment(data.tgl_terbit),
      tglBerlaku: moment(data.tgl_berlaku),
      id: data.id,
      isOperasional: isOperasional
    });

    
    // this.props.navigation.setOptions({
    //   headerLeft: props => (
    //     <HeaderBackButton {...props} onPress={this.handleBackButton} />
    //   ),
    // });
    
    // BackHandler.addEventListener('hardwareBackPress', this.actionBack);
    // console.log(data)
  }

  componentWillUnmount() {
    // BackHandler.removeEventListener('hardwareBackPress', this.actionBack);
  }

  actionBack = () => {
    // this.handleBackButton();
    return true;
  };

  handleBackButton = () => {
    if (this.state !== this.oldState) {
      Alert.alert(
        'Konfirmasi',
        'Apakah anda yakin akan kembali tanpa menyimpan perubahan?',
        [
          {
            text: 'Cancel',
            onPress: () => console.log('Cancel Pressed'),
            style: 'cancel',
          },
          {
            text: 'Go Back',
            onPress: () => {
              this.props.navigation.goBack();
            },
          },
        ],
      );
    } else {
      this.props.navigation.goBack();
    }
  };

  saveForm = () => {
    const {postPerizinanEditRequest} = this.props;
    this.validator() &&
    postPerizinanEditRequest({
      no_surat: this.state.noReg,
      tgl_terbit: this.state.tglKeluar.format('YYYY-MM-DD'),
      tgl_berlaku: this.state.tglBerlaku.format('YYYY-MM-DD'),
      id: this.state.id,
      file: this.state.filePickerResult.length > 0 ? this.state.filePickerResult[0] : "",
      isOperasional: this.state.isOperasional
    }, (response) =>{
      console.log(response);
      if(response.message.error){
        console.warn("inikan?", response.message.error[0])
        this.showFormError(response.message.error[0], 'error');
      }else{
        this.showFormError(response.message.success[0], 'success');
      }
      // if(this.state.avatarSource != null){
      //   postProfilePictureEditRequest(this.state.avatarSource);
      // }
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.perizinanEditRequest.dataEdit !==
      prevProps.perizinanEditRequest.dataEdit
    ) {
      const {route, navigation} = this.props;
      // const {[CONSTANTS.FUNCTION]: onPerizinanChanged} = route.params;
      // onPerizinanChanged(this.props.perizinanEditRequest.dataEdit);
      navigation.goBack();
    }
  }

  validator = () => {
    console.log('validator');
    if (!this.state.filePickerResult) {
      this.showFormError('Dokumen Surat Perizinan harus dipilih', 'error');
      return false;
    }
    if (!this.state.noReg) {
      this.showFormError('Nomor Surat Tanda Registrasi tidak boleh kosong', 'error');
      return false;
    }
    if (!this.state.tglKeluar) {
      this.showFormError('Tanggal Keluar tidak boleh kosong', 'error');
      return false;
    }
    if (!this.state.tglBerlaku) {
      this.showFormError('Tanggal Berlaku Hingga tidak boleh kosong', 'error');
      return false;
    }
    if (this.state.filePickerResult.length == 0) {
      this.showFormError('Dokumen tidak boleh kosong', 'error');
      return false;
    }
   
    return true;
  };

  showFormError = (message, type) => {
    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
      style: {marginBottom:35}
    });
  };

  responseDatePicker1 = (event, date1) => {
    this.setState({isShowDatePicker1: false});
    if (date1) {
      this.setState({tglKeluar: moment(date1)});
    }
  };
  responseDatePicker2 = (event, date2) => {
    this.setState({isShowDatePicker2: false});
    if (date2) {
      this.setState({tglBerlaku: moment(date2)});
    }
  };

  showFilePicker = async() => {
    try {
      const pickerResult = await DocumentPicker.pick({
        presentationStyle: 'fullScreen',
        copyTo: 'cachesDirectory',
        allowMultiSelection: false,
        type: [DocumentPicker.types.pdf, DocumentPicker.types.images]
      });
      this.setState({filePickerResult: [pickerResult]});
      console.warn(this.state.filePickerResult)
    } catch (e) {
      this.handleErrorFilePicker(e)
    }
  };

  handleErrorFilePicker = (err: unknown) => {
    console.warn(err);
    // if (DocumentPicker.isCancel(err)) {
    //   console.warn('cancelled')
    //   // User cancelled the picker, exit any dialogs or menus and move on
    // } else if (DocumentPicker.isInProgress(err)) {
    //   console.warn('multiple pickers were opened, only the last will be considered')
    // } else {
    //   throw err
    // }
  }

  render() {
    if (this.props.perizinanEditRequest.loading) {
      return <Loading />;
    }
    
    return (
      <ScrollView>
        <View style={{flex: 1, backgroundColor: AppTheme.colors.background}}>
          {/* Modal */}
          {this.state.isShowDatePicker1 && (
            <DateTimePicker
              value={
                this.state.tglKeluar
                  ? this.state.tglKeluar.toDate()
                  : new Date()
              }
              mode={'date'}
              display="default"
              onChange={this.responseDatePicker1}
            />
          )}
          {this.state.isShowDatePicker2 && (
            <DateTimePicker
              value={
                this.state.tglBerlaku
                  ? this.state.tglBerlaku.toDate()
                  : new Date()
              }
              mode={'date'}
              display="default"
              minimumDate={this.state.tglKeluar.toDate()}
              onChange={this.responseDatePicker2}
            />
          )}

          <View style={{padding: AppTheme.metrics.extraLargeSize}}>
            {this.state.isOperasional && (
              <CustomTextInput
                title={'Nama Operasional / Kalibrasi'}
                placeholder={this.state.namaPerizinan}
                value={this.state.namaPerizinan}
                readonly={true}
              />
            )}
            <CustomTextInput
                title={this.state.isOperasional ? 'Nomor Surat' : 'Nomor Surat Tanda Registrasi'}
                placeholder={'-'}
                value={this.state.noReg}
                onChangeText={text => {
                  this.setState({noReg: text});
                }}
              />

            <CustomTextInput
              title={'Tanggal Keluar'}
              placeholder={'DD-MM-YYYY'}
              value={
                this.state.tglKeluar
                  ? this.state.tglKeluar.format('DD-MM-YYYY')
                  : null
              }
              type='date'
              onPress={() => {
                this.setState({
                  isShowDatePicker1: !this.state.isShowDatePicker1,
                });
              }}
              iconRight={"date-range"}
            />

            <CustomTextInput
              title={'Berlaku Hingga'}
              placeholder={'DD-MM-YYYY'}
              value={
                this.state.tglBerlaku
                  ? this.state.tglBerlaku.format('DD-MM-YYYY')
                  : null
              }
              type='date'
              onPress={() => {
                this.setState({
                  isShowDatePicker2: !this.state.isShowDatePicker2,
                });
              }}
              iconRight={"date-range"}
            />

            <CustomTextInput
              title={this.state.isOperasional ? 'Surat Perizinan' : 'Surat Tanda Registrasi'}
              onPress={() => {
                this.showFilePicker();
              }}
              type={"file"}
              value={
                this.state.filePickerResult.length > 0 
                  ? this.state.filePickerResult[0].name 
                  : ""}
              textRight={"Pilih Dokumen"}
            />

            <SubmitButton onPress={() => this.saveForm()}>
              <ButtonText>Simpan</ButtonText>
            </SubmitButton>
          </View>
        </View>
      </ScrollView>
    );
  }
}

const mapStateToProps = state => ({
  perizinanEditRequest: state.perizinan,
});

const mapDispatchToProps = dispatch =>
  bindActionCreators(PerizinanEditCreators, dispatch);

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(FormStr);
