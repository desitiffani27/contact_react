import React from 'react';
import {View, FlatList, TouchableOpacity, Text, StyleSheet} from 'react-native';
import Separator from '~/components/common/Separator';
import styles from '~/styles';
import {Icon} from 'react-native-elements';
import InfoEmpty from '~/components/common/InfoEmpty';

const renderEmpty = () => {
  return (
    <View>
      <InfoEmpty scrollEnabled title={'Data is empty!'} />
    </View>
  );
};

const stylesComponent = StyleSheet.create({
  // View
  container: {
    paddingHorizontal: styles.metrics.mediumSize,
  },
  containerText: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  // Text
  text: {
    color: styles.colors.darkText,
    fontSize: 18,
    marginVertical: styles.metrics.largeSize,
  },
});

const List = ({selected, onSelected, data, idFieldName, nameFieldName}) => {
  console.log('selected : ', selected);
  if(typeof idFieldName == "undefined"){
    idFieldName = "id";
    nameFieldName = "name";
  }

  return (
    <View>
      <FlatList
        style={{
          marginTop: styles.metrics.mediumSize,
          marginBottom: styles.metrics.largeSize,
        }}
        ListEmptyComponent={renderEmpty}
        renderItem={({item, index}) => {
          return (
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => {
                onSelected(item);
              }}>
              <View style={stylesComponent.container}>
                <View style={stylesComponent.containerText}>
                  <Text style={stylesComponent.text}>{item[nameFieldName]}</Text>
                  {item[idFieldName] === selected && (
                    <Icon
                      type="material"
                      name="done"
                      size={styles.metrics.exlargeRS}
                      iconStyle={{
                        color: styles.colors.subText,
                      }}
                    />
                  )}
                </View>
                <Separator />
              </View>
            </TouchableOpacity>
          );
        }}
        keyExtractor={item => item[idFieldName]}
        data={data}
      />
    </View>
  );
};

export default List;
