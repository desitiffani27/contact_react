import React from 'react';
import {View, TextInput} from 'react-native';
import styles from '~/styles';
import Separator from '~/components/common/Separator';

const TextArea = ({value, onChangeText}) => {
  return (
    <View>
      <TextInput
        multiline={true}
        autoFocus={true}
        value={value}
        onChangeText={onChangeText}
        style={{
          padding: styles.metrics.mediumSize,
          color: styles.colors.darkText,
        }}
      />
      <Separator />
    </View>
  );
};

export default TextArea;
