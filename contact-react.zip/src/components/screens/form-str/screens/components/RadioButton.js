import React from 'react';
import {View, FlatList, TouchableOpacity, Text, StyleSheet} from 'react-native';
import Separator from '~/components/common/Separator';
import styles from '~/styles';
import {Icon} from 'react-native-elements';

var data = [{id: 1, name: 'Male'}, {id: 2, name: 'Female'}];

const RadioButton = ({selected, onSelected, options}) => {
  if(options != null){
    data = options;
  }

  const stylesComponent = StyleSheet.create({
    // View
    container: {
      paddingHorizontal: styles.metrics.mediumSize,
    },
    containerText: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },

    // Text
    text: {
      color: styles.colors.darkText,
      fontSize: 18,
      marginVertical: styles.metrics.largeSize,
    },
  });

  return (
    <View>
      <FlatList
        style={{marginTop: styles.metrics.mediumSize}}
        renderItem={(item, index) => {
          console.log(item);
          return (
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => {
                onSelected(item.item.id);
              }}>
              <View style={stylesComponent.container}>
                <View style={stylesComponent.containerText}>
                  <Text style={stylesComponent.text}>{item.item.name}</Text>
                  {item.item.id === selected && (
                    <Icon
                      type="material"
                      name="done"
                      size={styles.metrics.exlargeRS}
                      iconStyle={{
                        color: styles.colors.subText,
                      }}
                    />
                  )}
                </View>
                <Separator />
              </View>
            </TouchableOpacity>
          );
        }}
        keyExtractor={item => item.id}
        data={data}
      />
    </View>
  );
};

export default RadioButton;
