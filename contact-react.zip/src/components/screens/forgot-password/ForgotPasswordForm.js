// @flow

import React, {Component} from 'react';
import {
  TouchableOpacity,
  StatusBar,
  Animated,
  FlatList,
  ProgressBarAndroid,
  Image,
  View,
  TextInput,
  Text,
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {showMessage} from 'react-native-flash-message';
import styled from 'styled-components';
import {AuthContext} from '../../../context';
import {DefaultText} from '../login/components/Common';
import env from 'react-native-config';

import appStyles from '~/styles';

const Container = styled(View)`
  flex: 1;
`;

const Wrapper = styled(View)`
  width: 100%;
  height: 100%;
  position: absolute;
`;

const ContentWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.width}px;
  height: 100%;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const DarkLayer = styled(View)`
  width: 100%;
  height: 100%;
  background-color: ${({theme}) => theme.colors.intermediateDarkLayer};
`;

const Title = styled(Text)`
  font-family: Modesta-Script;
  color: ${({theme}) => theme.colors.defaultWhite};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('11.5%')}px;
`;

const TitleWrapper = styled(View)`
  width: 100%;
  align-items: center;
  justify-content: center;
  margin-vertical: ${({theme}) => theme.metrics.getHeightFromDP('4%')}px;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const BackgroundImage = styled(Image).attrs({
  source: {uri: 'login'},
  resizeMode: 'cover',
})`
  position: absolute;
  width: 100%;
  height: 100%;
`;

const NavigationTitleWrapper = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('10%')}px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;
const ContentContainer = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('7%')}px;
  justify-content: center;
  align-items: center;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({color}) => color};
  border-radius: 4px;
`;
class ForgotPasswordPhone extends Component {
  _loginFontSize: Object = new Animated.Value(1);
  _signUpFontSize: Object = new Animated.Value(0);
  _flatListRef: Object = {};
  static contextType = AuthContext;
  state = {
    isBackgroundImageLoaded: false,
    otp: null,
    confirmPassword: null,
    isResendSms: false,
    data: null,
    timer: 60,
    type: null,
    password: null,
  };
  componentDidMount() {
    const auth = this.context;
    setInterval(() => {
      this.countDown();
    }, 1000);
    this.countDown = this.countDown.bind(this);
    const {navigation, route} = this.props;
    navigation.setOptions({tabBarVisible: false});
    const {data: data} = route.params;
    this.setState({data});
    console.log(data);
  }
  countDown() {
    if (this.state.timer > 0) {
      this.setState({
        timer: this.state.timer - 1,
        isResendSms: false,
      });
    } else {
      this.setState({
        timer: this.state.timer,
        isResendSms: true,
      });
    }
  }
  onClickLoginButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 1,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 0,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 0}));
  };

  onClickSignUpButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 0,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 1,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 1}));
  };
  showRegisterError = (message, type) => {
    // setProgressVisible(false);

    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
    });
  };
  onLoadBackgroundImage = (): void => {
    this.setState({
      isBackgroundImageLoaded: true,
    });
  };
  validator = () => {
    if (!this.state.otp) {
      this.showRegisterError('OTP cannot be empty !', 'error');
      return false;
    }
    if (!this.state.password) {
      this.showRegisterError('Password cannot be empty !', 'error');
      return false;
    }
    if (!this.state.confirmPassword) {
      this.showRegisterError('Password confirm cannot be empty !', 'error');
      return false;
    }
    if (this.state.confirmPassword !== this.state.password) {
      this.showRegisterError('Password confirm not match !', 'error');
      return false;
    }
    if (this.state.otp.length < 6) {
      this.showRegisterError('OTP must be 6 digit !', 'error');
      return false;
    }
    return true;
  };
  verify() {
    const auth = this.context;
    this.validator() &&
      auth.forgotPassword(
        this.state.data,
        this.state.otp,
        this.state.password,
        this.showRegisterError,
        () => {
          auth.signIn(
            {
              username: this.state.data,
              password: this.state.password,
            },
            this.showRegisterError,
            response => {
              // if (!response.data.result.isActive) {
              //   navigation.navigate(ROUTE_NAMES.OTP, {
              //     data: response.result,
              //     type: 'LOGIN',
              //   });
              // }
              console.log('login success');
            },
          );
        },
      );
  }
  renderContent = (): Object => {
    const auth = this.context;
    let passTextInput = null;
    let confirmPassTextInput = null;
    return (
      <View
        style={{
          paddingHorizontal: appStyles.metrics.extraLargeSize * 2,
        }}>
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            marginBottom: 10,
            color: 'white',
          }}
          onChangeText={text => this.setState({otp: text})}
          value={this.state.otp}
          maxLength={6}
          keyboardType={'numeric'}
          placeholder={'OTP Code'}
          returnKeyType={'next'}
          onSubmitEditing={() => passTextInput.focus()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          selectionColor={appStyles.colors.defaultWhite}
        />
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            marginBottom: 10,
            color: 'white',
          }}
          onChangeText={text => this.setState({password: text})}
          value={this.state.password}
          returnKeyType={'next'}
          keyboardType={'default'}
          placeholder={'New Password'}
          secureTextEntry={true}
          onSubmitEditing={() => confirmPassTextInput.focus()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          selectionColor={appStyles.colors.defaultWhite}
          ref={input => {
            passTextInput = input;
          }}
        />
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            color: 'white',
          }}
          onChangeText={text => this.setState({confirmPassword: text})}
          value={this.state.confirmPassword}
          keyboardType={'default'}
          secureTextEntry={true}
          placeholder={'Confirm New Password'}
          onSubmitEditing={() => this.verify()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          selectionColor={appStyles.colors.defaultWhite}
          ref={input => {
            confirmPassTextInput = input;
          }}
        />
        <ProgressBarAndroid
          styleAttr="Horizontal"
          style={{
            width: '50%',
            marginHorizontal: '25%',
          }}
          indeterminate={false}
          color={appStyles.colors.primaryColor}
          progress={this.state.timer / 60}
        />
        <Text
          style={{
            color: 'white',
            fontSize: 15,
            textAlign: 'center',
            padding: appStyles.metrics.mediumSize,
          }}>
          Did not recieve code?
        </Text>
        <TouchableOpacity
          disabled={!this.state.isResendSms}
          onPress={() => {
            // setProgressVisible(true);
            // signIn({username, password}, showLoginError);
            console.log('verify');
            this.setState({isResendSms: false, timer: 60});
            auth.resendOtp(this.state.data, this.showRegisterError, null);
          }}>
          <ContentContainer
            color={
              !this.state.isResendSms
                ? appStyles.colors.softBlue
                : appStyles.colors.blue
            }>
            <DefaultText>RESEND OTP</DefaultText>
          </ContentContainer>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            // setProgressVisible(true);
            // signIn({username, password}, showLoginError);
            this.verify();
          }}>
          <ContentContainer color={appStyles.colors.primaryColor}>
            <DefaultText>SUBMIT</DefaultText>
          </ContentContainer>
        </TouchableOpacity>
      </View>
    );
  };

  render() {
    const {isBackgroundImageLoaded} = this.state;

    return (
      <Container>
        <StatusBar
          backgroundColor="transparent"
          barStyle="light-content"
          translucent
          animated
        />
        <BackgroundImage onLoad={this.onLoadBackgroundImage} />
        <DarkLayer />
        {isBackgroundImageLoaded && (
          <Wrapper>
            <KeyboardAwareScrollView>
              <TitleWrapper>
                <Image
                  style={{width: 100, height: 120}}
                  source={{
                    uri: 'logonew',
                  }}
                />
                <Text
                  style={{
                    color: 'white',
                    fontSize: 25,
                    fontWeight: 'bold',
                    textShadowColor: appStyles.colors.primaryColor,
                    textShadowOffset: {width: 10, height: 10},
                  }}>
                  Forgot Password
                </Text>
                <Text
                  style={{
                    color: 'white',
                    fontSize: 15,
                    textAlign: 'center',
                    paddingTop: appStyles.metrics.mediumSize,
                  }}>
                  Please enter 6 digit code sent to your mobile phone and your
                  new password.
                </Text>
              </TitleWrapper>
              {this.renderContent()}
            </KeyboardAwareScrollView>
          </Wrapper>
        )}
      </Container>
    );
  }
}

export default ForgotPasswordPhone;
