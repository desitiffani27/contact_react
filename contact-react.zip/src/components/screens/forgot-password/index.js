// @flow

import React, {Component} from 'react';
import {
  TouchableOpacity,
  StatusBar,
  Animated,
  FlatList,
  ProgressBarAndroid,
  Image,
  View,
  TextInput,
  Text,
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import {showMessage} from 'react-native-flash-message';
import styled from 'styled-components';
import {AuthContext} from '../../../context';
import {DefaultText} from '../login/components/Common';
import {ROUTE_NAMES} from '~/utils/CONSTANTS';
import env from 'react-native-config';

import appStyles from '~/styles';

const Container = styled(View)`
  flex: 1;
`;

const Wrapper = styled(View)`
  width: 100%;
  height: 100%;
  position: absolute;
`;

const ContentWrapper = styled(View)`
  width: ${({theme}) => theme.metrics.width}px;
  height: 100%;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const DarkLayer = styled(View)`
  width: 100%;
  height: 100%;
  background-color: ${({theme}) => theme.colors.intermediateDarkLayer};
`;

const Title = styled(Text)`
  font-family: Modesta-Script;
  color: ${({theme}) => theme.colors.defaultWhite};
  font-size: ${({theme}) => theme.metrics.getWidthFromDP('11.5%')}px;
`;

const TitleWrapper = styled(View)`
  width: 100%;
  align-items: center;
  justify-content: center;
  margin-vertical: ${({theme}) => theme.metrics.getHeightFromDP('4%')}px;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;

const BackgroundImage = styled(Image).attrs({
  source: {uri: 'login'},
  resizeMode: 'cover',
})`
  position: absolute;
  width: 100%;
  height: 100%;
`;

const NavigationTitleWrapper = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('10%')}px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-horizontal: ${({theme}) => 2 * theme.metrics.extraLargeSize}px;
`;
const ContentContainer = styled(View)`
  width: 100%;
  height: ${({theme}) => theme.metrics.getHeightFromDP('7%')}px;
  justify-content: center;
  align-items: center;
  margin-bottom: ${({theme}) => theme.metrics.largeSize}px;
  background-color: ${({color}) => color};
  border-radius: 4px;
`;
class ForgotPasswordPhone extends Component {
  _loginFontSize: Object = new Animated.Value(1);
  _signUpFontSize: Object = new Animated.Value(0);
  _flatListRef: Object = {};
  static contextType = AuthContext;
  state = {
    isBackgroundImageLoaded: false,
    phone: null,
    isResendSms: false,
    data: null,
    timer: 60,
    type: null,
    password: null,
  };
  componentDidMount() {
    const auth = this.context;
    setInterval(() => {
      this.countDown();
    }, 1000);
    this.countDown = this.countDown.bind(this);
    const {navigation, route} = this.props;
    navigation.setOptions({tabBarVisible: false});
    // const {data: data, type: type, password: password} = route.params;
    // this.setState({data, type, password});
    // if (type === 'LOGIN') {
    //   auth.resendOtp(data.phone, this.showRegisterError);
    // }
    // console.log(data);
  }
  countDown() {
    if (this.state.timer > 0) {
      this.setState({
        timer: this.state.timer - 1,
        isResendSms: false,
      });
    } else {
      this.setState({
        timer: this.state.timer,
        isResendSms: true,
      });
    }
  }
  onClickLoginButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 1,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 0,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 0}));
  };

  onClickSignUpButton = (): void => {
    Animated.parallel([
      Animated.timing(this._loginFontSize, {
        toValue: 0,
        duration: 200,
      }),
      Animated.timing(this._signUpFontSize, {
        toValue: 1,
        duration: 200,
      }),
    ]).start(this._flatListRef.scrollToIndex({animated: true, index: 1}));
  };
  showRegisterError = (message, type) => {
    // setProgressVisible(false);

    showMessage({
      message: message,
      type: type === 'error' ? 'danger' : 'success',
      icon: type === 'error' ? 'danger' : 'success',
    });
  };
  onLoadBackgroundImage = (): void => {
    this.setState({
      isBackgroundImageLoaded: true,
    });
  };
  validator = () => {
    if (!this.state.phone) {
      this.showRegisterError('Phone cannot be empty !', 'error');
      return false;
    }
    return true;
  };
  verify() {
    const {navigation, route} = this.props;
    const auth = this.context;
    this.validator() &&
      auth.resendOtp(this.state.phone, this.showRegisterError, () => {
        navigation.navigate(ROUTE_NAMES.FORGOT_PASSWORD_FORM, {
          data: this.state.phone,
        });
      });
    // auth.verifyOtp(
    //   this.state.data.phone,
    //   this.state.otp,
    //   this.showRegisterError,
    //   () => {
    //     if (this.state.type === 'LOGIN' || this.state.type === 'REGISTER') {
    //       auth.signIn(
    //         {
    //           username: this.state.data.email,
    //           password: this.state.password,
    //         },
    //         this.showRegisterError,
    //         response => {
    //           // if (!response.data.result.isActive) {
    //           //   navigation.navigate(ROUTE_NAMES.OTP, {
    //           //     data: response.result,
    //           //     type: 'LOGIN',
    //           //   });
    //           // }
    //           console.log('login success');
    //         },
    //       );
    //     }
    //   },
    // );
  }
  renderContent = (): Object => {
    const auth = this.context;
    return (
      <View
        style={{
          paddingHorizontal: appStyles.metrics.extraLargeSize * 2,
        }}>
        <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            color: 'white',
            marginBottom: 10,
          }}
          onChangeText={text => this.setState({phone: text})}
          value={this.state.phone}
          maxLength={14}
          keyboardType={'numeric'}
          placeholder={'Phone Number'}
          onSubmitEditing={() => this.verify()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          selectionColor={appStyles.colors.defaultWhite}
        />
        {/* <TextInput
          style={{
            height: 50,
            width: '100%',
            borderColor: appStyles.colors.transparentGray,
            backgroundColor: appStyles.colors.transparentGray,
            borderWidth: 1,
            textAlign: 'center',
            borderRadius: 5,
            color: 'white',
          }}
          onChangeText={text => this.setState({otp: text})}
          value={this.state.otp}
          maxLength={6}
          keyboardType={'numeric'}
          placeholder={'XXXXXX'}
          onSubmitEditing={() => this.verify()}
          placeholderTextColor={appStyles.colors.transparentGrayx}
          selectionColor={appStyles.colors.defaultWhite}
        /> */}
        {/* <ProgressBarAndroid
          styleAttr="Horizontal"
          style={{
            width: '50%',
            marginHorizontal: '25%',
          }}
          indeterminate={false}
          color={appStyles.colors.primaryColor}
          progress={this.state.timer / 60}
        /> */}
        {/* <Text
          style={{
            color: 'white',
            fontSize: 15,
            textAlign: 'center',
            padding: appStyles.metrics.mediumSize,
          }}>
          Did not recieve code?
        </Text> */}
        {/* <TouchableOpacity
          disabled={!this.state.isResendSms}
          onPress={() => {
            // setProgressVisible(true);
            // signIn({username, password}, showLoginError);
            console.log('verify');
            this.setState({isResendSms: false, timer: 60});
            auth.resendOtp(this.state.data.phone, this.showRegisterError);
          }}>
          <ContentContainer
            color={
              !this.state.isResendSms
                ? appStyles.colors.softBlue
                : appStyles.colors.blue
            }>
            <DefaultText>RESEND OTP</DefaultText>
          </ContentContainer>
        </TouchableOpacity> */}
        <TouchableOpacity
          onPress={() => {
            // setProgressVisible(true);
            // signIn({username, password}, showLoginError);
            this.verify();
          }}>
          <ContentContainer color={appStyles.colors.primaryColor}>
            <DefaultText>SUBMIT</DefaultText>
          </ContentContainer>
        </TouchableOpacity>
      </View>
    );
  };

  render() {
    const {isBackgroundImageLoaded} = this.state;

    return (
      <Container>
        <StatusBar
          backgroundColor="transparent"
          barStyle="light-content"
          translucent
          animated
        />
        <BackgroundImage onLoad={this.onLoadBackgroundImage} />
        <DarkLayer />
        {isBackgroundImageLoaded && (
          <Wrapper>
            <KeyboardAwareScrollView>
              <TitleWrapper>
                <Image
                  style={{width: 120, height: 150}}
                  source={{
                    uri: 'logonew',
                  }}
                />
                <Text
                  style={{
                    color: 'white',
                    fontSize: 25,
                    fontWeight: 'bold',
                    textShadowColor: appStyles.colors.primaryColor,
                    textShadowOffset: {width: 10, height: 10},
                  }}>
                  Forgot Password
                </Text>
                <Text
                  style={{
                    color: 'white',
                    fontSize: 15,
                    textAlign: 'center',
                    paddingTop: appStyles.metrics.mediumSize,
                  }}>
                  Please enter your mobile phone number.
                </Text>
              </TitleWrapper>
              {this.renderContent()}
            </KeyboardAwareScrollView>
          </Wrapper>
        )}
      </Container>
    );
  }
}

export default ForgotPasswordPhone;
