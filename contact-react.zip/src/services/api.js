import axios from 'axios';
import env from 'react-native-config';

console.log('URL: ' + env.API_BASE_URL);
const api = axios.create({
  baseURL: env.API_BASE_URL,
  timeout: 3000,
});

// Remove these lines if wanting to disable http request log
api.interceptors.request.use(request => {
  console.log('Starting Request', request);
  return request;
});

export const setClientToken = token => {
  let tokenBearer = '';
  if (token != null && token !== '') {
    tokenBearer = 'Bearer ' + token;
  }
  api.defaults.headers.common.Authorization = tokenBearer;
};

export const URI = {
  AUTH: {
    LOGIN: 'login',
    LOGOUT: 'logout'
  },
  LANDING_PAGE: {
    GET: 'dashboard'
  },
  PROFILE: {
    SHOW: 'profile/show',
    EDIT: 'profile/edit',
    SAVE: 'profile/store',
    SAVE_PROFILE_PICTURE: 'save-profile-picture'
  },
  PERIZINAN: {
    SAVE: 'update-perizinan',
  },
  STR: {
    SAVE: 'update-str',
  },
};

export default api;
