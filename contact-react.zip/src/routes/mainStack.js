// @flow

import * as React from 'react';
import {Image} from 'react-native';
import styled from 'styled-components';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {NavigationContainer} from '@react-navigation/native';

import AsyncStorage from '@react-native-community/async-storage';
import env from 'react-native-config';
import {ROUTE_NAMES} from '../utils/CONSTANTS';
import HomeRoutes from '../components/screens/home/routes';
import ArticleRoutes from '../components/screens/home/routes';
import ProfileRoutes from '../components/screens/profile/routes';

import isEqualsOrLargestThanIphoneX from '../utils/isEqualsOrLargestThanIphoneX';
import appStyles from '../styles';

const getTabIcon = (icon, tintColor) => {
  return <MaterialIcon color={tintColor} name={icon} size={28} />;
};

const getTabImageIcon = (image) => {
  return <Image source={{uri: image}} style={{width: 21, height: 21}} />;
};

const getTabBarVisibility = route => {
  console.log('> getTabBarVisibility');
  console.log(route.state);
  return route.state === undefined || route.state.index === 0;
};

const Tab = createBottomTabNavigator();

function MainStack(isLoggedIn) {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{ headerShown: false }}
        initialRouteName={ROUTE_NAMES.HOME}
        lazy={true}
        tabBarOptions={{
          showLabel: true,
          showIcon: true,
          labelStyle: {fontSize: 12},
          style: {
            paddingBottom: isEqualsOrLargestThanIphoneX() ? 30 : 0,
            backgroundColor: appStyles.colors.tabBackground,
            height: isEqualsOrLargestThanIphoneX()
              ? appStyles.metrics.getResponsiveSize(9)
              : appStyles.metrics.getResponsiveSize(6.5),
          },
          tabStyle: {
            backgroundColor: appStyles.colors.tabBackground,
          },
          indicatorStyle: {
            backgroundColor: 'transparent',
          },
          inactiveTintColor: appStyles.colors.tabInactive,
          activeTintColor: appStyles.colors.menuActiveColor,
        }}>
        <Tab.Screen
          name={ROUTE_NAMES.HOME}
          component={HomeRoutes}
          options={({route}) => ({
            tabBarLabel: 'Home',
            tabBarVisible: getTabBarVisibility(route),
            tabBarIcon: ({color}) => getTabIcon('home', color),
          })}
        />
        {/* <Tab.Screen
          name={ROUTE_NAMES.SEARCH_TALENT}
          component={SearchTalentRoutes}
          options={({route}) => ({
            tabBarLabel: 'Search Talent',
            tabBarVisible: getTabBarVisibility(route),
            tabBarIcon: ({color}) => getTabIcon('search', color),
          })}
        /> */}
        {/* <Tab.Screen
          name={ROUTE_NAMES.BOOKING_LIST}
          component={BookingRoutes}
          options={({route}) => ({
            tabBarLabel: 'Booking',
            tabBarVisible: getTabBarVisibility(route),
            tabBarIcon: ({color}) => getTabIcon('assignment', color),
          })}
        /> */}
        {/* {env.ENV_NAME === 'DEV' && ( */}
          {/* <Tab.Screen
            name={ROUTE_NAMES.ORDER_LIST}
            component={OrderRoutes}
            options={({route}) => ({
              tabBarLabel: 'Order',
              tabBarVisible: getTabBarVisibility(route),
              tabBarIcon: ({color}) => getTabIcon('shopping-basket', color),
            })}
          /> */}
        {/* )} */}
        <Tab.Screen
          name={ROUTE_NAMES.PROFILE}
          component={ProfileRoutes}
          options={({route}) => ({
            tabBarLabel: 'Profile',
            tabBarVisible: getTabBarVisibility(route),
            tabBarIcon: ({color}) => getTabIcon('account-circle', color),
          })}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default MainStack;
