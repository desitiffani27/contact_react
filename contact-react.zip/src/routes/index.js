import * as React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
import {NavigationContainer} from '@react-navigation/native';

import {ROUTE_NAMES} from '../utils/CONSTANTS';

import OnboardingIntro from '../components/screens/onboarding-intro';
import Login from '../components/screens/login/index';
import Otp from '../components/screens/otp/index';
import ForgotPasswordPhone from '../components/screens/forgot-password/index';
import ForgotPasswordForm from '../components/screens/forgot-password/ForgotPasswordForm';
import AsyncStorage from '@react-native-community/async-storage';
const Stack = createStackNavigator();

function AuthStack(isFirstTime) {
  console.log('> not authenticated');
  // AsyncStorage.getItem('isFirstTime').then(isFirstTime => {
  console.log(isFirstTime.isFirstTime, 'isFirstTime');
  return (
    <NavigationContainer>
      <Stack.Navigator
        // initialRouteName={
        //   isFirstTime.isFirstTime !== null || isFirstTime.isFirstTime === false
        //     ? ROUTE_NAMES.LOGIN
        //     : ROUTE_NAMES.ONBOARDING_INTRO
        // }
        initialRouteName={ ROUTE_NAMES.LOGIN }
        headerMode="none">
        <Stack.Screen
          name={ROUTE_NAMES.ONBOARDING_INTRO}
          component={OnboardingIntro}
        />
        <Stack.Screen name={ROUTE_NAMES.LOGIN} component={Login} />
        <Stack.Screen name={ROUTE_NAMES.OTP} component={Otp} />
        <Stack.Screen
          name={ROUTE_NAMES.FORGOT_PASSWORD_PHONE}
          component={ForgotPasswordPhone}
        />
        <Stack.Screen
          name={ROUTE_NAMES.FORGOT_PASSWORD_FORM}
          component={ForgotPasswordForm}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
  // });
}

export default AuthStack;
