import Immutable from 'seamless-immutable';

export const Types = {
  GET_PROFILE_REQUEST: 'profile/GET_PROFILE_REQUEST',
  GET_PROFILE_SUCCESS: 'profile/GET_PROFILE_SUCCESS',
  GET_PROFILE_FAILURE: 'profile/GET_PROFILE_FAILURE',

  GET_PROFILE_EDIT_REQUEST: 'profile/GET_PROFILE_EDIT_REQUEST',
  GET_PROFILE_EDIT_SUCCESS: 'profile/GET_PROFILE_EDIT_SUCCESS',
  GET_PROFILE_EDIT_FAILURE: 'profile/GET_PROFILE_EDIT_FAILURE',

  POST_PROFILE_EDIT_REQUEST: 'profile/POST_PROFILE_EDIT_REQUEST',
  POST_PROFILE_EDIT_SUCCESS: 'profile/POST_PROFILE_EDIT_SUCCESS',
  POST_PROFILE_EDIT_FAILURE: 'profile/POST_PROFILE_EDIT_FAILURE',

  POST_PROFILE_PICTURE_EDIT_REQUEST: 'profile/POST_PROFILE_PICTURE_EDIT_REQUEST',
  POST_PROFILE_PICTURE_EDIT_SUCCESS: 'profile/POST_PROFILE_PICTURE_EDIT_SUCCESS',
  POST_PROFILE_PICTURE_EDIT_FAILURE: 'profile/POST_PROFILE_PICTURE_EDIT_FAILURE',

  POST_REQUEST_KTA_REQUEST: 'profile/POST_REQUEST_KTA_REQUEST',
  POST_REQUEST_KTA_SUCCESS: 'profile/POST_REQUEST_KTA_SUCCESS',
  POST_REQUEST_KTA_FAILURE: 'profile/POST_REQUEST_KTA_FAILURE',
};

const initialState = Immutable({
  loading: false,
  error: false,
  errorMessage: null,
  data: {},
  dataGetProfile: {},
  dataEdit: null,
  dataReqKta: []
});

export const Creators = {
  getProfileRequest: () => ({
    type: Types.GET_PROFILE_REQUEST,
  }),

  getProfileSuccess: data => ({
    type: Types.GET_PROFILE_SUCCESS,
    payload: {data},
  }),

  getProfileFailure: errorMessage => ({
    type: Types.GET_PROFILE_FAILURE,
    payload: {errorMessage},
  }),

  getEditProfileRequest: (callback) => ({
    type: Types.GET_PROFILE_EDIT_REQUEST,
    callback: callback
  }),

  getEditProfileSuccess: data => ({
    type: Types.GET_PROFILE_EDIT_SUCCESS,
    payload: {data},
  }),

  getEditProfileFailure: errorMessage => ({
    type: Types.GET_PROFILE_EDIT_FAILURE,
    payload: {errorMessage},
  }),

  postProfileEditRequest: (param, onDone) => ({
    type: Types.POST_PROFILE_EDIT_REQUEST,
    payload: {param, onDone},
  }),

  postProfileEditSuccess: data => ({
    type: Types.POST_PROFILE_EDIT_SUCCESS,
    payload: {data},
  }),

  postProfileEditFailure: errorMessage => ({
    type: Types.POST_PROFILE_EDIT_FAILURE,
    payload: {errorMessage},
  }),

  postProfilePictureEditRequest: avatar => ({
    type: Types.POST_PROFILE_PICTURE_EDIT_REQUEST,
    payload: {avatar},
  }),

  postProfilePictureEditSuccess: data => ({
    type: Types.POST_PROFILE_PICTURE_EDIT_SUCCESS,
    payload: {data},
  }),

  postProfilePictureEditFailure: errorMessage => ({
    type: Types.POST_PROFILE_PICTURE_EDIT_FAILURE,
    payload: {errorMessage},
  }),

  postRequestKtaRequest: (param, onDone) => ({
    type: Types.POST_REQUEST_KTA_REQUEST,
    payload: {param, onDone},
  }),

  postRequestKtaSuccess: data => ({
    type: Types.POST_REQUEST_KTA_SUCCESS,
    payload: {data},
  }),

  postRequestKtaFailure: errorMessage => ({
    type: Types.POST_REQUEST_KTA_FAILURE,
    payload: {errorMessage},
  }),
};

const profile = (state = initialState, action) => {
  switch (action.type) {
    case Types.GET_PROFILE_REQUEST:
      console.log('> GET_PROFILE_REQUEST');
      return {
        ...state,
        loading: true,
        errorMessage: null,
        error: false,
      };

    case Types.GET_PROFILE_SUCCESS:
      console.log('> GET_PROFILE_SUCCESS');
      console.log('> Success', action.payload.data);
      return {
        ...state,
        data: action.payload.data,
        loading: false,
        error: false,
        errorMessage: null,
      };

    case Types.GET_PROFILE_FAILURE:
      console.log('> GET_PROFILE_FAILURE');
      return {
        ...state,
        loading: false,
        error: true,
        errorMessage: action.payload.errorMessage,
      };
    
      case Types.GET_PROFILE_EDIT_REQUEST:
        console.log('> GET_PROFILE_EDIT_REQUEST');
        return {
          ...state,
          loading: true,
          errorMessage: null,
          error: false,
        };
  
      case Types.GET_PROFILE_EDIT_SUCCESS:
        console.log('> GET_PROFILE_EDIT_SUCCESS');
        console.log('> Success', action.payload.data);
        return {
          ...state,
          dataGetProfile: action.payload.data,
          loading: false,
          error: false,
          errorMessage: null,
        };
  
      case Types.GET_PROFILE_EDIT_FAILURE:
        console.log('> GET_PROFILE_EDIT_FAILURE');
        return {
          ...state,
          loading: false,
          error: true,
          errorMessage: action.payload.errorMessage,
        };

    case Types.POST_PROFILE_EDIT_REQUEST:
      console.log('> POST_PROFILE_EDIT_REQUEST');
      return {
        ...state,
        loading: true,
        errorMessage: null,
        error: false,
      };

    case Types.POST_PROFILE_EDIT_SUCCESS:
      console.log('> POST_PROFILE_EDIT_SUCCESS');
      console.log('> Success', action.payload.data);
      return {
        ...state,
        dataEdit: action.payload.param,
        loading: false,
        error: false,
        errorMessage: null,
      };

    case Types.POST_PROFILE_EDIT_FAILURE:
      console.log('> POST_PROFILE_EDIT_FAILURE');
      return {
        ...state,
        loading: false,
        error: true,
        errorMessage: action.payload.errorMessage,
      };

    case Types.POST_PROFILE_PICTURE_EDIT_REQUEST:
      console.log('> POST_PROFILE_PICTURE_EDIT_REQUEST');
      return {
        ...state,
        loading: false,
        errorMessage: null,
        error: false,
      };

    case Types.POST_PROFILE_PICTURE_EDIT_SUCCESS:
      console.log('> POST_PROFILE_PICTURE_EDIT_SUCCESS');
      console.log('> Success', action.payload.data);
      return {
        ...state,
        loading: false,
        dataEdit: {...initialState.dataEdit, foto_profil: action.payload.data.data.url},
        error: false,
        errorMessage: null,
      };
  
    case Types.POST_PROFILE_PICTURE_EDIT_FAILURE:
      console.log('> POST_PROFILE_PICTURE_EDIT_FAILURE');
      return {
        ...state,
        loading: false,
        error: true,
        errorMessage: action.payload.errorMessage,
      };
    

    case Types.POST_REQUEST_KTA_REQUEST:
      console.log('> POST_REQUEST_KTA_REQUEST');
      return {
        ...state,
        loading: true,
        errorMessage: null,
        error: false,
      };

    case Types.POST_REQUEST_KTA_SUCCESS:
      console.log('> POST_REQUEST_KTA_SUCCESS');
      console.log('> Success', action.payload.data);
      return {
        ...state,
        dataReqKta: action.payload.data,
        loading: false,
        error: false,
        errorMessage: null,
      };

    case Types.POST_REQUEST_KTA_FAILURE:
      console.log('> POST_REQUEST_KTA_FAILURE');
      return {
        ...state,
        loading: false,
        error: false,
        errorMessage: action.payload.errorMessage,
      };

    default:
      console.log('> PROFILE_DUCKS->default');
      return state;
  }
};

export default profile;
