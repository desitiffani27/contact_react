import Immutable from 'seamless-immutable';

export const Types = {
  POST_PERIZINAN_EDIT_REQUEST: 'perizinan/POST_PERIZINAN_EDIT_REQUEST',
  POST_PERIZINAN_EDIT_SUCCESS: 'perizinan/POST_PERIZINAN_EDIT_SUCCESS',
  POST_PERIZINAN_EDIT_FAILURE: 'perizinan/POST_PERIZINAN_EDIT_FAILURE',

  // POST_PROFILE_PICTURE_EDIT_REQUEST: 'profile/POST_PROFILE_PICTURE_EDIT_REQUEST',
  // POST_PROFILE_PICTURE_EDIT_SUCCESS: 'profile/POST_PROFILE_PICTURE_EDIT_SUCCESS',
  // POST_PROFILE_PICTURE_EDIT_FAILURE: 'profile/POST_PROFILE_PICTURE_EDIT_FAILURE',
};

const initialState = Immutable({
  loading: false,
  error: false,
  errorMessage: null,
  data: {},
  dataEdit: null
});

export const Creators = {
  postPerizinanEditRequest: (param, onDone) => ({
    type: Types.POST_PERIZINAN_EDIT_REQUEST,
    payload: {param, onDone},
  }),

  postPerizinanEditSuccess: data => ({
    type: Types.POST_PERIZINAN_EDIT_SUCCESS,
    payload: {data},
  }),

  postPerizinanEditFailure: errorMessage => ({
    type: Types.POST_PERIZINAN_EDIT_FAILURE,
    payload: {errorMessage},
  }),

  // postProfilePictureEditRequest: avatar => ({
  //   type: Types.POST_PROFILE_PICTURE_EDIT_REQUEST,
  //   payload: {avatar},
  // }),

  // postProfilePictureEditSuccess: data => ({
  //   type: Types.POST_PROFILE_PICTURE_EDIT_SUCCESS,
  //   payload: {data},
  // }),

  // postProfilePictureEditFailure: errorMessage => ({
  //   type: Types.POST_PROFILE_PICTURE_EDIT_FAILURE,
  //   payload: {errorMessage},
  // }),
};

const perizinan = (state = initialState, action) => {
  switch (action.type) {
    case Types.POST_PERIZINAN_EDIT_REQUEST:
      console.log('> POST_PERIZINAN_EDIT_REQUEST');
      return {
        ...state,
        loading: true,
        errorMessage: null,
        error: false,
      };

    case Types.POST_PERIZINAN_EDIT_SUCCESS:
      console.log('> POST_PERIZINAN_EDIT_SUCCESS');
      console.log('> Success', action.payload.data);
      console.log('> Param', action.payload);
      return {
        ...state,
        dataEdit: action.payload.data,
        loading: false,
        error: false,
        errorMessage: null,
      };

    case Types.POST_PERIZINAN_EDIT_FAILURE:
      console.log('> POST_PERIZINAN_EDIT_FAILURE');
      return {
        ...state,
        loading: false,
        error: true,
        errorMessage: action.payload.errorMessage,
      };

    // case Types.POST_PROFILE_PICTURE_EDIT_REQUEST:
    //   console.log('> POST_PROFILE_PICTURE_EDIT_REQUEST');
    //   return {
    //     ...state,
    //     loading: false,
    //     errorMessage: null,
    //     error: false,
    //   };

    // case Types.POST_PROFILE_PICTURE_EDIT_SUCCESS:
    //   console.log('> POST_PROFILE_PICTURE_EDIT_SUCCESS');
    //   console.log('> Success', action.payload.data);
    //   return {
    //     ...state,
    //     loading: false,
    //     dataEdit: {...initialState.dataEdit, foto_profil: action.payload.data.data.url},
    //     error: false,
    //     errorMessage: null,
    //   };
  
    // case Types.POST_PROFILE_PICTURE_EDIT_FAILURE:
    //   console.log('> POST_PROFILE_PICTURE_EDIT_FAILURE');
    //   return {
    //     ...state,
    //     loading: false,
    //     error: true,
    //     errorMessage: action.payload.errorMessage,
    //   };

    default:
      console.log('> PERIZINAN_DUCKS->default');
      return state;
  }
};

export default perizinan;
