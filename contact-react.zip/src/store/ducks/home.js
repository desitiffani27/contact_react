import Immutable from 'seamless-immutable';

export const Types = {

  GET_LANDING_REQUEST: 'home/GET_LANDING_REQUEST',
  GET_LANDING_SUCCESS: 'home/GET_LANDING_SUCCESS',
  GET_LANDING_FAILURE: 'home/GET_LANDING_FAILURE',

  GET_SERVICE_REQUEST: 'home/GET_SERVICE_REQUEST',
  GET_SERVICE_SUCCESS: 'home/GET_SERVICE_SUCCESS',
  GET_SERVICE_FAILURE: 'home/GET_SERVICE_FAILURE',
};

const initialState = Immutable({
  loading: false,
  error: false,
  errorMessage: null,
  user: null,
  widget: null,
  tenagaKesehatanStr: [],
  operasionalStr: []
});

export const Creators = {

  getLandingRequest: () => ({
    type: Types.GET_LANDING_REQUEST,
  }),

  getLandingSuccess: data => ({
    type: Types.GET_LANDING_SUCCESS,
    payload: {data},
  }),

  getLandingFailure: errorMessage => ({
    type: Types.GET_LANDING_FAILURE,
    payload: {errorMessage},
  }),

};

const home = (state = initialState, action) => {
  switch (action.type) {
  
    case Types.GET_LANDING_REQUEST:
      console.log('> GET_LANDING_REQUEST');
      return {
        ...state,
        loading: true,
        errorMessage: null,
        error: false,
      };

    case Types.GET_LANDING_SUCCESS:
      console.log('> GET_LANDING_SUCCESS');
      return {
        ...state,
        user: action.payload.data.data.user,
        widget: action.payload.data.data.widget,
        tenagaKesehatanStr: action.payload.data.data.perizinan_tekes_latest,
        operasionalStr: action.payload.data.data.perizinan_op_latest,
        loading: false,
        error: false,
        errorMessage: null,
      };

    case Types.GET_LANDING_FAILURE:
      console.log('> GET_LANDING_FAILURE');
      return {
        ...state,
        loading: false,
        error: true,
        errorMessage: action.payload.errorMessage,
      };

    default:
      console.log('> HOME_DUCKS->default');
      return state;
  }
};

export default home;
