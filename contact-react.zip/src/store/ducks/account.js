import Immutable from 'seamless-immutable';

export const Types = {
  LOGOUT_REQUEST: 'account/LOGOUT_REQUEST',
  LOGOUT_SUCCESS: 'account/LOGOUT_SUCCESS',
  LOGOUT_FAILURE: 'account/LOGOUT_FAILURE',
};

const initialState = Immutable({
  loading: false,
  error: false,
  errorMessage: null,
});

export const Creators = {
  logoutRequest: () => ({
    type: Types.LOGOUT_REQUEST,
  }),

  logoutSuccess: data => ({
    type: Types.LOGOUT_SUCCESS,
    payload: {data},
  }),

  logoutFailure: errorMessage => ({
    type: Types.LOGOUT_FAILURE,
    payload: {errorMessage},
  }),
};

const account = (state = initialState, action) => {
  switch (action.type) {
    case Types.LOGOUT_REQUEST:
      console.log('> LOGOUT_REQUEST');
      return {
        ...state,
        loading: true,
        errorMessage: null,
        error: false,
      };

    case Types.LOGOUT_SUCCESS:
      console.log('>LOGOUT_SUCCESS');
      return {
        ...state,
        loading: false,
        error: false,
        errorMessage: null,
      };

    case Types.LOGOUT_FAILURE:
      console.log('> LOGOUT_FAILURE');
      return {
        ...state,
        loading: false,
        error: true,
        errorMessage: action.payload.errorMessage,
      };

    default:
      console.log('> ACCOUNT_DUCKS->default');
      return state;
  }
};

export default account;
