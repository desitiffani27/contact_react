import {combineReducers} from 'redux';

import home from './home';
import profile from './profile';
import account from './account';
import perizinan from './perizinan';

export default combineReducers({
  home,
  profile,
  account,
  perizinan
});
