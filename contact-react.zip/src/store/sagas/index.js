import {all, takeLatest, takeEvery} from 'redux-saga/effects';

import {Types as AccountTypes} from '../ducks/account';
import {Types as HomeTypes} from '../ducks/home';
import {Types as ProfileTypes} from '../ducks/profile';
import {Types as PerizinanTypes} from '../ducks/perizinan';

import {
  profileRequest, 
  profileEditRequest, 
  getProfileEditRequest, 
  profilePictureEditRequest
} from './profile';
import {landingRequest} from './home';
import {logoutRequest} from './account';
import {perizinanEditRequest} from './perizinan';

export default function* rootSaga() {
  return yield all([
    takeLatest(HomeTypes.GET_LANDING_REQUEST, landingRequest),
    takeLatest(ProfileTypes.GET_PROFILE_REQUEST, profileRequest),
    takeLatest(ProfileTypes.GET_PROFILE_EDIT_REQUEST, getProfileEditRequest),
    takeLatest(ProfileTypes.POST_PROFILE_EDIT_REQUEST, profileEditRequest),
    takeLatest(ProfileTypes.POST_PROFILE_PICTURE_EDIT_REQUEST, profilePictureEditRequest),
    takeLatest(AccountTypes.LOGOUT_REQUEST, logoutRequest),
    takeLatest(PerizinanTypes.POST_PERIZINAN_EDIT_REQUEST, perizinanEditRequest)
  ]);
}
