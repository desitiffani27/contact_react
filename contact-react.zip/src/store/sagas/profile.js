import {call, put} from 'redux-saga/effects';

import {Creators as ProfileActions} from '../ducks/profile';
import api, {URI} from '../../services/api';

export function* profileRequest(action) {
  try {
    console.log('> profileRequest');
    console.log(action.payload);
    const response = yield call(api.get, URI.PROFILE.SHOW);
    console.log('> DATA', response.data);
    yield put(ProfileActions.getProfileSuccess(response.data.data));
  } catch (err) {
    console.log(err);
    var errorMsg = err.toString();
    if(err.response.data.message){
      errorMsg = err.response.data.message;
    }
    yield put(ProfileActions.getProfileFailure(errorMsg));
  }
}

export function* getProfileEditRequest(action) {
  try {
    console.log('> getProfileEditRequest');
    console.log(action.payload);
    const response = yield call(api.get, URI.PROFILE.EDIT);
    console.log('> DATA', response.data);
    yield put(ProfileActions.getEditProfileSuccess(response.data.data));
    action.callback(response.data.data);
  } catch (err) {
    console.log(err);
    var errorMsg = err.toString();
    if(err.response.data.message){
      errorMsg = err.response.data.message;
    }
    yield put(ProfileActions.getEditProfileFailure(errorMsg));
  }
}

export function* profileEditRequest(action) {
  try {
    //api.defaults.headers.post = {'Content-Type': 'multipart/form-data'};
    console.log('> profileEditRequest');
    console.log(action.payload);
    const response = yield call(api.post, URI.PROFILE.SAVE, action.payload.param);
    console.log('> DATA', response.data);
    yield put(ProfileActions.postProfileEditSuccess(response.data));
    if (action.payload.onDone) {
      action.payload.onDone();
    }
  } catch (err) {
    console.log(err.response);
    var errorMsg = err.toString();
    if(err.response.data.message){
      errorMsg = err.response.data.message;
    }
    yield put(ProfileActions.postProfileEditFailure(errorMsg));
  }
}

export function* profilePictureEditRequest(action) {
  try {
    api.defaults.headers.post = {'Content-Type': 'multipart/form-data'};
    console.log('> profilePictureEditRequest');
    console.warn(action.payload);
    const { avatar } = action.payload;
    const data = new FormData();
    if (avatar) {
      data.append('foto_profil', {
        uri: avatar.uri,
        name: avatar.fileName,
        type: 'image/jpg',
      });
    }
    console.warn(data);
    const response = yield call(api.post, URI.PROFILE.SAVE_PROFILE_PICTURE, data);
    console.warn('> DATA' + response.data);
    yield put(ProfileActions.postProfilePictureEditSuccess(response.data));
  } catch (err) {
    console.warn('> ERROR' + err.response);
    var errorMsg = err.toString();
    if(err.response.data.message){
      errorMsg = err.response.data.message;
    }
    yield put(ProfileActions.postProfilePictureEditFailure(errorMsg));
  }
}


export function* requestKta(action) {
  try {
    console.log('> requestKta');
    console.log(action.payload);
    const response = yield call(api.post, URI.PROFILE.REQUEST_KTA, action.payload.param);
    console.log('> DATA', response.data);
    yield put(ProfileActions.postRequestKtaSuccess(response.data));
    if (action.payload.onDone) {
      action.payload.onDone(response.data);
    }
  } catch (err) {
    console.log(err.response);
    var errorMsg = err.toString();
    if(err.response.data.message){
      errorMsg = err.response.data.message;
    }
    yield put(ProfileActions.postRequestKtaFailure(errorMsg));
    if (action.payload.onDone) {
      action.payload.onDone(err.response.data);
    }
  }
}