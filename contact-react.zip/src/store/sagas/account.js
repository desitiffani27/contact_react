import {call, put} from 'redux-saga/effects';

import {Creators as AccountActions} from '../ducks/account';
import api, {URI} from '../../services/api';

/**
 * Request to get list of pkom list
 */
export function* logoutRequest() {
  try {
    console.log('> logout');
    const response = yield call(api.post, URI.AUTH.LOGOUT);
    yield put(AccountActions.logoutSuccess(response.data));
  } catch (err) {
    console.log(err);
    yield put(AccountActions.logoutFailure(err.toString()));
  }
}
