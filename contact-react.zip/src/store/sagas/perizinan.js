import {call, put} from 'redux-saga/effects';

import {Creators as PerizinanActions} from '../ducks/perizinan';
import api, {URI} from '../../services/api';

export function* perizinanEditRequest(action) {
  try {
    api.defaults.headers.post = {'Content-Type': 'multipart/form-data'};
    console.log('> perizinanEditRequest');
    const data = new FormData();
    var isOperasional = action.payload.param.isOperasional;
    if (isOperasional){
      data.append("no_surat", action.payload.param.no_surat);
    }else{
      data.append("no_str", action.payload.param.no_surat);
    }
    data.append("tgl_terbit", action.payload.param.tgl_terbit);
    data.append("tgl_berlaku", action.payload.param.tgl_berlaku);
    data.append("id", action.payload.param.id);
    if (action.payload.param.file) {
      data.append('file', {
        uri: action.payload.param.file.uri,
        name: action.payload.param.file.name,
        type: action.payload.param.file.type,
      });
    }
    console.log(data);
    //const response = yield call(api.post, URI.PERIZINAN.SAVE, action.payload.param);
    const response = yield call(api.post, isOperasional ? URI.PERIZINAN.SAVE : URI.STR.SAVE, data);
    console.log(response);
    yield put(PerizinanActions.postPerizinanEditSuccess(response.data));
    if (action.payload.onDone) {
      action.payload.onDone(response.data);
    }
  } catch (err) {
    console.log(err);
    var errorMsg = err.toString();
    if(err.response.data.message){
      errorMsg = err.response.data.message;
    }
    yield put(PerizinanActions.postPerizinanEditFailure(errorMsg));
  }
}