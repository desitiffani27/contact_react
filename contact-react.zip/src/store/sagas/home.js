import {call, put} from 'redux-saga/effects';

import {Creators as HomeActions} from '../ducks/home';
import api, {URI} from '../../services/api';

export function* landingRequest() {
  try {
    console.warn('> landingRequest');
    const response = yield call(api.get, URI.LANDING_PAGE.GET);
    console.warn(response)
    yield put(HomeActions.getLandingSuccess(response.data));
  } catch (err) {
    console.log('errorrrrrr', err);
    // if (
    //   err.toString() !==
    //   "TypeError: undefined is not an object (evaluating 'error.response.status')"
    // ) {
    if (err && err.response.status !== 404) {
      yield put(HomeActions.getLandingFailure(err.toString()));
    }
    // }
  }
}